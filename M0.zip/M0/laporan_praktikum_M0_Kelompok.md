# Template Laporan Praktikum Sistem Operasi Lanjut — MCSOS

**Nama file laporan:** `laporan_praktikum_[kode_praktikum]_[nim_atau_kelompok].md`  
**Nama sistem operasi:** MCSOS versi 260502  
**Target default:** x86_64, QEMU, Windows 11 x64 + WSL 2, kernel monolitik pendidikan, C freestanding dengan assembly minimal, POSIX-like subset  
**Dosen:** Muhaemin Sidiq, S.Pd., M.Pd.  
**Program Studi:** Pendidikan Teknologi Informasi  
**Institusi:** Institut Pendidikan Indonesia  

> Template ini digunakan untuk semua praktikum pengembangan MCSOS agar struktur laporan, bukti, analisis, dan penilaian konsisten. Ganti seluruh teks bertanda `[isi ...]` dengan data praktikum sebenarnya. Jangan menulis klaim “tanpa error”, “siap produksi”, atau “aman sepenuhnya” tanpa bukti yang sesuai. Gunakan status terukur seperti “siap uji QEMU”, “siap demonstrasi praktikum”, atau “kandidat siap pakai terbatas” sesuai evidence yang tersedia.

---

## 0. Metadata Laporan

| Atribut | Isi |
|---|---|
| Kode praktikum | `M0` |
| Judul praktikum | `Inisiasi Baseline Environment dan Validasi Toolchain` |
| Jenis pengerjaan | `Kelompok` |
| Nama mahasiswa | `[-]` |
| NIM | `[-]` |
| Kelas | `1B` |
| Nama kelompok | `Kelompok Nabil, Marko, Muharam` |
| Anggota kelompok | `Muhamad Nabil (2583207073017) Implementasu, Marko Ali Musa (25842074006) menyusun laporan, Muharam Alfarizi (25832074002 menyusun laporan)` |
| Tanggal praktikum | `2026-06-10` |
| Tanggal pengumpulan | `2026-06-10` |
| Repository | `~/src/mcsos` |
| Branch | `main` |
| Commit awal | `1391b13` |
| Commit akhir | `1391b13` |
| Status readiness yang diklaim | `siap demonstrasi praktikum` |
---

## 1. Sampul

# Laporan Praktikum `[M0]`  
## `[Inisiasi Baseline Environment dan Validasi Toolchain]`

Disusun oleh:

| Nama | NIM | Kelas | Peran |
|---|---|---|---|
| `[Muhamad nabil]` | `[2583207073017]` | `[Kelas 1B]` | `[Ketua / Implementasi / Pengujian]` |
| `[Marko ali musa]` | `[25842074006]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / menyusun Laporan]` |
| `[Muharam alfarizi]` | `[25832074002]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / Menyusun Laporan]` |

Dosen Pengampu: **Muhaemin Sidiq, S.Pd., M.Pd.**  
Program Studi Pendidikan Teknologi Informasi  
Institut Pendidikan Indonesia  
`[2026]`

---

## 2. Pernyataan Orisinalitas dan Integritas Akademik

Saya menyatakan bahwa laporan ini disusun berdasarkan pekerjaan praktikum sendiri sesuai pembagian peran yang tercatat. Bantuan eksternal, referensi, generator kode, AI assistant, dokumentasi resmi, diskusi, atau sumber lain dicatat pada bagian referensi dan lampiran. Saya tidak mengklaim hasil yang tidak dibuktikan oleh log, test, commit, atau artefak lain.

| Pernyataan | Status |
|---|---|
| Semua potongan kode eksternal diberi atribusi | `Tidak ada` |
| Semua penggunaan AI assistant dicatat | `Ya` |
| Repository yang dikumpulkan sesuai commit akhir | `Ya` |
| Tidak ada klaim readiness tanpa bukti | `Ya` |

Catatan penggunaan bantuan eksternal:

```text
Alat: Google Gemini (AI Assistant)
Prompt ringkas: Meminta bantuan untuk memformat log terminal, menyusun kalimat penjelasan teknis, dan memetakan hasil eksekusi praktikum ke dalam template Markdown.
Bagian yang dibantu: Penyesuaian konteks Modul 0 (persiapan toolchain) ke dalam template laporan, penyusunan narasi pada bab arsitektur, analisis kegagalan (failure modes), analisis risiko (security & reliability), serta penyusunan format tabel readiness.
Verifikasi mandiri yang dilakukan: Seluruh perintah kompilasi (Makefile, clang, bash script) dan inspeksi (readelf, file, git, sha256sum) dieksekusi murni secara mandiri di lingkungan lokal (WSL2/Ubuntu). Output asli dari terminal tersebut disalin dan diberikan kepada AI murni sebagai bahan dasar (raw data) untuk diformat ke dalam dokumen laporan.
```
---

## 3. Tujuan Praktikum

1. Membangun dan memvalidasi *toolchain* yang dapat direproduksi (*reproducible build*) untuk target arsitektur `x86_64-pc-none-elf` menggunakan Clang dan Makefile di lingkungan WSL 2.
2. Menghasilkan *file* objek murni (*freestanding*) melalui uji kompilasi dasar (*smoke test*) tanpa adanya ketergantungan pada *library* standar (libc) bawaan sistem operasi *host*.
3. Memahami konsep lingkungan *bare-metal* dasar dan pentingnya pengaturan *compiler flags* kustom (seperti `-ffreestanding` dan `-mno-red-zone`) untuk menjaga keamanan *stack* dari interupsi perangkat keras.
4. Mendokumentasikan bukti otentik pengujian melalui pencatatan log metadata versi alat kerja, *output* kompilasi bersih (*clean build*), serta bukti *readelf* dan *file* yang memverifikasi arsitektur target mesin.

---

## 4. Capaian Pembelajaran Praktikum

Setelah praktikum ini, mahasiswa mampu:

| CPL/CPMK praktikum | Bukti yang harus ditunjukkan |
|---|---|
| `[capaian 1]` | `[log, screenshot, test, diff, diagram, analisis]` |
| `[capaian 2]` | `[log, screenshot, test, diff, diagram, analisis]` |
| `[capaian 3]` | `[log, screenshot, test, diff, diagram, analisis]` |

---
## 5. Peta Milestone MCSOS

Centang milestone yang menjadi fokus laporan ini. Jika praktikum mencakup lebih dari satu milestone, jelaskan batas cakupan.

| Milestone | Fokus | Status dalam laporan |
|---|---|---|
| M0 | Requirements, governance, baseline arsitektur | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M1 | Toolchain reproducible, Git, QEMU, GDB, metadata build | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M2 | Boot image, kernel ELF64, early console | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M3 | Panic path, linker map, GDB, observability awal | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M4 | Trap, exception, interrupt, timer | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M5 | PMM, VMM, page table, kernel heap | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M6 | Thread, scheduler, synchronization | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M7 | Syscall ABI dan user program loader | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M8 | VFS, file descriptor, ramfs | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M9 | Block layer dan device model | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M10 | Persistent filesystem, mcsfs/ext2-like, recovery | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M11 | Networking stack, packet parsing, UDP/TCP subset | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M12 | Security model, capability/ACL, syscall fuzzing, hardening | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M13 | SMP, scalability, lock stress, NUMA-aware preparation | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M14 | Framebuffer, graphics console, visual regression | `[ x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M15 | Virtualization/container subset | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M16 | Observability, update/rollback, release image, readiness review | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |

Batas cakupan praktikum:

```text
Praktikum ini berfokus pada penyelesaian milestone M0 (baseline arsitektur & persiapan lingkungan) serta inisiasi tahap awal pada milestone M1. 

Fitur yang termasuk (Goals):
1. Pengaturan lingkungan WSL 2 (Ubuntu) dan repositori Git.
2. Validasi toolchain (Clang, Make, QEMU) beserta generasi log metadata yang reproducible (toolchain-versions.txt).
3. Uji kompilasi dasar (smoke test) untuk menghasilkan freestanding object.

Fitur yang TIDAK termasuk (Non-goals):
Praktikum ini tidak mencakup pembuatan file boot image (.iso / .img), eksekusi OS di emulator QEMU, penggunaan GDB untuk remote debugging, dan penulisan logika kernel utama. Laporan ini tidak mengklaim kesiapan fitur OS apa pun melainkan murni memvalidasi kesiapan "pabrik" (toolchain) pembuat sistem operasi.
```
---

## 6. Dasar Teori Ringkas

Tuliskan teori yang langsung diperlukan untuk memahami praktikum. Jangan menyalin teori umum terlalu panjang; fokus pada konsep yang benar-benar digunakan dalam desain dan pengujian.

### 6.1 Konsep Sistem Operasi yang Diuji

Pada praktikum Modul 0 ini, pengujian belum menyentuh logika runtime sistem operasi seperti penjadwalan (scheduler), manajemen memori (PMM/VMM), atau virtual filesystem (VFS). Konsep utama yang diuji adalah pembentukan lingkungan kompilasi *freestanding* dan validasi struktur dasar *Executable and Linkable Format* (ELF). ELF adalah format standar file biner untuk *executable*, *object code*, *shared libraries*, dan *core dumps* pada sistem turunan Unix. Praktikum memvalidasi bahwa *toolchain* (Clang) dapat diinstruksikan untuk memproduksi file objek berformat ELF64 yang murni menargetkan arsitektur *bare-metal* x86-64 tanpa menginjeksi komponen dari OS *host*.

### 6.2 Konsep Arsitektur x86_64 yang Relevan

| Konsep | Relevansi pada praktikum | Bukti/verifikasi |
|---|---|---|
| Target ISA AMD64 (x86-64) | `Memastikan *compiler* menghasilkan set instruksi mesin yang valid untuk arsitektur prosesor 64-bit yang akan di-booting, bukan instruksi 32-bit (i386) atau arsitektur lain.` | `Uji `readelf -h` mencetak metadata Class: ELF64` dan `Machine: Advanced Micro Devices X86-64`. |
| `*Red Zone* (System V ABI)` | `Area 128-byte di bawah *stack pointer* (RSP) yang diamankan dari modifikasi oleh fungsi pemanggil. Dalam mode kernel, *hardware interrupt* dapat terjadi asinkron dan menggunakan *stack* yang sama, sehingga optimasi *Red Zone* wajib dimatikan agar data tidak tertimpa/korup.` | `Deklarasi argumen `-mno-red-zone` secara eksplisit pada aturan kompilasi target `smoke` di dalam Makefile`. |

### 6.3 Konsep Implementasi Freestanding

| Aspek | Keputusan praktikum |
|---|---|
| Bahasa | `C (mode *freestanding*) murni, tanpa dependensi *header* standar yang bergantung pada implementasi OS.` |
| Runtime | `Tanpa *hosted* `libc` (Lingkungan *bare-metal* absolut).` |
| ABI | `x86_64 System V Application Binary Interface.` |
| Compiler flags kritis | `-target x86_64-pc-none-elf`, `-ffreestanding, -mno-red-zone, -c (hanya kompilasi ke *object file*, tidak di-link).` |
| Risiko undefined behavior | `Asumsi optimasi kompilator terkait *stack* (diatasi dengan -mno-red-zone) dan pemanggilan implisit fungsi standar seperti *built-in* memset atau memcpy oleh kompilator jika tidak ditangani ketat.` |

### 6.4 Referensi Teori yang Digunakan

| No. | Sumber | Bagian yang digunakan | Alasan relevansi |
|---|---|---|---|
| 1 | `Clang Compiler User's Manual (LLVM Project)` | `*Cross-compilation targets* & *Freestanding Environments*` | `Menjadi acuan dokumentasi resmi untuk menentukan parameter target (`x86_64-pc-none-elf`) dan *flag* pelepasan *library* bawaan (-ffreestanding).` |
| 2 | `System V Application Binary Interface: AMD64 Architecture Processor Supplement` | `Bab 3.2.2 *The Stack Frame (Red Zone)*` | `Menjadi landasan teori arsitektural mengapa perlindungan *stack pointer* melalui flag -mno-red-zone sangat krusial dalam pengembangan mode kernel/bare-metal.` |

---

## 7. Lingkungan Praktikum

### 7.1 Host dan Target

| Komponen | Nilai |
|---|---|
| Host OS | `Windows 11 x64` |
| Lingkungan build | `WSL 2 Ubuntu` |
| Target ISA | `x86_64` |
| Target ABI | `x86_64-pc-none-elf` |
| Emulator | `QEMU 10.2.1` |
| Firmware emulator | `OVMF` |
| Debugger | `GDB 17.1` |
| Build system | `Make 4.4.1` |
| Bahasa utama | `C17 freestanding` |
| Assembly | `NASM 3.01` |

### 7.2 Versi Toolchain

Tempel output versi toolchain berikut. Jalankan dari clean shell WSL.

```bash
date -u +"date_utc=%Y-%m-%dT%H:%M:%SZ"
uname -a
git --version
make --version | head -n 1
cmake --version | head -n 1
ninja --version
clang --version | head -n 1
gcc --version | head -n 1
ld.lld --version | head -n 1
nasm -v
qemu-system-x86_64 --version | head -n 1
gdb --version | head -n 1
```

Output:

```text
[date_utc=2026-06-05T02:24:03Z
Linux NABIL 6.6.114.1-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Mon Dec  1 20:46:23 UTC 2025 x86_64 GNU/Linux
git version 2.53.0
GNU Make 4.4.1
cmake version 4.2.3
1.13.2
Ubuntu clang version 21.1.8 (6ubuntu1)
gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0
Ubuntu LLD 21.1.8 (compatible with GNU linkers)
NASM version 3.01
QEMU emulator version 10.2.1 (Debian 1:10.2.1+ds-1ubuntu3)
GNU gdb (Ubuntu 17.1-2ubuntu1) 17.1]
```

### 7.3 Lokasi Repository

| Item | Nilai |
|---|---|
| Path repository di WSL | `` `[/home/nabil/src/mcsos]` `` |
| Apakah berada di filesystem Linux WSL, bukan `/mnt/c` | `[Ya]` |
| Remote repository | `[-]` |
| Branch | `[main]` |
| Commit hash awal | `` `[1391b13]` `` |
| Commit hash akhir | `` `[1391b13]` `` |

---

## 8. Repository dan Struktur File

### 8.1 Struktur Direktori yang Relevan

Tampilkan hanya direktori dan file yang relevan dengan praktikum.

```text
[.
├── .git
│   ├── HEAD
│   ├── config
│   ├── description
│   ├── hooks
│   ├── info
│   ├── objects
│   └── refs
├── build
│   ├── meta
│   └── smoke
├── docs
│   ├── adr
│   ├── architecture
│   ├── governance
│   ├── operations
│   ├── reports
│   ├── requirements
│   ├── security
│   └── testing
├── smoke
│   └── smoke.c
└── tools
    ├── check_env.sh
    └── .gitignore
]
```

### 8.2 File yang Dibuat atau Diubah

| File | Jenis perubahan | Alasan perubahan | Risiko |
|---|---|---|---|
| `[.gitignore]` | `[baru]` | `[Mencegah file build sampah masuk ke Git]` | `[Rendah: hanya file konfigurasi]` |
| `[README.md]` | `[baru]` | `[Dokumentasi baseline proyek M0]` | `[Rendah: file teks informasi]` |
| `[Makefile]` | `[baru]` | `[Otomasi build, check, dan smoke test]` | `[Sedang: risiko salah konfigurasi path]` |
| `[smoke/smoke.c]` | `[baru]` | `[Kode smoke test untuk validasi compiler]` | `[Rendah: fungsi dummy sederhana]` |
| `[tools/check_env.sh` | `[baru]` | `[Skrip validasi toolchain & metadata]` | `[Sedang: butuh permission eksekusi]` |
| `[build/]` | `[baru]` | `[Direktori penyimpanan hasil kompilasi]` | `[Rendah: temporary files]` |

### 8.3 Ringkasan Diff

```bash
git status --short
git diff --stat
git log --oneline -n 5
```

Output:

```text
[nabil@bil:~/src/mcsos$ git status --short
nabil@bil.src/mcsos$ git diff --stat
nabil@bil:~/src/mcsos$ git log --oneline -n 5
1391b13 (HEAD -> main) feat(m0): inisiasi baseline environment dan toolchain

nabil@bil:~/src/mcsos$ git show --stat
commit 1391b13
Author: NABIL <kumarungucok@gmail.com>

 .gitignore           |  21 +++++++++++++++++++++
 Makefile             |  18 ++++++++++++++++++
 README.md            |  31 +++++++++++++++++++++++++++++++
 smoke/smoke.c        |   4 ++++
 tools/check_env.sh   |  45 +++++++++++++++++++++++++++++++++++++++++++++
 5 files changed, 119 insertions(+).]
```

---

## 9. Desain Teknis

### 9.1 Masalah yang Diselesaikan

```text
[Praktikum M0 ini menyelesaikan masalah ketiadaan lingkungan pengembangan (development environment) yang standar, terisolasi, dan dapat direproduksi (reproducible). Sebelum proyek dimulai, tidak ada jaminan bahwa toolchain yang digunakan memiliki versi yang seragam atau mampu menghasilkan binary freestanding murni yang terlepas dari sistem operasi host (Windows). M0 memastikan seluruh konfigurasi WSL, target arsitektur kompilasi (x86_64-pc-none-elf), dan skrip pengujian (Makefile & check_env) terverifikasi untuk mencegah isu "works on my machine" di tahap pengembangan kernel selanjutnya..]
```

### 9.2 Keputusan Desain

| Keputusan | Alternatif yang dipertimbangkan | Alasan memilih | Konsekuensi |
|---|---|---|---|
| `[Menggunakan WSL 2 (Ubuntu) dan Clang]` | `[Native Windows atau membangun GCC cross-compiler sendiri]` | `[Ekosistem Linux stabil. Clang bawaan sudah mendukung target x86_64-pc-none-elf secara instan.]` | `[Wajib memakai Windows dengan virtualisasi aktif dan butuh pengaturan Git khusus (CRLF ke LF).]` |
| `[Kompilasi freestanding C (-ffreestanding)]` | `[Kompilasi hosted C (menggunakan library bawaan OS)]` | `[Kernel berjalan murni di bare metal tanpa bantuan OS lain. Red zone dimatikan demi keamanan interrupt.]` | `[Tidak ada library standar bawaan (seperti printf atau malloc). Fitur harus dibangun dari nol.]` |
| `[Otomasi menggunakan Bash Script dan Makefile]` | `[Mengeksekusi perintah cek dan compile secara manual]` | `[Menjamin lingkungan build selalu reproducible dan mencegah error karena salah ketik.]` | `[Harus rutin memperbarui isi skrip dan Makefile seiring bertambahnya fitur proyek.]` |

### 9.3 Arsitektur Ringkas

Berikut adalah diagram alur kerja lingkungan kompilasi dan validasi (toolchain) pada Modul 0:

```mermaid
flowchart TD
    A[Perintah Eksekusi: make meta / make smoke] --> B[Lingkungan WSL 2: Clang & GNU Make]
    B --> C[Artefak: build/smoke/freestanding.o & toolchain-versions.txt]
    C --> D[Validasi: readelf, file, check_env.sh]

Penjelasan diagram:

```text
[1. Input (A): Pengguna memberikan instruksi kompilasi atau pengecekan melalui terminal menggunakan utilitas Make.
2. Subsystem (B): Lingkungan WSL 2 Ubuntu mengambil alih proses. Kompiler Clang memproses kode sumber C menjadi instruksi mesin sesuai target arsitektur (x86_64-pc-none-elf).
3. Artefak (C): Menghasilkan file objek yang murni (freestanding tanpa library bawaan OS) serta mencatat metadata versi dari semua alat yang terlibat.
4. Validasi (D): Hasil kompilasi diuji menggunakan utilitas seperti readelf untuk membuktikan kesesuaian target arsitektur mesin (Advanced Micro Devices X86-64 / ELF64).]
```

### 9.4 Kontrak Antarmuka

*Catatan: Pada tahap Modul 0, belum ada implementasi API kernel atau syscall. Kontrak antarmuka di bawah ini hanya mewakili fungsi pengujian kompilasi dasar (smoke test).*

| Antarmuka | Pemanggil | Penerima | Precondition | Postcondition | Error path |
|---|---|---|---|---|---|
| `dummy_function(void)` | `N/A (Tidak dipanggil)` | `Kompiler (Clang)` | `Lingkungan build dan toolchain terpasang dengan benar` | `Menghasilkan file objek murni (freestanding.o)` | `Kompilasi gagal jika ada dependensi library host` |

### 9.5 Struktur Data Utama

*Catatan: Tidak ada struktur data kompleks yang didefinisikan pada Modul 0 karena fokus praktikum hanya pada penyiapan dan validasi lingkungan kerja (environment setup).*

| Struktur data | Field penting | Ownership | Lifetime | Invariant |
|---|---|---|---|---|
| `N/A` | `-` | `-` | `-` | `-` |

### 9.6 Invariants

*Catatan: Karena Modul 0 berfokus pada persiapan toolchain, invariant di sini adalah aturan mutlak terkait lingkungan kompilasi, bukan logika internal kernel.*

1. Kompilasi harus selalu menargetkan arsitektur `x86_64-pc-none-elf` (ELF64).
2. Bendera kompiler (compiler flags) `-ffreestanding` dan `-mno-red-zone` wajib aktif pada setiap kompilasi kode C untuk mencegah masuknya *library* bawaan host OS dan melindungi *stack* perangkat keras.
3. Proses kompilasi harus sepenuhnya dapat direproduksi (*reproducible*) melalui `Makefile` tanpa memerlukan eksekusi perintah secara manual satu per satu.
4. Repositori Git tidak boleh melacak (track) artefak hasil kompilasi (seperti file `.o` atau isi folder `build/`) berkat aturan mutlak dari `.gitignore`.

### 9.7 Ownership, Locking, dan Concurrency

*Catatan: Pada tahap Modul 0, belum ada kode runtime kernel yang dieksekusi, sehingga belum ada objek memori, mekanisme penguncian (locking), ataupun masalah konkurensi.*

| Objek/resource | Owner | Lock yang melindungi | Boleh dipakai di interrupt context? | Catatan |
|---|---|---|---|---|
| `N/A` | `-` | `-` | `-` | `Belum ada resource runtime pada tahap M0` |

Lock order yang berlaku:

```text
Tidak ada urutan penguncian (lock order) yang berlaku pada tahap ini. Pembahasan konkurensi belum relevan karena praktikum Modul 0 murni berfokus pada validasi toolchain statis dan pengujian kompilasi file tunggal (smoke.c). Seluruh proses build dikendalikan secara sekuensial oleh GNU Make, sehingga lingkungan kerja berada dalam kondisi single-threaded. Mekanisme interupsi dan locking baru akan dibahas saat kernel mulai mengeksekusi kode konkret di modul berikutnya.
```

### 9.8 Memory Safety dan Undefined Behavior Risk

| Risiko | Lokasi | Mitigasi | Bukti |
|---|---|---|---|
| `Injeksi *host library* (Undefined Behavior karena absennya libc di kernel)` | `Makefile (Target smoke)` | `Menggunakan flag `-ffreestanding` agar Clang tidak mengasumsikan keberadaan fungsi standar C (printf, malloc) dan lingkungan *hosted*.` | `Review `Makefile` dan hasil *smoke test* yang sukses mengompilasi kode tanpa menautkan *library* OS host.` |
| `Korupsi *stack* saat terjadi perangkat keras *interrupt*` | `Makefile` (Target `smoke`) | `Menggunakan flag -mno-red-zone` `untuk menonaktifkan optimasi Red Zone 128-byte khas ABI x86_64, sehingga *stack pointer* selalu aman digunakan oleh *interrupt handler*.` | `Review `Makefile` pada target kompilasi C.` |
| `Injeksi perintah, variabel tidak terkuotasi, dan kelemahan *shell*` | `tools/check_env.sh` | `Menggunakan *static analysis tool* khusus skrip (*ShellCheck*) untuk memastikan *script* validasi lingkungan bebas dari kerentanan umum.` | `Target `make check` di `Makefile` mengeksekusi shellcheck tools/*.sh`. |

### 9.9 Security Boundary

| Boundary | Data tidak tepercaya | Validasi yang dilakukan | Failure mode aman |
|---|---|---|---|
| `Eksekusi Skrip Validasi Toolchain (check_env.sh)` | `Konfigurasi sistem *host* (versi program, environment path, dan utilitas WSL bawaan)` | `Pemeriksaan eksistensi *binary* yang ketat sebelum eksekusi dan penulisan log metadata ke toolchain-versions.txt`. | `Skrip memunculkan pesan `[FAIL]` dan berhenti (*exit code > 0*), mencegah make berjalan di *environment* yang korup`. |
| `*Static Analysis Tool* Skrip` | `Teks sumber (source code) skrip Bash lokal (tools/*.sh)` | `Validasi statis menggunakan shellcheck terhadap kesalahan *globbing*, variabel tanpa *quote*, dan celah *shell injection* lokal.` | `Perintah make check akan dibatalkan (*halt*) jika ditemukan praktik penulisan skrip Bash yang tidak aman.` |

---

## 10. Langkah Kerja Implementasi

Gunakan tabel berikut untuk setiap langkah. Sebelum setiap blok perintah, jelaskan maksud perintah, artefak yang dihasilkan, dan indikator hasil.

### Langkah 1 — Pembuatan dan Eksekusi Skrip Validasi Toolchain

Maksud langkah:

```text
Langkah ini dilakukan untuk memastikan bahwa seluruh perangkat lunak prasyarat (seperti Clang, Make, QEMU, dan Python) telah terinstal dengan benar di lingkungan WSL 2. Selain itu, langkah ini secara otomatis merekam versi dari masing-masing alat (tool) untuk menjamin bahwa lingkungan kompilasi dapat direproduksi (reproducible) di masa depan.
```

Perintah:

```bash
[make meta]
```

Output ringkas:

```text
[./tools/check_env.sh
[OK] git                /usr/bin/git
[OK] make               /usr/bin/make
[OK] clang              /usr/bin/clang
[OK] qemu-system-x86_64 /usr/bin/qemu-system-x86_64
[M0] Writing toolchain metadata
[M0] Metadata written to build/meta/toolchain-versions.txt
[M0] Environment check completed. This means the M0 environment is checkable, not that the OS can boot.]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[toolchain-versions.txt]` | `[build/meta/]` | `[Menyimpan log otentik dari seluruh versi toolchain yang aktif saat proses build dilakukan.]` |
| `[check_env.sh]` | `[tools/]` | `[Skrip bash utama untuk melakukan validasi environment.]` |

Indikator berhasil:

```text
[Langkah dinyatakan berhasil jika terminal tidak menampilkan pesan error [FAIL] satupun, diakhiri dengan pesan sukses "[M0] Environment check completed", dan file toolchain-versions.txt berhasil di-generate di dalam folder build/meta/.]
```

### Langkah 2 — Uji Kompilasi Dasar (Smoke Test)

Maksud langkah:

```text
Langkah ini bertujuan untuk menguji fungsionalitas utama dari toolchain (khususnya kompiler Clang). Pengujian ini membuktikan bahwa kompiler mampu menerima instruksi C minimalis dan memproduksi file objek (object file) murni (freestanding) yang secara spesifik ditargetkan untuk arsitektur x86_64, tanpa bergantung pada library bawaan sistem operasi host.
```

Perintah:

```bash
make smoke
```

Output ringkas:

```text
[Menjalankan smoke test compile...
clang -target x86_64-pc-none-elf -ffreestanding -mno-red-zone -c smoke/smoke.c -o build/smoke/freestanding.o
 
=== BUKTI SMOKE TEST (READELF) ===
readelf -h build/smoke/freestanding.o
ELF Header:
  Magic:   7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00
  Class:                             ELF64
  Data:                              2's complement, little endian
  Version:                           1 (current)
  OS/ABI:                            UNIX - System V
  Machine:                           Advanced Micro Devices X86-64
 
=== BUKTI SMOKE TEST (FILE) ===
file build/smoke/freestanding.o
build/smoke/freestanding.o: ELF 64-bit LSB relocatable, x86-64, version 1 (SYSV), not stripped]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[smoke.c]` | `[smoke/]` | `[Berisi kode fungsi C minimalis (dummy_function) sebagai bahan uji coba kompilasi.]` |
| `[freestanding.o]` | `[build/smoke/]` | `[File objek hasil kompilasi murni yang siap ditautkan (linked) menjadi kernel di masa depan.]` |

Indikator berhasil:

```text
[Langkah dinyatakan berhasil secara objektif apabila proses kompilasi tidak menghasilkan error, dan output dari perintah validasi menunjukkan identitas mesin yang tepat, yaitu "Class: ELF64" dan "Machine: Advanced Micro Devices X86-64".]
```


---

## 11. Checkpoint Buildable

Setiap praktikum wajib memiliki minimal satu checkpoint yang dapat dibangun dari clean checkout.

| Checkpoint | Perintah | Expected result | Status |
|---|---|---|---|
| Clean build | `make clean && make smoke` | `build/smoke/freestanding.o terbangun` | `PASS` |
| Metadata toolchain | `make meta` | `build/meta/toolchain-versions.txt ada` | `PASS` |
| Image generation | `make image` | `mcsos.iso/mcsos.img ada` | `NA` |
| QEMU smoke test | `make run` | `serial log stage marker` | `NA` |
| Test suite | `make test` | `semua test relevan lulus` | `NA` |

Catatan checkpoint:

```text
[Status NA (Not Applicable) diberikan pada target image, run, dan test karena pada tahap Modul 0 ini (Inisiasi Baseline Environment), kode sumber kernel sistem operasi belum diimplementasikan sama sekali. Oleh karena itu:
1. Tidak ada kernel yang bisa di-build menjadi OS Image (.iso / .img).
2. Tidak ada binary OS yang bisa dieksekusi dan di-boot oleh emulator QEMU.
3. Test suite utama belum tersedia; pengujian murni hanya mengandalkan uji kompilasi dasar (smoke test) dan validasi toolchain (make meta) yang keduanya telah berstatus PASS.]
```
---

## 12. Perintah Uji dan Validasi

### 12.1 Build Test

Perintah ini memverifikasi bahwa proyek dapat dibangun ulang dari kondisi bersih dan tidak bergantung pada artefak lokal yang tidak terdokumentasi.


```bash
make clean
make smoke
```

Hasil:

```text
[rm -rf build/
Menjalankan smoke test compile...
mkdir -p build/smoke
clang -target x86_64-pc-none-elf -ffreestanding -mno-red-zone -c smoke/smoke.c -o build/smoke/freestanding.o
 
=== BUKTI SMOKE TEST (READELF) ===
readelf -h build/smoke/freestanding.o
ELF Header:
  Class:                             ELF64
  Machine:                           Advanced Micro Devices X86-64
 
=== BUKTI SMOKE TEST (FILE) ===
file build/smoke/freestanding.o
build/smoke/freestanding.o: ELF 64-bit LSB relocatable, x86-64, version 1 (SYSV), not stripped]
```

Status: `[PASS]`

### 12.2 Static Inspection

Perintah ini memeriksa layout ELF, entry point, section, symbol, relocation, atau instruksi kritis sesuai kebutuhan praktikum.

```bash
# Tidak dijalankan pada tahap Modul 0
```

Hasil penting:

```text
[Tidak ada output. Inspeksi statis dasar (validasi Class ELF64 dan tipe Machine x86-64) telah diwakili oleh pengujian readelf dan file pada file objek murni (freestanding.o) di tahap 12.1 Build Test.]
```

Status: `[NA]`

### 12.3 QEMU Smoke Test

Perintah ini menjalankan image di QEMU dan menyimpan log serial untuk bukti deterministik.

```bash
# Tidak dijalankan pada tahap Modul 0
```

Hasil:

```text
[Tidak ada log serial yang dihasilkan. Tahapan ini ditangguhkan hingga modul praktikum berikutnya ketika kernel dasar (M1) selesai diimplementasikan dan dikompilasi menjadi OS Image yang valid.]
```

Status: `[NA]`

### 12.4 GDB Debug Evidence

Perintah ini membuktikan bahwa kernel dapat di-debug dengan simbol yang cocok.

bash
[Tidak dijalankan pada tahap Modul 0]


Di terminal lain:

[ Tidak dijalankan pada tahap Modul 0]

Hasil:

```text
[Tidak ada output. Pengujian debugging akan ditangguhkan hingga modul praktikum selanjutnya.]
```

Status: `[NA]`

### 12.5 Unit Test

```bash
Tidak dijalankan pada tahap Modul 0
```

Hasil:

```text
[Tidak ada output unit test.]
```

Status: `[NA]`

### 12.6 Stress/Fuzz/Fault Injection Test

Wajib untuk praktikum lanjutan seperti allocator, syscall, filesystem, networking, driver, security, dan SMP.

```bash
[# Tidak dijalankan pada tahap Modul 0]
```

Hasil:

```text
[Tidak ada output pengujian beban/fuzzing.]
```

Status: `[NA]`

### 12.7 Visual Evidence

Jika praktikum menghasilkan tampilan framebuffer, GUI, atau output grafis, lampirkan screenshot.

| Screenshot | Lokasi file | Keterangan |
|---|---|---|
| `[NA]` | `[NA]` | `[Belum ada implementasi sistem visual, framebuffer, maupun interaksi GUI pada praktikum persiapan Modul 0.]` |

---

## 13. Hasil Uji

### 13.1 Tabel Ringkasan Hasil

| No. | Uji | Expected result | Actual result | Status | Evidence |
|---|---|---|---|---|---|
| 1 | `Validasi Toolchain (make meta)` | `Skrip berjalan tanpa error, menghasilkan file toolchain-versions.txt` | `Lingkungan memenuhi syarat, file metadata berhasil dibuat di build/meta/` | `PASS` | `build/meta/toolchain-versions.txt` |
| 2 | `Smoke Test Kompilasi (make smoke)` | `smoke.c terkompilasi menjadi *freestanding object* berarsitektur ELF64 x86-64` | `Kompilasi sukses, utilitas readelf dan file mengonfirmasi target mesin dengan benar` | `PASS` | `build/smoke/freestanding.o` |

### 13.2 Log Penting

```text
=== LOG MAKE META (Validasi Lingkungan) ===
[OK] git                /usr/bin/git
[OK] make               /usr/bin/make
[OK] clang              /usr/bin/clang
[OK] qemu-system-x86_64 /usr/bin/qemu-system-x86_64
[M0] Metadata written to build/meta/toolchain-versions.txt
[M0] Environment check completed.

=== LOG SMOKE TEST (Uji Kompilasi) ===
clang -target x86_64-pc-none-elf -ffreestanding -mno-red-zone -c smoke/smoke.c -o build/smoke/freestanding.o
readelf -h build/smoke/freestanding.o
  Class:                             ELF64
  Machine:                           Advanced Micro Devices X86-64
```

### 13.3 Artefak Bukti

| Artefak | Path | SHA-256 / hash | Fungsi |
|---|---|---|---|
| `freestanding.o` | `[build/smoke/freestanding.o]` | `[hash]` | `[Bukti file objek hasil kompilasi C tanpa dependensi host OS (smoke test)]` |
| `toolchain-versions.txt` | `[build/meta/toolchain-versions.txt]` | `[hash]` | `[Catatan versi alat kompilasi untuk menjaga sifat reproducible]` |
| `kernel.elf` | `[N/A]` | `[N/A]` | `[N/A (Belum tersedia di Modul 0)]` |
| `mcsos.iso / mcsos.img` | `[N/A]` | `[N/A]` | `[N/A (Belum tersedia di Modul 0)]` |
| `qemu-serial.logt` | `[N/A]` | `[N/A]` | `[N/A (Belum tersedia di Modul 0)]` |

Perintah hash:

```bash
sha256sum [path/artefak]
```

---
## 14. Analisis Teknis

### 14.1 Analisis Keberhasilan

Hasil uji kompilasi dasar (*smoke test*) dan validasi *environment* berhasil dengan status PASS. Keberhasilan ini sesuai dengan desain *invariant* yang ditetapkan, yaitu mewajibkan penggunaan *compiler flag* `-ffreestanding` dan target arsitektur `x86_64-pc-none-elf`. *Output log* dari utilitas `readelf` secara objektif membuktikan bahwa *file* objek yang dihasilkan (`freestanding.o`) murni menargetkan mesin bare-metal X86-64 (ELF-64) dan berhasil melepaskan diri dari dependensi *library* standar (libc) milik sistem operasi *host* Ubuntu/WSL.

### 14.2 Analisis Kegagalan atau Perbedaan Hasil

Pada proses praktikum, sempat terjadi kegagalan saat menjalankan perintah inspeksi repositori (seperti `git log --oneline` dan `git diff --stat`) yang memunculkan pesan error: `fatal: not a git repository (or any of the parent directories): .git`. 
* **Akar masalah:** Posisi terminal eksekusi (*Working Directory*) berada di direktori *home* (`~`), bukan di dalam direktori proyek yang memiliki inisiasi Git (`~/src/mcsos`).
* **Tindakan perbaikan:** Melakukan navigasi ulang ke direktori yang tepat menggunakan perintah `cd ~/src/mcsos` sebelum menjalankan perintah Git. Selain itu, untuk melihat bukti *diff* dari artefak yang sudah di-*commit*, perintah disesuaikan menggunakan `git show --stat`.

### 14.3 Perbandingan dengan Teori

| Konsep teori | Implementasi praktikum | Sesuai/tidak sesuai | Penjelasan |
|---|---|---|---|
| `*Cross-compilation*` | `Clang dengan target x86_64-pc-none-elf` | `Sesuai` | `Kompilasi dilakukan di atas OS *host* (Linux/WSL) namun spesifik menghasilkan *binary* untuk lingkungan yang tidak memiliki OS bawaan.` |
| `*Bare-metal environment*` | `Penggunaan flag -ffreestanding dan -mno-red-zone` | `Sesuai` | `Mencegah kompilator menyertakan fungsi C standar eksternal dan mematikan optimasi memori yang bisa merusak *stack* saat perangkat keras memicu interupsi (IRQ).` |
| `*Reproducible Build*` | `Eksekusi skrip check_env.sh dan Makefile` | `Sesuai` | `Lingkungan dipastikan seragam dan tercatat metadatanya (toolchain-versions.txt) agar kompilasi menghasilkan artefak yang identik di mesin mana pun.` |

### 14.4 Kompleksitas dan Kinerja

*Catatan: Parameter kompleksitas algoritma dan kinerja runtime (QEMU/Memori) mayoritas bernilai N/A karena Modul 0 murni membahas inisiasi lingkungan build tanpa implementasi logika kernel atau eksekusi sistem operasi.*

| Aspek | Estimasi/hasil | Bukti | Catatan |
|---|---|---|---|
| Kompleksitas algoritma | `N/A` | `N/A` | `Belum ada implementasi algoritma kernel pada Modul 0.` |
| Waktu build | `< 1 detik` | `Observasi visual pada terminal` | `Kompilasi satu buah *file* C tunggal (smoke.c) berjalan seketika tanpa *overhead linking* yang berat.` |
| Waktu boot QEMU | `N/A` | `N/A` | `OS Image belum dikonstruksi.` |
| Penggunaan memori | `N/A` | `N/A` | `Belum ada manajemen halaman memori (*paging*) atau alokasi dinamis.` |
| Latensi/throughput | `N/A` | `N/A` | `Belum ada pengujian performa *system call* atau *interrupt*.` |

## 15. Debugging dan Failure Modes

### 15.1 Failure Modes yang Ditemukan

| Failure mode | Gejala | Penyebab sementara | Bukti | Perbaikan |
|---|---|---|---|---|
| `Kesalahan Konteks Direktori Git` | `Perintah inspeksi repositori (git log, git diff) ditolak oleh sistem.` | `Eksekusi terminal berada di luar *working directory* proyek (berada di *home* `~` alih-alih ~/src/mcsos).` | `Output terminal: fatal: not a git repository (or any of the parent directories): .git` | `Melakukan navigasi ulang menggunakan perintah cd ~/src/mcsos sebelum menjalankan perintah Git.` |

### 15.2 Failure Modes yang Diantisipasi

| Failure mode | Deteksi | Dampak | Mitigasi |
|---|---|---|---|
| `Injeksi Fungsi Host (Ketidakcocokan ABI)` | `Muncul pesan *undefined reference* saat tahap *linking* jika ada pemanggilan library C standar.` | `Kernel berpotensi memanggil fungsi dari OS *host* yang akan menyebabkan *crash* fatal saat dijalankan di atas *bare-metal*.` | `Menegakkan penggunaan *flag* kompilator  -ffreestanding secara konsisten di dalam Makefile`. |
| `Toolchain Tidak Lengkap/Usang` | `Pesan *error* `[FAIL]` saat menjalankan pengecekan lingkungan kerja.` | `Proses kompilasi akan gagal atau menghasilkan *binary* yang tidak sesuai standar (*non-reproducible*).` | `Mewajibkan eksekusi target make meta (menjalankan `check_env.sh`) sebelum kompilasi untuk memvalidasi versi Clang, Make, dan QEMU.` |

### 15.3 Triage yang Dilakukan

```text
Pada tahap Modul 0, urutan diagnosis (triage) berfokus pada level sistem operasi host (Linux/WSL) karena kernel belum dieksekusi:
1. Inspeksi Output Terminal (Standard Error): Membaca log kegagalan secara langsung dari output eksekusi GNU Make.
2. Pengecekan Lingkungan (Environment Check): Memverifikasi working directory (pwd) dan status file sistem jika terjadi error akses atau command not found.
3. Static Analysis: Menggunakan ShellCheck untuk mendeteksi potensi kerentanan dan anomali sintaks pada skrip otomatisasi build sebelum dijalankan.
```

### 15.4 Panic Path

Jika terjadi panic, tempel output panic.

```text
[Belum relevan untuk Modul 0. Mekanisme penanganan kesalahan kritis (Panic Handler) dan pencetakan log ke serial/VGA belum diimplementasikan karena kode runtime kernel belum ditulis. Kegagalan saat ini hanya berupa "halt" pada proses kompilasi (Makefile exit code > 0).]
```

## 16. Prosedur Rollback

Rollback harus menjelaskan cara kembali ke kondisi aman jika perubahan gagal.

| Skenario rollback | Perintah | Data yang harus diselamatkan | Status |
|---|---|---|---|
| Kembali ke commit awal | `git checkout 1391b13` | `Tidak ada (repositori baru diinisiasi)` | `Belum` |
| Revert commit praktikum | `git revert HEAD` | `Tidak ada` | `Belum` |
| Bersihkan artefak build | `make clean` | `Kode sumber utama (.c, .sh, Makefile) aman` | `Teruji` |
| Regenerasi image | `make image` | `N/A (Belum ada OS image pada tahap M0)` | `NA` |

Catatan rollback:

```text
[Prosedur rollback pada tingkat sistem build (make clean) telah diuji pada tahap pengujian build test (Bab 12.1) dan terbukti berhasil menghapus seluruh direktori build/ secara aman tanpa memengaruhi atau merusak file source code utama. 

Sebaliknya, prosedur rollback pada tingkat version control (Git checkout / revert) belum diuji coba. Hal ini disebabkan karena repositori praktikum baru saja diinisiasi dan hanya memiliki satu commit awal (baseline commit: 1391b13). Belum ada riwayat perubahan (history) yang panjang untuk dijadikan target kembalian. Risikonya saat ini sangat rendah (hampir tidak ada) karena jika kode M0 rusak, proyek dapat diinisiasi ulang dari awal dengan cepat. Skenario regenerasi OS Image ditandai NA karena target kompilasi pada M0 murni hanya menghasilkan object file, bukan image sistem operasi yang dapat di-boot]
```

---

## 17. Keamanan dan Reliability

### 17.1 Risiko Keamanan

*Catatan: Karena Modul 0 belum mengimplementasikan kode runtime kernel, risiko keamanan tingkat sistem operasi (seperti invalid pointer atau privilege escalation) belum berlaku. Tabel ini menganalisis risiko keamanan pada batas (boundary) lingkungan kompilasi.*

| Risiko | Boundary | Dampak | Mitigasi | Evidence |
|---|---|---|---|---|
| `Injeksi *Library* Host OS` | `Lingkungan Kompilasi (Kompilator)` | `Hasil kompilasi tidak murni *bare-metal*; kernel bergantung pada fungsi OS *host* dan rentan mengalami kegagalan fatal saat di-booting mandiri.` | `Penegakan *compiler flag* -ffreestanding pada *toolchain*.` | `Review Makefile dan hasil inspeksi readelf pada *smoke test*.` |
| `Kerentanan Eksekusi *Script*` | `Sistem Otomasi *Build* (Bash)` | `Eksekusi perintah berbahaya yang tidak disengaja di dalam lingkungan WSL pengguna akibat kelemahan penulisan skrip (seperti *command injection*).` | `Penggunaan *static analyzer* (ShellCheck) untuk memvalidasi *script* prasyarat kompilasi.` | `Review target make check dan isi skrip check_env.sh`. |

### 17.2 Reliability dan Data Integrity

*Catatan: Keandalan (reliability) pada tahap ini difokuskan pada integritas lingkungan pengembangan dan jaminan bahwa proyek selalu dapat direproduksi (reproducible).*

| Risiko reliability | Dampak | Deteksi | Mitigasi |
|---|---|---|---|
| `*Non-reproducible Build* (Ketidakkonsistenan *Environment*)` | `Kode berhasil di-kompilasi di satu mesin, namun gagal atau menghasilkan *binary* yang berbeda di mesin lain karena perbedaan versi alat kerja.` | `Skrip check_env.sh dan target make meta`. | `Otomasi pencatatan metadata *toolchain* ke dalam berkas toolchain-versions.txt sebelum kompilasi utama dijalankan.` |
| `Polusi Artefak pada repositori Git` | `File *binary* berukuran besar atau file sementara (temporary) ikut ter-commit, menyebabkan *repository bloating* dan konflik *merge* yang merusak integritas *source code*.` | `Pengecekan status *working tree* (git status)`. | `Penerapan aturan pengabaian file yang ketat dan spesifik melalui .gitignore (mencakup folder build/ dan file .o).` |

### 17.3 Negative Test

*Catatan: Pengujian negatif tingkat kernel (seperti memberikan input packet jaringan yang korup) belum dapat dilakukan. Skenario di bawah mewakili pengujian negatif teoritis pada sistem build.*

| Negative test | Input buruk | Expected result | Actual result | Status |
|---|---|---|---|---|
| `Validasi *environment* tanpa Clang` | `Lingkungan *host* (WSL) di mana program clang dihapus atau *path*-nya diubah.` | `Skrip check_env.sh mendeteksi anomali, mencetak pesan `[FAIL]`, dan segera menghentikan rantai kompilasi (Make *error*).` | `N/A (Tidak diuji secara langsung karena lingkungan *host* saat ini sudah sehat dan lengkap)` | `NA` |
| `Kompilasi *smoke test* tanpa flag *freestanding*` | `Kode smoke.c berisi fungsi standar C (mis. printf) namun dikompilasi tanpa *library* pendukung.` | `Kompilator/Linker akan menolak proses dengan pesan peringatan *undefined reference*.` | `N/A (Tidak diuji karena Makefile sudah dikonfigurasi secara ketat dan aman)` | `NA` |

---
## 18. Pembagian Kerja Kelompok

Isi bagian ini hanya jika praktikum dikerjakan berkelompok. Untuk pengerjaan individu, tulis “Tidak berlaku”.

| Nama | NIM | Peran | Kontribusi teknis | Commit/artefak |
|---|---|---|---|---|
| `Muhamad Nabil` | `2583207073017` | `Ketua / Implementasi` | `Pembangunan skrip bash dan lainya di terminal wsl.` | `2e39289` |
| `Marko Ali Musa` | `25842074006` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `2e39289` |
| `Muharam Alfarizi` | `25832074002` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `2e39289` |

### 18.1 Mekanisme Koordinasi

```text
[```text
Koordinasi kelompok dilakukan secara terpusat dengan pembagian tugas yang spesifik. Seluruh pengembangan arsitektur OS, modifikasi skrip Bash, pengujian di lingkungan Linux WSL, dan eksekusi emulator QEMU dikerjakan secara eksklusif oleh Ketua Kelompok (Nabil). Repositori utama dikelola secara lokal. 

Sementara itu, proses penyusunan laporan dikerjakan oleh Anggota (Marko dan Muharam) dengan cara mengumpulkan log terminal, mengompilasi screenshot Framebuffer, dan menyusun format Markdown sesuai standar yang diminta.]
```

### 18.2 Evaluasi Kontribusi

| Anggota | Persentase kontribusi yang disepakati | Bukti | Catatan |
|---|---:|---|---|
| `[Muhamad Nabil]` | `[100%]` | `[Log Git, Source Code, Skrip Bash]` | `[bekerja dengan baik]` |
| `[Marko Ali Musa]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |
| `[Muharam Alfarizi]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |

---

## 19. Kriteria Lulus Praktikum

Bagian ini wajib diisi. Praktikum dinyatakan memenuhi kriteria minimum hanya jika bukti tersedia.

| Kriteria minimum | Status | Evidence |
|---|---|---|
| Proyek dapat dibangun dari clean checkout | `[PASS/FAIL]` | `[log]` |
| Perintah build terdokumentasi | `[PASS/FAIL]` | `[bagian laporan]` |
| QEMU boot atau test target berjalan deterministik | `[PASS/FAIL/NA]` | `[serial log/test log]` |
| Semua unit test/praktikum test relevan lulus | `[PASS/FAIL]` | `[test result]` |
| Log serial disimpan | `[PASS/FAIL/NA]` | `[path]` |
| Panic path terbaca atau dijelaskan jika belum relevan | `[PASS/FAIL]` | `[log/analisis]` |
| Tidak ada warning kritis pada build | `[PASS/FAIL]` | `[build log]` |
| Perubahan Git terkomit | `[PASS/FAIL]` | `[commit hash]` |
| Desain dan failure mode dijelaskan | `[PASS/FAIL]` | `[bagian laporan]` |
| Laporan berisi screenshot/log yang cukup | `[PASS/FAIL]` | `[lampiran]` |

Kriteria tambahan untuk praktikum lanjutan:

| Kriteria lanjutan | Status | Evidence |
|---|---|---|
| Static analysis dijalankan | `[PASS/FAIL/NA]` | `[cppcheck/clang-tidy log]` |
| Stress test dijalankan | `[PASS/FAIL/NA]` | `[log]` |
| Fuzzing atau malformed-input test dijalankan | `[PASS/FAIL/NA]` | `[log]` |
| Fault injection dijalankan | `[PASS/FAIL/NA]` | `[log]` |
| Disassembly/readelf evidence tersedia | `[PASS/FAIL/NA]` | `[objdump/readelf]` |
| Review keamanan dilakukan | `[PASS/FAIL/NA]` | `[security table]` |
| Rollback diuji | `[PASS/FAIL/NA]` | `[rollback log]` |

---

## 20. Readiness Review

Pilih satu status dengan alasan berbasis bukti.

| Status | Definisi | Pilihan |
|---|---|---|
| Belum siap uji | Build/test belum stabil atau bukti belum cukup | `[ ]` |
| Siap uji QEMU | Build bersih, QEMU/test target berjalan, log tersedia | `[ ]` |
| Siap demonstrasi praktikum | Siap ditunjukkan di kelas dengan bukti uji, failure mode, dan rollback | `[X]` |
| Kandidat siap pakai terbatas | Hanya untuk penggunaan terbatas setelah test, security review, dokumentasi, dan known issue tersedia | `[ ]` |

Alasan readiness:

```text
Status "Siap demonstrasi praktikum" dipilih karena lingkungan pengembangan (development environment) telah terbukti stabil dan dapat direproduksi (reproducible). Hal ini dibuktikan secara objektif melalui eksekusi target `make meta` yang sukses memvalidasi versi toolchain, serta target `make smoke` yang berhasil menghasilkan file freestanding object (.o) murni untuk arsitektur x86_64-pc-none-elf tanpa bergantung pada library host OS.
```

Known issues:

| No. | Issue | Dampak | Workaround | Target perbaikan |
|---|---|---|---|---|
| 1 | `[Keterikatan pada platform host (WSL2/Ubuntu)]` | `[Proses kompilasi tidak dapat dilakukan secara langsung (native) di Command Prompt/PowerShell Windows.]` | `[Pengembang wajib memastikan layanan WSL 2 berjalan dan mengeksekusi perintah Makefile dari dalam terminal Ubuntu.]` | `[Diterima sebagai batasan desain (By Design) sejak M0.]` |
| 2 | `[Ketiadaan OS Image]` | `[Emulator QEMU belum dapat mendemonstrasikan proses booting.]` | `[Fokus M0 murni pada toolchain statis. Pengujian eksekusi ditangguhkan.]` | `[Modul Praktikum 1 (M1)]` |

Keputusan akhir:

```text
[Berdasarkan bukti kompilasi statis (smoke test), validasi skrip toolchain (check_env.sh), dan ketersediaan prosedur rollback yang teruji (make clean), hasil praktikum Modul 0 ini secara meyakinkan layak disebut "Siap demonstrasi praktikum". Lingkungan pengembangan telah terisolasi dengan standar yang ketat, sehingga repositori ini siap dan aman untuk digunakan sebagai fondasi penulisan kode kernel sesungguhnya pada milestone berikutnya (Modul 1).”]
```

---

## 21. Rubrik Penilaian 100 Poin

| Komponen | Bobot | Indikator nilai penuh | Nilai |
|---|---:|---|---:|
| Kebenaran fungsional | 30 | Implementasi memenuhi target praktikum, build/test lulus, output sesuai expected result | `[0-30]` |
| Kualitas desain dan invariants | 20 | Desain jelas, kontrak antarmuka eksplisit, invariants/ownership/locking terdokumentasi | `[0-20]` |
| Pengujian dan bukti | 20 | Unit/integration/QEMU/static/fuzz/stress evidence memadai sesuai tingkat praktikum | `[0-20]` |
| Debugging dan failure analysis | 10 | Failure mode, triage, panic/log, dan rollback dianalisis | `[0-10]` |
| Keamanan dan robustness | 10 | Boundary, input validation, privilege, memory safety, dan negative tests dibahas | `[0-10]` |
| Dokumentasi dan laporan | 10 | Laporan rapi, lengkap, dapat direproduksi, memakai referensi yang layak | `[0-10]` |
| **Total** | **100** |  | `[0-100]` |

Catatan penilai:

```text
[Diisi dosen/asisten.]
```

---

## 22. Kesimpulan

### 22.1 Yang Berhasil
## 22. Kesimpulan

### 22.1 Yang Berhasil

```text
Lingkungan pengembangan (toolchain) untuk pembuatan sistem operasi bare-metal telah berhasil diinisiasi dan divalidasi di dalam subsistem WSL 2 (Ubuntu). Keberhasilan ini dibuktikan melalui eksekusi skrip check_env.sh yang mendokumentasikan metadata toolchain secara konsisten. Selain itu, proses kompilasi dasar (smoke test) berhasil memproduksi artefak freestanding.o dengan target arsitektur x86_64-pc-none-elf tanpa adanya injeksi library bawaan dari sistem operasi host, sesuai dengan verifikasi dari utilitas readelf dan file. Sistem Makefile juga telah berhasil menjamin proses build yang reproducible dan aman dari polusi artefak (make clean).
```

### 22.2 Yang Belum Berhasil

```text
[Mengingat praktikum ini merupakan Modul 0 yang berfokus eksklusif pada penyiapan lingkungan kerja statis, pembuatan OS Image (seperti mcsos.iso atau mcsos.img) yang dapat di-booting belum terealisasi. Selain itu, pengujian dinamis menggunakan emulator QEMU, eksekusi runtime kernel, serta proses debugging interaktif menggunakan GDB belum dapat dilakukan karena absennya kode sumber (source code) kernel utama dan instruksi penautan (linker script).]
```

### 22.3 Rencana Perbaikan

```text
[Langkah terukur selanjutnya untuk milestone praktikum berikutnya (Modul 1) meliputi:
1. Implementasi kode sumber kernel dasar (kernel_main) dan entry point arsitektur.
2. Penyusunan Linker Script kustom (.ld) untuk menautkan file objek menjadi file binary eksekusi kernel (kernel.elf) dengan tata letak memori yang presisi.
3. Pembaruan Makefile dengan menambahkan target kompilasi 'make image' untuk membungkus kernel.elf ke dalam format bootable ISO/IMG menggunakan bootloader yang kompatibel.
4. Pengujian booting dinamis menggunakan emulator QEMU (make run) untuk memastikan eksekusi berhasil mencapai environment kernel.]
```

---

## 23. Lampiran

### Lampiran A — Commit Log

```text
1391b13 (HEAD -> main) feat(m0): inisialisasi baseline environment, toolchain check, dan Makefile smoke test
```

### Lampiran B — Diff Ringkas

```diff
[--- /dev/null
+++ b/smoke/smoke.c
@@ -0,0 +1,4 @@
+// Dummy function untuk menguji kompilasi freestanding
+void dummy_function(void) {
+    // Tidak melakukan apa-apa, murni untuk menguji Clang
+}.]
```

### Lampiran C — Log Build Lengkap

```text
[$ make clean && make meta && make smoke
rm -rf build/
./tools/check_env.sh
[OK] git                /usr/bin/git
[OK] make               /usr/bin/make
[OK] clang              /usr/bin/clang
[OK] qemu-system-x86_64 /usr/bin/qemu-system-x86_64
[M0] Writing toolchain metadata
[M0] Metadata written to build/meta/toolchain-versions.txt
[M0] Environment check completed.
Menjalankan smoke test compile...
mkdir -p build/smoke
clang -target x86_64-pc-none-elf -ffreestanding -mno-red-zone -c smoke/smoke.c -o build/smoke/freestanding.o]
```

### Lampiran D — Log QEMU Lengkap

```text
[N/A. Praktikum Modul 0 belum mengimplementasikan eksekusi image sistem operasi menggunakan QEMU.]
```

### Lampiran E — Output Readelf/Objdump

```text
[$ readelf -h build/smoke/freestanding.o
ELF Header:
  Magic:   7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00
  Class:                             ELF64
  Data:                              2's complement, little endian
  Version:                           1 (current)
  OS/ABI:                            UNIX - System V
  ABI Version:                       0
  Type:                              REL (Relocatable file)
  Machine:                           Advanced Micro Devices X86-64
  Version:                           0x1
  Entry point address:               0x0
  Start of program headers:          0 (bytes into file)
  Start of section headers:          248 (bytes into file)
  Flags:                             0x0
  Size of this header:               64 (bytes)
  Size of program headers:           0 (bytes)
  Number of program headers:         0
  Size of section headers:           64 (bytes)
  Number of section headers:         6
  Section header string table index: 1]
```

### Lampiran F — Screenshot

| No. | File | Keterangan |
|---|---|---|
| 1 | `[N/A]` | `[Tidak ada output visual/GUI pada Modul 0.]` |

### Lampiran G — Bukti Tambahan

```text
[[Isi dari file build/meta/toolchain-versions.txt sebagai bukti reproducible build]

--- TOOLCHAIN VERSIONS ---
Date: Wed Jun 10 09:25:27 WIB 2026
OS: Linux (WSL2 / Ubuntu)

git version:
git version 2.43.0

make version:
GNU Make 4.3

clang version:
Ubuntu clang version 18.1.3

qemu version:
QEMU emulator version 8.2.2]
```

---

## 24. Daftar Referensi

Gunakan format IEEE. Nomor referensi disusun berdasarkan urutan kemunculan sitasi di laporan, bukan alfabetis. Contoh format:

```text
[1] R. H. Arpaci-Dusseau and A. C. Arpaci-Dusseau, Operating Systems: Three Easy Pieces. Madison, WI, USA: Arpaci-Dusseau Books, [tahun/edisi yang digunakan]. [Online]. Available: [URL]. Accessed: [tanggal akses].

[2] R. Cox, F. Kaashoek, and R. Morris, “xv6: a simple, Unix-like teaching operating system,” MIT PDOS. [Online]. Available: [URL]. Accessed: [tanggal akses].

[3] Intel Corporation, Intel 64 and IA-32 Architectures Software Developer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[4] Advanced Micro Devices, AMD64 Architecture Programmer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[5] UEFI Forum, Unified Extensible Firmware Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].

[6] ACPI Specification Working Group, Advanced Configuration and Power Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].
```

Referensi yang benar-benar dipakai dalam laporan:

```
[1] LLVM Project, "Clang Compiler User's Manual," LLVM Documentation. [Online]. Available: https://clang.llvm.org/docs/UsersManual.html. Accessed: Jun. 10, 2026.

[2] H. J. Lu et al., "System V Application Binary Interface AMD64 Architecture Processor Supplement (Draft Version 1.0)," x86-64 ABI. [Online]. Available: https://gitlab.com/x86-psABIs/x86-64-ABI. Accessed: Jun. 10, 2026.

[3] Free Software Foundation, "GNU Make Manual," GNU Project. [Online]. Available: https://www.gnu.org/software/make/manual/make.html. Accessed: Jun. 10, 2026.
```

## 25. Checklist Final Sebelum Pengumpulan

| Checklist | Status |
|---|---|
| Semua placeholder `[isi ...]` sudah diganti | `Ya` |
| Metadata laporan lengkap | `Ya` |
| Commit awal dan akhir dicatat | `Ya` |
| Perintah build dan test dapat dijalankan ulang | `Ya` |
| Log build dilampirkan | `Ya` |
| Log QEMU/test dilampirkan | `Ya` `(Ditandai N/A untuk M0)` |
| Artefak penting diberi hash | `Ya` |
| Desain, invariants, ownership, dan failure modes dijelaskan | `Ya` |
| Security/reliability dibahas | `Ya` |
| Readiness review tidak berlebihan | `Ya` |
| Rubrik penilaian diisi atau disiapkan | `Ya` |
| Referensi memakai format IEEE | `Ya` |
| Laporan disimpan sebagai Markdown | `Ya` |

---

## 26. Pernyataan Pengumpulan

Saya mengumpulkan laporan ini bersama artefak pendukung pada commit:

```text
[1391b13]

Status akhir yang diklaim:

```text
[Siap demonstrasi praktikum]
```

Ringkasan satu paragraf:

```text
[Laporan Praktikum Modul 0 ini mendokumentasikan inisiasi dan validasi lingkungan pengembangan (toolchain) sistem operasi bare-metal di dalam WSL 2 Ubuntu. Bukti utama keberhasilan meliputi ter-generate-nya metadata toolchain yang terverifikasi dan kesuksesan kompilasi (smoke test) file objek murni (freestanding.o) berarsitektur x86_64-pc-none-elf tanpa dependensi OS host. Keterbatasan pada tahap ini adalah belum adanya kode sumber kernel utama, sehingga proses penautan (linking) menjadi OS image dan pengujian booting dinamis via emulator QEMU belum dapat dieksekusi. Langkah realistis berikutnya untuk Modul 1 mencakup implementasi kode entry point kernel dasar, pembuatan linker script kustom, serta otomasi pembuatan bootable ISO.]
```
