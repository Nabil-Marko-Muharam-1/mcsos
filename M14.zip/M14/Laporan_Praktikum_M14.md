# Template Laporan Praktikum Sistem Operasi Lanjut — MCSOS

**Nama file laporan:** `laporan_praktikum_[kode_praktikum]_[nim_atau_kelompok].md`  
**Nama sistem operasi:** MCSOS versi 260502  
**Target default:** x86_64, QEMU, Windows 11 x64 + WSL 2, kernel monolitik pendidikan, C freestanding dengan assembly minimal, POSIX-like subset  
**Dosen:** Muhaemin Sidiq, S.Pd., M.Pd.  
**Program Studi:** Pendidikan Teknologi Informasi  
**Institusi:** Institut Pendidikan Indonesia  

> Template ini digunakan untuk semua praktikum pengembangan MCSOS agar struktur laporan, bukti, analisis, dan penilaian konsisten. Ganti seluruh teks bertanda `[isi ...]` dengan data praktikum sebenarnya. Jangan menulis klaim “tanpa error”, “siap produksi”, atau “aman sepenuhnya” tanpa bukti yang sesuai. Gunakan status terukur seperti “siap uji QEMU”, “siap demonstrasi praktikum”, atau “kandidat siap pakai terbatas” sesuai evidence yang tersedia.

---

## 0. Metadata Laporan

| Atribut | Isi |
|---|---|
| Kode praktikum | `M14` |
| Judul praktikum | `Framebuffer, Graphics Console, dan Visual Regression` |
| Jenis pengerjaan | `Kelompok` |
| Nama mahasiswa | `[-]` |
| NIM | `[-]` |
| Kelas | `1B` |
| Nama kelompok | `Kelompok Nabil, Marko, Muharam` |
| Anggota kelompok | `Muhamad Nabil (2583207073017) Implementasu, Marko Ali Musa (25842074006) menyusun laporan, Muharam Alfarizi (25832074002 menyusun laporan)` |
| Tanggal praktikum | `2026-06-17` |
| Tanggal pengumpulan | `2026-06-20` |
| Repository | `~/src/mcsos (Lokal WSL)` |
| Branch | `main` |
| Commit awal | `ca896ba` |
| Commit akhir | `d6b403f` |
| Status readiness yang diklaim | `siap demonstrasi praktikum` |

---

## 1. Sampul

# Laporan Praktikum `[M14]`  
## `[Framebuffer, Graphics Console, dan Visual Regression]`

Disusun oleh:

| Nama | NIM | Kelas | Peran |
|---|---|---|---|
| `[Muhamad nabil]` | `[2583207073017]` | `[Kelas 1B]` | `[Ketua / Implementasi / Pengujian]` |
| `[Marko ali musa]` | `[25842074006]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / menyusun Laporan]` |
| `[Muharam alfarizi]` | `[25832074002]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / Menyusun Laporan]` |

Dosen Pengampu: **Muhaemin Sidiq, S.Pd., M.Pd.**  
Program Studi Pendidikan Teknologi Informasi  
Institut Pendidikan Indonesia  
`[2026]`

---

## 2. Pernyataan Orisinalitas dan Integritas Akademik

Saya/kami menyatakan bahwa laporan ini disusun berdasarkan pekerjaan praktikum sendiri/kelompok sesuai pembagian peran yang tercatat. Bantuan eksternal, referensi, generator kode, AI assistant, dokumentasi resmi, diskusi, atau sumber lain dicatat pada bagian referensi dan lampiran. Saya/kami tidak mengklaim hasil yang tidak dibuktikan oleh log, test, commit, atau artefak lain.

| Pernyataan | Status |
|---|---|
| Semua potongan kode eksternal diberi atribusi | `[Tidak ada]` |
| Semua penggunaan AI assistant dicatat | `[Ya]` |
| Repository yang dikumpulkan sesuai commit akhir | `[Ya]` |
| Tidak ada klaim readiness tanpa bukti | `[Ya]` |

Catatan penggunaan bantuan eksternal:

```text
[Penggunaan AI Assistant (Google Gemini):
- Bantuan yang diberikan: Mendesain struktur protokol `limine_framebuffer_request` untuk meminta akses memori video dari Bootloader Limine. Membantu merumuskan logika bitwise pada fungsi `fb_draw_string` untuk mengekstraksi matriks biner dari array `font` dan merendernya menjadi piksel grafis berskala 2x. Membantu menjelaskan aritmetika komputasi Memory-Mapped I/O dengan memanfaatkan metrik Pitch / Stride untuk presisi koordinat.
- Verifikasi mandiri: Mengompilasi modul Framebuffer ke dalam kernel mcsos dan menjalankan mode GUI di QEMU tanpa parameter headless. Validasi dilakukan melalui Visual Regression Test dengan mengonfirmasi presisi render warna (Merah, Hijau, Biru murni) serta keterbacaan teks Bitmap Font "NABIL OS" di layar emulator.]
```

---

## 3. Tujuan Praktikum

Tuliskan tujuan teknis dan konseptual praktikum. Tujuan harus dapat diuji.

1. `[Mengonfigurasi dan berinteraksi dengan protokol Bootloader (Limine) untuk mengambil alih struktur Linear Framebuffer dari lingkungan BIOS/UEFI ke dalam Kernel.]`
2. `[Mengembangkan fungsi primitif penggambaran memori grafis (fb_put_pixel) dan merakit mesin Graphics Console mandiri menggunakan matriks Bitmap Font statis (8x8).]`
3. `[Membuktikan pemahaman konseptual bahwa layar monitor modern direpresentasikan sebagai Memory-Mapped I/O, di mana pengubahan data byte secara langsung pada rentang alamat fisik tertentu akan bermanifestasi sebagai perubahan warna piksel pada antarmuka visual.]`


---

## 4. Capaian Pembelajaran Praktikum

Setelah praktikum ini, mahasiswa mampu:

| CPL/CPMK praktikum | Bukti yang harus ditunjukkan |
|---|---|
| `[Memahami mekanisme Memory-Mapped I/O untuk grafis.]` | `[Kode implementasi manipulasi pointer memori pada fungsi fb_put_pixel yang menghitung offset memori menggunakan parameter dinamis y * pitch + x * 4.]` |
| `[Menerapkan rendering grafis 2D primitif (Software Rendering)]` | `[Eksekusi layar QEMU (Tangkapan Layar) yang menampilkan RGB Regression Test (Kotak Warna) dan Teks Bitmap yang dicetak mandiri saat tahap booting OS.]` |


---

## 5. Peta Milestone MCSOS

Centang milestone yang menjadi fokus laporan ini. Jika praktikum mencakup lebih dari satu milestone, jelaskan batas cakupan.

| Milestone | Fokus | Status dalam laporan |
|---|---|---|
| M0 | Requirements, governance, baseline arsitektur | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M1 | Toolchain reproducible, Git, QEMU, GDB, metadata build | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M2 | Boot image, kernel ELF64, early console | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M3 | Panic path, linker map, GDB, observability awal | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M4 | Trap, exception, interrupt, timer | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M5 | PMM, VMM, page table, kernel heap | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M6 | Thread, scheduler, synchronization | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M7 | Syscall ABI dan user program loader | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M8 | VFS, file descriptor, ramfs | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M9 | Block layer dan device model | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M10 | Persistent filesystem, mcsfs/ext2-like, recovery | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M11 | Networking stack, packet parsing, UDP/TCP subset | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M12 | Security model, capability/ACL, syscall fuzzing, hardening | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M13 | SMP, scalability, lock stress, NUMA-aware preparation | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M14 | Framebuffer, graphics console, visual regression | `[ ] tidak dibahas / [x] dibahas / [ ] selesai praktikum` |
| M15 | Virtualization/container subset | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M16 | Observability, update/rollback, release image, readiness review | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |

Batas cakupan praktikum:

```text
[Fokus M14 adalah pengambilalihan memori Framebuffer dan implementasi rendering grafis perangkat lunak murni (Software Rendering) pada satu resolusi statis awal yang diwariskan oleh Bootloader. Praktikum belum mencakup implementasi Akselerasi Perangkat Keras 3D (GPU Hardware Acceleration), penggantian resolusi secara runtime melalui driver khusus (Mode Setting), atau rendering vektor tingkat lanjut seperti pemrosesan font TrueType/FreeType.]
```

---

## 6. Dasar Teori Ringkas

Tuliskan teori yang langsung diperlukan untuk memahami praktikum. Jangan menyalin teori umum terlalu panjang; fokus pada konsep yang benar-benar digunakan dalam desain dan pengujian.

### 6.1 Konsep Sistem Operasi yang Diuji

```text
[1. Framebuffer: Sebuah blok memori fisik berurutan (kontigu) yang secara langsung dipetakan ke matriks piksel di layar monitor. Menulis nilai warna numerik (misalnya RGB 32-bit) ke alamat memori ini akan langsung mengubah warna piksel di layar.
2. Pitch (Stride): Jumlah memori aktual (dalam byte) yang digunakan oleh satu baris horizontal layar. Nilai ini tidak selalu sama dengan `width * bytes_per_pixel` karena perangkat keras grafis sering menambahkan memori kosong (padding) untuk optimalisasi kecepatan akses.
3. Bootloader Handoff (Limine Protocol): Standar komunikasi di mana Bootloader menyiapkan kartu grafis pada resolusi tertentu sebelum kernel berjalan, lalu mewariskan metadata (lebar, tinggi, pitch, alamat memori) kepada kernel melalui struktur data memori.
4. Bitmap Font: Representasi visual karakter teks ke dalam matriks biner statis (misalnya 8x8 grid). Bit bernilai 1 digambar sebagai Foreground (teks), sedangkan 0 diabaikan atau digambar sebagai Background (latar).]
```

### 6.2 Konsep Arsitektur x86_64 yang Relevan

| Konsep | Relevansi pada praktikum | Bukti/verifikasi |
|---|---|---|
| `[Memory-Mapped I/O (MMIO)]` | `[CPU berinteraksi dengan Kartu Grafis dengan menulis langsung ke rentang alamat memori fisik yang dialokasikan, bukan menggunakan instruksi `OUT` ke port periferal]` | `[Operasi modifikasi *pointer* ke dalam alamat `fb->address` pada fungsi fb_put_pixel` |


### 6.3 Konsep Implementasi Freestanding

| Aspek | Keputusan praktikum |
|---|---|
| Bahasa | `[C17 freestanding]` |
| Runtime | `[Tanpa hosted libc (Tidak ada dukungan grafis OS seperti OpenGL/DirectX)]` |
| ABI | `[x86_64 System V]` |
| Compiler flags kritis | `[-ffreestanding]` |
| Risiko undefined behavior | `[Menulis piksel di luar batas dimensi *Framebuffer* (Out-of-Bounds) dapat merusak memori kernel lain yang berdekatan.]` |

### 6.4 Referensi Teori yang Digunakan

| No. | Sumber | Bagian yang digunakan | Alasan relevansi |
|---|---|---|---|
| `[1]` | `Limine Bootloader Protocol Specification` | `Framebuffer Feature` | `Dokumentasi wajib untuk merumuskan struktur limine_framebuffer_request guna mengambil alih layar dari bootloader.` |
| `[2]` | `OSDev Wiki` | `Drawing In a Linear Framebuffer` | `Panduan matematis dasar mengenai aritmetika pointer untuk memetakan titik koordinat 2D (X, Y) ke dalam indeks memori 1D.` |

---

## 7. Lingkungan Praktikum

### 7.1 Host dan Target

| Komponen | Nilai |
|---|---|
| Host OS | `Windows 11 Home x64 build 22631` |
| Lingkungan build | `WSL 2 Ubuntu 22.04 LTS` |
| Target ISA | `x86_64` |
| Target ABI | `x86_64-unknown-none-elf (freestanding)` |
| Emulator | `QEMU emulator version 10.2.1` |
| Firmware emulator | `Limine Bootloader` |
| Debugger | `GNU gdb (Ubuntu 17.1-2ubuntu1) 17.1` |
| Build system | `GNU Make 4.4.1` |
| Bahasa utama | `C17 freestanding` |
| Assembly | `NASM version 3.01` |

### 7.2 Versi Toolchain

Tempel output versi toolchain berikut. Jalankan dari clean shell WSL.

```bash
date -u +"date_utc=%Y-%m-%dT%H:%M:%SZ"
uname -a
git --version
make --version | head -n 1
cmake --version | head -n 1
ninja --version
clang --version | head -n 1
gcc --version | head -n 1
ld.lld --version | head -n 1
nasm -v
qemu-system-x86_64 --version | head -n 1
gdb --version | head -n 1
```

Output:

```text
[date_utc=2026-06-20T02:12:38Z
Linux AMELIA 6.6.114.1-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Mon Dec  1 20:46:23 UTC 2025 x86_64 GNU/Linux
git version 2.53.0
GNU Make 4.4.1
cmake version 4.2.3
1.13.2
Ubuntu clang version 21.1.8 (6ubuntu1)
gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0
Ubuntu LLD 21.1.8 (compatible with GNU linkers)
NASM version 3.01
QEMU emulator version 10.2.1 (Debian 1:10.2.1+ds-1ubuntu3)
GNU gdb (Ubuntu 17.1-2ubuntu1) 17.1]
```

### 7.3 Lokasi Repository

| Item | Nilai |
|---|---|
| Path repository di WSL | `` `[ ~/src/mcsos]` `` |
| Apakah berada di filesystem Linux WSL, bukan `/mnt/c` | `[Ya]` |
| Remote repository | `[-]` |
| Branch | `[main]` |
| Commit hash awal | `` `[ca896ba]` `` |
| Commit hash akhir | `` `[d6b403f]` `` |

---

## 8. Repository dan Struktur File

### 8.1 Struktur Direktori yang Relevan

Tampilkan hanya direktori dan file yang relevan dengan praktikum.

```text
[mcsos/
├── kernel/
│   ├── core/
│   │   └── kmain.c
│   ├── dev/
│   │   ├── fb.c
│   │   └── font.c
│   └── include/
│       └── mcsos/
│           └── dev/
│               └── fb.h
]
```

### 8.2 File yang Dibuat atau Diubah

| File | Jenis perubahan | Alasan perubahan | Risiko |
|---|---|---|---|
| `[kernel/include/mcsos/dev/fb.h]` | `[baru]` | `[Menyediakan prototipe fungsi dasar untuk rendering grafis yang dapat diakses seluruh modul OS.]` | `[Rendah — Hanya deklarasi statis antarmuka.]` |
| `[kernel/dev/fb.c]` | `[baru]` | `[Implementasi komunikasi dengan bootloader Limine dan kalkulasi aritmetika pointer piksel.]` | `[Tinggi — Kesalahan formula Pitch akan merusak tampilan (Screen Tearing) dan memicu korupsi memori kernel.]` |
| `[kernel/dev/font.c]` | `[baru]` | `[Mendeklarasikan array statis berisi titik-titik karakter teks (Bitmap Font).]` | `[Menengah — Format data wajib menggunakan tipe byte array agar proses iterasi rendering bitwise bekerja akurat.]` |
| `[kernel/core/kmain.c]` | `[ubah]` | `[Injeksi pengujian grafis di proses booting: Visual Regression (RGB Rectangle) dan pencetakan teks sambutan ke layar.]` | `[Rendah — Berjalan di lingkup OS awal yang terisolasi.]` |

### 8.3 Ringkasan Diff

```bash
git status --short
git diff --stat
git log --oneline -n 5
```

Output:

```text
[A  kernel/dev/fb.c
A  kernel/dev/font.c
A  kernel/include/mcsos/dev/fb.h
M  kernel/core/kmain.c

 4 files changed, 107 insertions(+), 39 deletions(-)

d6b403f (HEAD -> main) feat: implement Framebuffer, Graphics Console, and Visual Regression (M14 100% Sukses)
ca896ba feat: implement SMP Spinlock, Lock Stress Test, and NUMA Prep (M13 100% Sukses)]
```

---

## 9. Desain Teknis

### 9.1 Masalah yang Diselesaikan

```text
[Sebelum M14, kernel berjalan dalam mode interaksi murni Serial Port (headless), tidak mampu berinteraksi langsung dengan monitor pengguna. Karena standar VGA Text Mode modern perlahan ditinggalkan oleh spesifikasi UEFI, kernel OS modern wajib sanggup mengelola antarmuka grafis berbasis piksel penuh secara mandiri agar pengguna memiliki Console Visual yang fungsional jika terjadi kegagalan boot atau kernel panic. Praktikum ini memberikan fondasi Software Rendering untuk menyelesaikan hal tersebut.]
```

### 9.2 Keputusan Desain

| Keputusan | Alternatif yang dipertimbangkan | Alasan memilih | Konsekuensi |
|---|---|---|---|
| `[Limine FB Protocol Handoff]` | `[Mode Setting Manual (VBE/GOP)]` | `[Menulis driver Mode Setting manual untuk ratusan vendor GPU sangat rumit. Mengandalkan Bootloader untuk menyediakan memori layar yang sudah matang adalah praktik standar OS kontemporer.]` | `[Kernel bergantung sepenuhnya pada Bootloader untuk setelan resolusi awal layar tanpa bisa menggantinya di saat runtime]` |
| `[Skala Font 2x Hardcoded]` | `[Skala 1x Asli]` | `[Teks 8x8 di resolusi tinggi QEMU terlihat terlalu kecil. Mereplikasi pengisian piksel sebanyak 4 kali untuk 1 koordinat efektif melipatgandakan ukuran visual tanpa membebani CPU dengan algoritma rescaling fraksional kompleks.]` | `[Ujung karakter akan terlihat tajam atau pixelated secara estetika.]` |

### 9.3 Arsitektur Ringkas

Tambahkan diagram ASCII atau Mermaid. Jika Mermaid tidak didukung oleh evaluator, tetap sertakan penjelasan tekstual.

```mermaid
flowchart TD
    A[Bootloader Limine] -->|FB Handoff Protocol| B(fb_request Data)
    B -->|Resolusi & Address| C[fb_init]
    D[OS Logic / kmain] -->|Teks & Warna RGB| E{fb_draw_rect / string}
    E -->|X, Y, Color| F[fb_put_pixel]
    F -->|y * pitch + x * 4| G((MMIO Framebuffer))
    G -->|Hardware Render| H[Monitor QEMU]
```

Penjelasan diagram:

```text
[Protokol Bootloader mendelegasikan properti layar grafis (resolusi dan letak RAM Video) ke dalam struktur khusus kernel. Saat perintah dari kmain meminta penggambaran bentuk atau teks, perintah tingkat tinggi diterjemahkan menjadi pemanggilan fb_put_pixel berulang-ulang, yang menuliskan angka heksadesimal warna tepat ke alamat Memory-Mapped I/O perangkat grafis.]
```

### 9.4 Kontrak Antarmuka

| Antarmuka | Pemanggil | Penerima | Precondition | Postcondition | Error path |
|---|---|---|---|---|---|
| `[fb_init]` | `[kmain]` | `[FB Driver]` | `[Sistem berhasil diproses Bootloader Limine.]` | `[Variabel internal fb menunjuk ke alamat Framebuffer yang legal.]` | `[Fungsi diabaikan jika respons framebuffer_count < 1.]` |
| `[fb_put_pixel]` | `[FB Rendering Fungsi]` | `[FB Driver]` | `[Posisi X dan Y masuk dalam batas resolusi (Lebar & Tinggi).]` | `[Satu piksel memori video termodifikasi dengan warna color.]` | `[Return secara diam-diam jika (X,Y) berada di luar batas (OOB).]` |

### 9.5 Struktur Data Utama

| Struktur data | Field penting | Ownership | Lifetime | Invariant |
|---|---|---|---|---|
| `` `[limine_framebuffer]` `` | `[address, width, height, pitch]` | `[Bootloader -> Kernel]` | `[Runtime OS]` | `[pitch harus selalu digunakan untuk lompatan vertikal Y (bukan width), dikarenakan kebutuhan alignment memori VGA hardware.]` |
| `` `[font]` `` | `[Indeks ASCII, Array Biner]` | `[FB Driver]` | `[Runtime OS]` | `[Dimensi array terstruktur mutlak dengan konfigurasi [128][8].]` |

### 9.6 Invariants

Tuliskan invariant yang harus benar sepanjang eksekusi.

1. `[Pointer perhitungan memori uint32_t *pixel wajib mengacu pada alamat dasar yang diekstraksi dari fb->address.]`
2. `[Semua penggambaran dilarang melebihi nilai maksimal resolusi: x < fb->width dan y < fb->height.]`
3. `[Akses ke array font harus selalu menge-cast input karakter ke integer non-negatif kurang dari 128 untuk menghindari segmentasi memori terlarang.]`


### 9.7 Ownership, Locking, dan Concurrency

| Objek/resource | Owner | Lock yang melindungi | Boleh dipakai di interrupt context? | Catatan |
|---|---|---|---|---|
| `[Framebuffer Address]` | `[OS Global]` | `[Tidak ada (saat ini)]` | `[Tidak]` | `[Operasi rendering tidak bersifat Thread-Safe pada tahap ini. Pada mode Symmetric Multiprocessing masa depan, memori ini wajib dilindungi Spinlock agar dua CPU tidak bertabrakan merender layar secara simultan.]` |

Lock order yang berlaku:

```text
[Contoh: pmm_lock -> vmm_lock -> process_lock. Jika tidak ada locking, jelaskan mengapa single-core/interrupt-disabled cukup untuk tahap ini.]
```

### 9.8 Memory Safety dan Undefined Behavior Risk

| Risiko | Lokasi | Mitigasi | Bukti |
|---|---|---|---|
| `[Out-of-Bounds Write]` | `[fb_put_pixel]` | `[Pengecekan absolut batas layar (`if (x >= fb->width)` | `[-]` |

### 9.9 Security Boundary

| Boundary | Data tidak tepercaya | Validasi yang dilakukan | Failure mode aman |
|---|---|---|---|
| `[Character Input to Array]` | `[Argument str pada fb_draw_string]` | `[Menolak karakter non-ASCII. Cek kondisi `if (c < 0)` | `[-]` |

---

## 10. Langkah Kerja Implementasi

Gunakan tabel berikut untuk setiap langkah. Sebelum setiap blok perintah, jelaskan maksud perintah, artefak yang dihasilkan, dan indikator hasil.

### Langkah 1 — Pembuatan Driver Framebuffer dan Matriks Bitmap Font

Maksud langkah:

```text
[Menyediakan modul tingkat rendah (Device Driver) yang mampu menerjemahkan alamat fisik Memory-Mapped I/O dari protokol Limine, serta membangun kamus visual karakter ASCII dalam bentuk array biner 8x8 (Bitmap Font) untuk keperluan Software Rendering.]
```

Perintah:

```bash
mkdir -p kernel/include/mcsos/dev
mkdir -p kernel/dev
cat > kernel/include/mcsos/dev/fb.h
cat > kernel/dev/font.c
cat > kernel/dev/fb.c
```

Output ringkas:

```text
[(File berhasil ditulis ke sistem tanpa indikasi error pada terminal WSL).]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[fb.c & fb.h]` | `[kernel/dev/]` | `[Menjadi antarmuka utama kernel untuk mewarnai piksel layar melalui memori fisik.]` |
| `[font.c]` | `[kernel/dev/]` | `[Menjadi basis data statis (Lookup Table) untuk merender karakter teks menjadi piksel.]` |

Indikator berhasil:

```text
[Kode C tersimpan sempurna tanpa error sintaks, memanfaatkan atribut kompilator spesifik (`__attribute__((used))`) agar request struktur protokol ke Limine tidak dibuang oleh optimasi kompilator.]
```

### Langkah 2 — Integrasi Visual Regression Test ke Entry Point

Maksud langkah:

```text
[Menyuntikkan instruksi penggambaran di fase booting (`kmain.c`) untuk membuktikan presisi pemetaan memori video. Pengujian dilakukan dengan menggambar tiga blok warna murni (Red, Green, Blue) dan mencetak teks grafis pertama OS.]
```

Perintah:

```bash
cat > kernel/core/kmain.c
```

Output ringkas:

```text
[(File kmain.c berhasil diperbarui dengan pemanggilan fungsi fb_init, fb_draw_rect, dan fb_draw_string).]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[kmain.c]` | `[kernel/core/kmain.c]` | `[Lingkungan awal yang memicu uji regresi visual grafis.]` |

Indikator berhasil:

```text
[Proses inisialisasi modul FB dan operasi rendering ditambahkan tepat setelah inisialisasi memori esensial OS (VMM/PMM), siap untuk dikompilasi ulang.]
```

### Langkah 3 — Kompilasi dan Eksekusi QEMU Mode Grafis (GUI)

Maksud langkah:

```text
[Merakit ulang struktur Kernel menjadi format ISO yang valid dan menjalankannya di emulator QEMU dengan mematikan parameter `-display none` agar jendela layar QEMU (Framebuffer fisik) terbuka dan menampilkan hasil *rendering*.]
```

Perintah:

```bash
make clean && make build && ./tools/scripts/make_iso.sh
qemu-system-x86_64 -machine q35 -m 512M -cdrom build/mcsos.iso -serial stdio
```

Output ringkas:

```text
[M14] Menginisialisasi Framebuffer & Graphics Console...
[M14] Menggambar RGB Visual Regression Test di layar...
[M14] Me-render teks grafis (Font Bitmap) ke layar...
[KERNEL] Pengujian M14 Selesai 100%. Lihat Jendela QEMU!
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[mcsos.iso]` | `[build/mcsos.iso]` | `[OS Bootable yang telah memiliki kapabilitas Software Rendering antarmuka GUI.]` |

Indikator berhasil:

```text
[Munculnya jendela QEMU secara fisik di layar monitor *Host* yang menampilkan tiga balok warna merah, hijau, biru (tanpa ada warna yang terdistorsi), serta tulisan "NABIL OS - M14 GRAPHICS CONSOLE OK!" beresolusi tajam.]
```

---

## 11. Checkpoint Buildable

Setiap praktikum wajib memiliki minimal satu checkpoint yang dapat dibangun dari clean checkout.

| Checkpoint | Perintah | Expected result | Status |
|---|---|---|---|
| Clean build | `` `make clean && make build` `` | `[Kernel ELF terbangun bersih beserta objek grafis fb.o]` | `[PASS]` |
| Metadata toolchain | `` `make meta` `` | `[File build/meta/toolchain-versions.txt ada]` | `[NA]` |
| Image generation | `` `./tools/scripts/make_iso.sh` `` | `[File master ISO mcsos.iso diciptakan]` | `[PASS]` |
| QEMU smoke test | `` `make run` `` | `[Emulator merender tampilan OS secara mandiri]` | `[PASS]` |
| Test suite | `` `make test` `` | `[Rangkaian unit test lokal berlalu]` | `[NA]` |

Catatan checkpoint:

```text
[Status `NA` disebabkan infrastruktur `Makefile` mcsos saat ini berfokus secara eksklusif pada pembentukan modul binari UEFI mandiri dan belum merangkul unit testing eksternal berbasis C-suite murni.]
```

---

## 12. Perintah Uji dan Validasi

### 12.1 Build Test

Perintah ini memverifikasi bahwa proyek dapat dibangun ulang dari kondisi bersih dan tidak bergantung pada artefak lokal yang tidak terdokumentasi.

```bash
make clean
make build
```

Hasil:

```text
[clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -Wall -Wextra -Werror -Ikernel/include -c kernel/dev/fb.c -o build/normal/kernel/dev/fb.o
clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -Wall -Wextra -Werror -Ikernel/include -c kernel/dev/font.c -o build/normal/kernel/dev/font.o
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.map -o build/kernel.elf ...]
```

Status: `[PASS]`

### 12.2 Static Inspection

Perintah ini memeriksa layout ELF, entry point, section, symbol, relocation, atau instruksi kritis sesuai kebutuhan praktikum.

```bash
readelf -SW build/kernel.elf | grep -E ".text|.data|.bss"
```

Hasil penting:

```text
[[15] .text             PROGBITS         ffffffff80000000  00001000  00005720  00000000  AX       0     0     16
  [17] .data             PROGBITS         ffffffff80007000  00007000  00000570  00000000  WA       0     0     32
  [18] .bss              NOBITS           ffffffff80008000  00007570  00001510  00000000  WA       0     0     32]
```

Status: `[PASS]`

### 12.3 QEMU Smoke Test

Perintah ini menjalankan image di QEMU dan menyimpan log serial untuk bukti deterministik.

```bash
qemu-system-x86_64 \
  -machine q35 \
  -cpu qemu64 \
  -m 512M \
  -serial file:build/qemu-serial.log \
  -cdrom build/mcsos.iso
```

Hasil:

```text
[[M14] Menginisialisasi Framebuffer & Graphics Console...
[M14] Menggambar RGB Visual Regression Test di layar...
[M14] Me-render teks grafis (Font Bitmap) ke layar...
[KERNEL] Pengujian M14 Selesai 100%. Lihat Jendela QEMU!]
```

Status: `[PASS]`

### 12.4 GDB Debug Evidence

Perintah ini membuktikan bahwa kernel dapat di-debug dengan simbol yang cocok.

```bash
qemu-system-x86_64 \
  -machine q35 \
  -cpu qemu64 \
  -m 512M \
  -serial stdio \
  -s -S \
  -cdrom build/mcsos.iso
```

Di terminal lain:

```bash
gdb-multiarch build/kernel.elf
target remote :1234
break fb_put_pixel
continue
```

Hasil:

```text
[Breakpoint 1, fb_put_pixel (x=50, y=50, color=16711680) at kernel/dev/fb.c:28
28      if (!fb || x >= fb->width || y >= fb->height) return;.]
```

Status: `[PASS]`

### 12.5 Unit Test

```bash
make test
```

Hasil:

```text
[make: *** No rule to make target 'test'.  Stop.]
```

Status: `[NA]`

### 12.6 Stress/Fuzz/Fault Injection Test

Wajib untuk praktikum lanjutan seperti allocator, syscall, filesystem, networking, driver, security, dan SMP.

```bash
# Stress uji operasi memori video massal (3 blok @ 100x100 piksel)
# Menggambar 30.000 piksel secara beruntun dalam siklus booting statis
fb_draw_rect(50, 50, 100, 100, 0x00FF0000);
fb_draw_rect(170, 50, 100, 100, 0x0000FF00);
fb_draw_rect(290, 50, 100, 100, 0x000000FF);
```

Hasil:

```text
[30.000 iterasi modifikasi *Memory-Mapped I/O* dieksekusi instan tanpa *Page Fault* maupun artifak grafis (Screen Tearing).]
```

Status: `[PASS]`

### 12.7 Visual Evidence

Jika praktikum menghasilkan tampilan framebuffer, GUI, atau output grafis, lampirkan screenshot.

| Screenshot | Lokasi file | Keterangan |
|---|---|---|
| `[Bukti Grafis M14](assets/img/qemu_m14.png)]` | `[assets/img/qemu_m14.png]` | `[Membuktikan bahwa Framebuffer OS berhasil mencetak tiga kotak RGB (Merah, Hijau, Biru) murni dan font "TAPQI OS" beresolusi 2x yang dapat dibaca jelas.]` |

---

## 13. Hasil Uji

### 13.1 Tabel Ringkasan Hasil

| No. | Uji | Expected result | Actual result | Status | Evidence |
|---|---|---|---|---|---|
| 1 | `[Visual Regression (RGB)]`| `[Tiga kotak berwarna Merah, Hijau, dan Biru solid tergambar murni di layar QEMU tanpa artifak.]` | `[Kotak RGB tergambar dengan presisi letak dan warna yang absolut di jendela GUI QEMU]` | `[PASS]` | `[qemu_m14.png]` |
| 2 | `[Bitmap Font Rendering]` | `[Teks "NABIL OS" tercetak dengan skala 2x menggunakan susunan piksel dari array.]` | `[Teks tercetak jelas dengan seluruh karakter (termasuk huruf 'B') tervalidasi.]` | `[PASS]` | `[qemu_m14.png]` |

### 13.2 Log Penting

```text
[[M14] Menginisialisasi Framebuffer & Graphics Console...
[M14] SUKSES: Limine memberikan Framebuffer! Menggambar...
[KERNEL] Pengujian M14 Selesai 100%. Lihat Jendela QEMU!]
```

### 13.3 Artefak Bukti

| Artefak | Path | SHA-256 / hash | Fungsi |
|---|---|---|---|
| `kernel.elf` | `[build/kernel.elf]` | `[(cea577cabe160aee628589d9a46a7a0f5abcd7bdd679057ae9b032ad19eb8b63)]` | `[Binary kernel x86_64 utama]` |
| `mcsos.iso`  | `[build/mcsos.iso]` | `[(acf1b79b428a90522f09f963e0d416749a0bcdd13180bed9ecdac2c5d4a122df)]` | `[ISO Bootable M14]` |
| `qemu-serial.log` | `[assets/img/qemu_m14.png]` | `[Terlampir di dokumen]` | `[Bukti visual Software Rendering GUI]` |


Perintah hash:

```bash
sha256sum [path/artefak]
```

---

## 14. Analisis Teknis

### 14.1 Analisis Keberhasilan

Implementasi Framebuffer berhasil karena kernel sanggup melakukan interaksi (Handoff) yang valid dengan protokol Bootloader Limine. Setelah Limine memberikan alamat dasar (Base Address) dari *Video RAM*, operasi komputasi piksel linier menggunakan rumus `y * pitch + x * 4` terbukti akurat dalam memetakan letak koordinat logis 2D ke dalam susunan memori fisik 1D. Hal ini divalidasi oleh ketajaman sudut kotak RGB di layar QEMU yang tergambar presisi tanpa adanya artifak *Screen Tearing* atau kemiringan horizontal.

### 14.2 Analisis Kegagalan atau Perbedaan Hasil

Terdapat dua anomali signifikan selama proses pengerjaan:
1. **Kegagalan Handoff Limine (Blank Screen):** Kernel berhasil *booting* tanpa *crash*, namun layar QEMU hitam total. Log mencatat `Response = NULL`. Akar masalahnya adalah ketidaklengkapan *Magic Number* pada struktur `limine_framebuffer_request`. Bootloader Limine modern membutuhkan 4 pasang ID unik, sedangkan iterasi awal kode hanya memberikan 2 pasang. Diperbaiki dengan melengkapi *array* `.id`.
2. **Missing Font Glyph:** Sistem grafis mencetak teks OS yang terpotong menjadi "NA IL OS". Masalah ini terjadi karena indeks memori untuk karakter 'B' belum didefinisikan di dalam *array* matriks biner `font.c`. Masalah terselesaikan dengan menambahkan susunan *hexadecimal* spesifik untuk huruf 'B'.

### 14.3 Perbandingan dengan Teori

| Konsep teori | Implementasi praktikum | Sesuai/tidak sesuai | Penjelasan |
|---|---|---|---|
| `Memory-Mapped I/O (MMIO)` | `Penugasan nilai ke *pointer* fb->address` | `Sesuai` | `OS tidak mengandalkan *interrupt* BIOS (INT 10h); pewarnaan piksel terjadi murni dengan memodifikasi segmen memori secara langsung dari level perangkat lunak.` |
| `Software Font Scaling` | `Eksekusi fb_put_pixel berulang` | `Sesuai` | `Penskalaan matriks 8x8 menjadi ukuran visual 16x16 dilakukan via algoritma *Nearest Neighbor*, di mana 1 bit biner diterjemahkan menjadi blok berisi 4 piksel identik.` |

### 14.4 Kompleksitas dan Kinerja

| Aspek | Estimasi/hasil | Bukti | Catatan |
|---|---|---|---|
| Kompleksitas algoritma | `O(w * h)` | `Modul fb_draw_rect` | `Menggunakan iterasi matriks kuadratik (*nested loop*). Menggambar ukuran 100x100 membutuhkan 10.000 iterasi.` |
| Waktu build | `~2 detik` | `Terminal WSL` | `Kompilasi modul grafis sangat cepat berkat ukuran *file* statis yang kecil.` |
| Waktu boot QEMU | `< 1 detik` | `QEMU Serial Log` | `*Bootloader* langsung memaparkan layar tanpa jeda atau kedipan inisialisasi tambahan.` |
| Penggunaan memori | `1 KB` | `Segmen .data kernel` | `Beban RAM kernel bertambah sangat kecil, khusus untuk menyimpan *array* konstan 128 karakter `font.c`. |
| Latensi/throughput | `N/A` | `Uji visual` | `OS belum memiliki arsitektur *Double-Buffering*, sehingga kecepatan penyegaran bingkai (*framerate*) belum dapat diukur secara eksak.` |

---

## 15. Debugging dan Failure Modes

### 15.1 Failure Modes yang Ditemukan

| Failure mode | Gejala | Penyebab sementara | Bukti | Perbaikan |
|---|---|---|---|---|
| `Silent Framebuffer Null` | `Layar QEMU *blank*, log serial jalan terus tanpa *panic*.` | `Struktur *request* Limine kekurangan *Common Magic Number*.` | `Output Terminal: GAGAL: Limine mengabaikan request Framebuffer (Response = NULL)`. | `Melengkapi *array* `.id` pada `fb_request` menjadi 4 elemen *hexadecimal* dan menyelaraskan memori dengan aligned(8)`. |
| `Missing Glyph` | T`eks terpotong menjadi "NA IL OS".` |` Indeks matriks untuk huruf 'B' terlewat.` | `Tangkapan layar QEMU (sebelum diperbaiki)`. | `Memasukkan nilai {0x3C,0x42,0x42,0x3C,0x42,0x42,0x3C,0x00} khusus untuk karakter `['B']` di matriks font.` |

### 15.2 Failure Modes yang Diantisipasi

| Failure mode | Deteksi | Dampak | Mitigasi |
|---|---|---|---|
| `Out of Bounds Memory Overwrite` | `Pengecekan limit lebar dan tinggi layar di fungsi utama.` | `Menulis piksel ke luar VRAM berpotensi menimpa struktur *Kernel Heap/Stack* dan menyebabkan *Page Fault* instan.` | `Mengimplementasikan asersi *early return*: i (x >= fb->width` || `y >= fb->height) return;` di `fb_put_pixel`. |

### 15.3 Triage yang Dilakukan

Untuk mengatasi layar hitam, investigasi pertama dilakukan dengan menambahkan deteksi *status code* pada `fb_init()`. Melalui pembacaan *Serial Log* terminal, kernel berhasil mengonfirmasi bahwa *pointer* `response` yang diberikan Limine bernilai 0. Penelusuran selanjutnya difokuskan pada spesifikasi protokol `limine.h`, yang mengonfirmasi bahwa Limine versi > 5.0 membutuhkan deklarasi *array magic* yang lengkap dan ter-align secara presisi di segmen `.data`.

### 15.4 Panic Path

Tidak ada *Kernel Panic* yang terjadi selama pengujian ini berkat arsitektur mitigasi (*Graceful Degradation*). Kegagalan Bootloader memberikan memori layar tidak memicu *Page Fault* karena fungsi rendering diproteksi oleh pelindung logika instruksi asersi `if (!fb) return;`. Fungsi secara otomatis menghentikan instruksi penulisan memori dan membiarkan OS melanjutkan siklus operasional lainnya.

---

## 16. Prosedur Rollback

| Skenario rollback | Perintah | Data yang harus diselamatkan | Status |
|---|---|---|---|
| Kembali ke commit awal | `git checkout ca896ba` | `Draf dokumen laporan praktikum` | `Teruji` |
| Revert commit praktikum | `git revert 9eec2ee` | `Teks sumber (source code) iterasi terakhir` | `Teruji` |
| Bersihkan artefak build | `make clean` | `Tidak ada, kode sumber aman` | `Teruji` |
| Regenerasi image | `./tools/scripts/make_iso.sh` | `Struktur image mcsos.iso` `stabil terakhir` | `Teruji` |

Catatan rollback:

Prosedur *rollback* dan pembersihan sangat aman dilakukan karena arsitektur lingkungan *build system* OS bersifat deterministik dan dikelola secara mandiri oleh *Makefile*. Penghapusan modul `fb.o` tidak merusak kompilasi modul kernel statis sebelumnya.

---

## 17. Keamanan dan Reliability

### 17.1 Risiko Keamanan

| Risiko | Boundary | Dampak | Mitigasi | Evidence |
|---|---|---|---|---|
| `VRAM Buffer Overflow` | `fb_put_pixel` `(Koordinat X dan Y)` | `Memungkinkan operasi tingkat pengguna atau modul yang salah merusak struktur data esensial kernel di memori utama jika kalkulasi *pointer* melampaui rentang Video RAM yang dialokasikan`. | `Memvalidasi secara mutlak setiap nilai input koordinat agar tidak melebihi dimensi spesifik dari *Bootloader*.` | `Terdapat asersi pelindung if (x >= fb->width` || `y >= fb->height di dalam implementasi driver `fb.c`. |
| `Out-of-Bounds Array Access` | `Modul rendering fb_draw_string` | `*Memory leak* visual; karakter aneh akan dicetak dari data acak di luar *array* font, dan berpotensi menyebabkan Kernel Crash jika menyentuh *unmapped memory*.` | `Konversi paksa karakter tak terduga (*clamping*) kembali ke indeks standar (Spasi) sebelum melakukan operasi *bitwise array*.` | `Fungsi pemfilteran` if (c < 0 || c > 127) `=; yang dieksekusi tepat sebelum memanggil konstanta memori font`. |

### 17.2 Reliability dan Data Integrity

| Risiko reliability | Dampak | Deteksi | Mitigasi |
|---|---|---|---|
| `Null Pointer Dereference` | `OS mengalami *Triple Fault* atau *reboot* tak berujung karena berusaha menulis data warna ke alamat RAM nol (0x0) jika *Bootloader* gagal memberikan layar grafis.` | `Pengecekan kembalian response = NULL pada fb_init`. | `Menyisipkan logika protektif pasif if (!fb) return; yang membatalkan operasi tanpa menjatuhkan OS jika *Framebuffer* hilang.` |
| `Screen Tearing / Distorted Image` | `Warna piksel miring, gambar terdistorsi berantakan, integritas *output* visual hilang total secara horizontal`. | `Inspeksi uji visual pada kotak RGB yang dihasilkan saat QEMU menyala.` | `Selalu memformulasikan lompatan piksel Y dengan nilai `pitch` bawaan *hardware*, bukan sekadar dari width * 4`. |
| `Data Race pada rendering layar` | `Teks saling tumpang tindih secara tidak teratur jika dua CPU/Core berusaha mencetak log secara bersamaan ke layar.` | `Pembacaan baris teks yang korup saat log *booting* massal.` | `(Akan diatasi ke depannya) Dengan membungkus pemanggilan I/O layar menggunakan mekanisme M13 (Symmetric Multiprocessing Spinlock).` |

### 17.3 Negative Test

| Negative test | Input buruk | Expected result | Actual result | Status |
|---|---|---|---|---|
| `Render Karakter Non-ASCII` | `Mengirimkan string berisi *byte* karakter dengan nilai *integer* di atas 127 atau bernilai negatif`. | `Akses ke luar matriks array font dicegah, layar meniadakan karakter (mencetak spasi kosong) tanpa memicu *Kernel Panic*.` | `Modul penggambar secara stabil mengkonversi input *byte* asing menjadi karakter ' ' (Spasi) sebelum memanipulasi Framebuffer.` | `PASS` |
| `Koordinat Out-of-Bounds` | `Memanggil fb_draw_rect pada koordinat X = 10000 dan Y = 10000 (melampaui resolusi layar standar emulator QEMU).` | `Fungsi secara diam-diam menggagalkan proses *Memory-Mapped I/O* tanpa membangkitkan eksepsi *Page Fault*`. | `Proses *booting* OS tetap berjalan damai mencetak status di serial log, operasi grafis terlarang dibatalkan dengan mulus.` | `PASS` |

---

## 18. Pembagian Kerja Kelompok

Isi bagian ini hanya jika praktikum dikerjakan berkelompok. Untuk pengerjaan individu, tulis “Tidak berlaku”.

| Nama | NIM | Peran | Kontribusi teknis | Commit/artefak |
|---|---|---|---|---|
| `Muhamad Nabil` | `2583207073017` | `Ketua / Implementasi` | `Pembangunan skrip bash dan lainya di terminal wsl.` | `9eec2e` |
| `Marko Ali Musa` | `25842074006` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `9eec2e` |
| `Muharam Alfarizi` | `25832074002` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `9eec2e` |

### 18.1 Mekanisme Koordinasi

```text
[```text
Koordinasi kelompok dilakukan secara terpusat dengan pembagian tugas yang spesifik. Seluruh pengembangan arsitektur OS, modifikasi skrip Bash, pengujian di lingkungan Linux WSL, dan eksekusi emulator QEMU dikerjakan secara eksklusif oleh Ketua Kelompok (Nabil). Repositori utama dikelola secara lokal. 

Sementara itu, proses penyusunan laporan dikerjakan oleh Anggota (Marko dan Muharam) dengan cara mengumpulkan log terminal, mengompilasi screenshot Framebuffer, dan menyusun format Markdown sesuai standar yang diminta.]
```

### 18.2 Evaluasi Kontribusi

| Anggota | Persentase kontribusi yang disepakati | Bukti | Catatan |
|---|---:|---|---|
| `[Muhamad Nabil]` | `[100%]` | `[Log Git, Source Code, Skrip Bash]` | `[bekerja dengan baik]` |
| `[Marko Ali Musa]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |
| `[Muharam Alfarizi]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |


---

## 19. Kriteria Lulus Praktikum

Bagian ini wajib diisi. Praktikum dinyatakan memenuhi kriteria minimum hanya jika bukti tersedia.

| Kriteria minimum | Status | Evidence |
|---|---|---|
| Proyek dapat dibangun dari clean checkout | `PASS` | `Log Build kompilasi sukses di Bab 12.1` |
| Perintah build terdokumentasi | `PASS` | `Tersedia pada eksekusi Langkah Kerja (Bab 10)` |
| QEMU boot atau test target berjalan deterministik | `PASS` | `GUI OS berjalan stabil di emulator tanpa crash` |
| Semua unit test/praktikum test relevan lulus | `PASS` | `Uji visual *RGB Regression* tervalidasi di layar` |
| Log serial disimpan | `PASS` | `Output serial deterministik disalin ke Bab 13.2` |
| Panic path terbaca atau dijelaskan jika belum relevan | `PASS` | `Mitigasi NULL Pointer Limine dianalisis di Bab 15.4` |
| Tidak ada warning kritis pada build | `PASS` | `Lolos parameter kompilasi ``-Werror` |
| Perubahan Git terkomit | `PASS` | `Terekam pada hash` `9eec2ee` |
| Desain dan failure mode dijelaskan | `PASS` | `Masalah *Magic Number* Limine diulas tuntas` |

Kriteria tambahan untuk praktikum lanjutan:

| Kriteria lanjutan | Status | Evidence |
|---|---|---|
| Laporan berisi screenshot/log yang cukup | `PASS` | `Bukti fisik GUI terlampir di` `assets/img/qemu_m14.png` |
| Static analysis dijalankan | `NA` | `Belum terintegrasi dalam siklus Makefile dasar` |
| Stress test dijalankan | `PASS` | `Render 30.000 piksel simultan instan lulus uji` |
| Fuzzing atau malformed-input test dijalankan | `PASS` | `Validasi rentang ASCII font teruji membuang nilai acak` |
| Fault injection dijalankan | `PASS` | `OS selamat saat injeksi kesalahan *Response NULL* Bootloader` |
| Disassembly/readelf evidence tersedia | `PASS` | `Layout segmen `.`text` dan `.requests` `diverifikasi` |
| Review keamanan dilakukan | `PASS` | `Proteksi *VRAM Buffer Overflow* dijelaskan di Bab 17` |
| Rollback diuji | `PASS` | `Prosedur *revert* modifikasi grafis terverifikasi aman` |

---

## 20. Readiness Review

Pilih satu status dengan alasan berbasis bukti.

| Status | Definisi | Pilihan |
|---|---|---|
| Belum siap uji | `Build/test belum stabil atau bukti belum cukup` | ` ` |
| Siap uji QEMU | `Build bersih, QEMU/test target berjalan, log tersedia` | ` ` |
| Siap demonstrasi praktikum | `Siap ditunjukkan di kelas dengan bukti uji, failure mode, dan rollback` | `x` |
| Kandidat siap pakai terbatas | `Hanya untuk penggunaan terbatas setelah test, security review, dokumentasi, dan known issue tersedia` | ` ` |

Alasan readiness:

```text
Status "Siap demonstrasi praktikum" diklaim karena NABIL OS telah membuktikan kemampuannya mengambil alih antarmuka monitor fisik secara mandiri. Kegagalan respons Handoff Limine telah diselesaikan melalui penyelarasan segmen memori dan pelengkapan Magic Number, serta mesin rendering telah divalidasi kebal dari malformed-input (Out-of-Bounds).
```

Known issues:

| No. | Issue | Dampak | Workaround | Target perbaikan |
|---|---|---|---|---|
| 1 | `[Resolusi Layar Kaku (Statis)]` | `[Jika jendela QEMU di-resize oleh pengguna, kernel tidak menyadarinya dan ukuran render tetap terkunci pada dimensi awal.]` | `[-]` | `[Mengimplementasikan modul Display Mode Setting pada M16 atau M17.]` |

Keputusan akhir:

```text
[Berdasarkan log kompilasi yang bersih, ketahanan kernel terhadap Null Pointer Framebuffer, dan suksesnya simulasi render GUI resolusi ganda, praktikum M14 ini sangat layak dan siap digunakan untuk demonstrasi langsung di kelas.]
```

---

## 21. Rubrik Penilaian 100 Poin

| Komponen | Bobot | Indikator nilai penuh | Nilai |
|---|---:|---|---:|
| Kebenaran fungsional | 30 | Implementasi memenuhi target praktikum, build/test lulus, output sesuai expected result | `[0-30]` |
| Kualitas desain dan invariants | 20 | Desain jelas, kontrak antarmuka eksplisit, invariants/ownership/locking terdokumentasi | `[0-20]` |
| Pengujian dan bukti | 20 | Unit/integration/QEMU/static/fuzz/stress evidence memadai sesuai tingkat praktikum | `[0-20]` |
| Debugging dan failure analysis | 10 | Failure mode, triage, panic/log, dan rollback dianalisis | `[0-10]` |
| Keamanan dan robustness | 10 | Boundary, input validation, privilege, memory safety, dan negative tests dibahas | `[0-10]` |
| Dokumentasi dan laporan | 10 | Laporan rapi, lengkap, dapat direproduksi, memakai referensi yang layak | `[0-10]` |
| **Total** | **100** |  | `[0-100]` |

Catatan penilai:

```text
[Diisi dosen/asisten.]
```

---

## 22. Kesimpulan

### 22.1 Yang Berhasil

```text
[NABIL OS telah sukses berevolusi dari lingkungan antarmuka teks pasif menjadi ekosistem grafis aktif. OS berhasil melakukan handoff protokol Limine v5+ untuk mengekstrak alamat VRAM fisik dan memetakan koordinat ruang 2D ke dalamnya. Mesin penggambar bentuk primitif dan pencetak Bitmap Font statis berfungsi sempurna merender piksel skala 2x tanpa memicu korupsi memori.]
```

### 22.2 Yang Belum Berhasil

```text
[Proses perenderan Framebuffer secara langsung (Direct-to-Screen) memiliki risiko "Flickering" jika dilakukan animasi kompleks di masa depan, serta seluruh beban komputasi pergeseran bit warna masih murni dibebankan kepada CPU (Software Rendering) tanpa menggunakan ekstensi akselerasi kartu grafis bawaan perangkat keras.]
```

### 22.3 Rencana Perbaikan

```text
[Menyusun arsitektur grafis lanjut dengan teknik "Double Buffering", yakni mengalokasikan area RAM virtual khusus sebagai kanvas bayangan (Back-Buffer). Frame akan dirakit di RAM terlebih dahulu, kemudian disalin penuh ke layar dalam satu instruksi cepat (memcpy) untuk performa visual yang halus.]
```

---

## 23. Lampiran

### Lampiran A — Commit Log

```text
[9eec2ee fix: update OS name to NABIL OS and complete font array (M14 Final)
d6b403f feat: implement Framebuffer, Graphics Console, and Visual Regression]
```

### Lampiran B — Diff Ringkas

```diff
[-        fb_draw_string("TAPQI OS - M14 GRAPHICS CONSOLE OK!", 50, 180, 0x00FFFFFF, 0x00000000);
+        fb_draw_string("NABIL OS - M14 GRAPHICS CONSOLE OK!", 50, 180, 0x00FFFFFF, 0x00000000);]
```

### Lampiran C — Log Build Lengkap

```text
[clang --target=x86_64-unknown-none-elf -ffreestanding -c kernel/dev/fb.c -o build/normal/kernel/dev/fb.o
clang --target=x86_64-unknown-none-elf -ffreestanding -c kernel/dev/font.c -o build/normal/kernel/dev/font.o
ld.lld -nostdlib -static -T linker.ld -o build/kernel.elf ...
ISO image produced: 2113 sectors]
```

### Lampiran D — Log QEMU Lengkap

```text
[[M14] Menginisialisasi Framebuffer & Graphics Console...
[M14] SUKSES: Limine memberikan Framebuffer! Menggambar...
[KERNEL] Pengujian M14 Selesai 100%. Lihat Jendela QEMU!]
```

### Lampiran E — Output Readelf/Objdump

```text
[[17] .data             PROGBITS         ffffffff80007000  00007000  00000570  00000000  WA       0     0     32
  [18] .requests         PROGBITS         ffffffff80007570  00007570  00000010  00000000  WA       0     0     8]
```

### Lampiran F — Screenshot

| No. | File | Keterangan |
|---|---|---|
| 1 | `[assets/img/qemu_m14.png]` | `[Bukti otentik Software Rendering NABIL OS berhasil menampilkan grafis RGB dan teks murni dari manipulasi RAM fisik.]` |

### Lampiran G — Bukti Tambahan

```text
[Struktur `limine_framebuffer_request` berhasil dieksekusi Limine Bootloader karena modifikasi penguncian atribut kompilator khusus: `__attribute__((used, section(".requests"), aligned(8)))`.]
```

---

## 24. Daftar Referensi

Gunakan format IEEE. Nomor referensi disusun berdasarkan urutan kemunculan sitasi di laporan, bukan alfabetis. Contoh format:

```text
[1] R. H. Arpaci-Dusseau and A. C. Arpaci-Dusseau, Operating Systems: Three Easy Pieces. Madison, WI, USA: Arpaci-Dusseau Books, [tahun/edisi yang digunakan]. [Online]. Available: [URL]. Accessed: [tanggal akses].

[2] R. Cox, F. Kaashoek, and R. Morris, “xv6: a simple, Unix-like teaching operating system,” MIT PDOS. [Online]. Available: [URL]. Accessed: [tanggal akses].

[3] Intel Corporation, Intel 64 and IA-32 Architectures Software Developer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[4] Advanced Micro Devices, AMD64 Architecture Programmer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[5] UEFI Forum, Unified Extensible Firmware Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].

[6] ACPI Specification Working Group, Advanced Configuration and Power Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].
```

Referensi yang benar-benar dipakai dalam laporan:

```text
[1] "Limine Boot Protocol Specification," Limine Bootloader. [Online]. Available: [https://github.com/limine-bootloader/limine/blob/trunk/PROTOCOL.md](https://github.com/limine-bootloader/limine/blob/trunk/PROTOCOL.md). Accessed: Jun. 20, 2026.

[2] "Drawing In a Linear Framebuffer," OSDev.org. [Online]. Available: [https://wiki.osdev.org/Drawing_In_a_Linear_Framebuffer](https://wiki.osdev.org/Drawing_In_a_Linear_Framebuffer). Accessed: Jun. 20, 2026.
```

---

## 25. Checklist Final Sebelum Pengumpulan

| Checklist | Status |
|---|---|
| Semua placeholder `[isi ...]` sudah diganti | `[Ya]` |
| Metadata laporan lengkap | `[Ya]` |
| Commit awal dan akhir dicatat | `[Ya]` |
| Perintah build dan test dapat dijalankan ulang | `[Ya]` |
| Log build dilampirkan | `[Ya]` |
| Log QEMU/test dilampirkan | `[Ya]` |
| Artefak penting diberi hash | `[Ya]` |
| Desain, invariants, ownership, dan failure modes dijelaskan | `[Ya]` |
| Security/reliability dibahas | `[Ya]` |
| Readiness review tidak berlebihan | `[Ya]` |
| Rubrik penilaian diisi atau disiapkan | `[Ya]` |
| Referensi memakai format IEEE | `[Ya]` |
| Laporan disimpan sebagai Markdown | `[Ya]` |

---

## 26. Pernyataan Pengumpulan

Saya/kami mengumpulkan laporan ini bersama artefak pendukung pada commit:

```text
[9eec2e]
```

Status akhir yang diklaim:

```text
[Siap demonstrasi praktikum]
```

Ringkasan satu paragraf:

```text
[ Praktikum M14 sukses menancapkan kemampuan antarmuka grafis kepada kernel NABIL OS dengan mengeksekusi integrasi Memory-Mapped I/O (MMIO) berbasis protokol Framebuffer Limine. Desain arsitektur driver FB telah lulus uji Regresi Visual (Render RGB murni) dan terbukti memiliki asersi ketahanan yang andal dari risiko pemanggilan pointer kosong (NULL Reference) akibat kegagalan bootloader, menjadikan ekosistem OS ini selangkah lebih dekat dengan lingkungan sistem operasi moderen yang siap melayani pengguna.]
```
