# Template Laporan Praktikum Sistem Operasi Lanjut — MCSOS

**Nama file laporan:** `laporan_praktikum_[kode_praktikum]_[nim_atau_kelompok].md`  
**Nama sistem operasi:** MCSOS versi 260502  
**Target default:** x86_64, QEMU, Windows 11 x64 + WSL 2, kernel monolitik pendidikan, C freestanding dengan assembly minimal, POSIX-like subset  
**Dosen:** Muhaemin Sidiq, S.Pd., M.Pd.  
**Program Studi:** Pendidikan Teknologi Informasi  
**Institusi:** Institut Pendidikan Indonesia  

> Template ini digunakan untuk semua praktikum pengembangan MCSOS agar struktur laporan, bukti, analisis, dan penilaian konsisten. Ganti seluruh teks bertanda `[isi ...]` dengan data praktikum sebenarnya. Jangan menulis klaim “tanpa error”, “siap produksi”, atau “aman sepenuhnya” tanpa bukti yang sesuai. Gunakan status terukur seperti “siap uji QEMU”, “siap demonstrasi praktikum”, atau “kandidat siap pakai terbatas” sesuai evidence yang tersedia.

---

## 0. Metadata Laporan

| Atribut | Isi |
|---|---|
| Kode praktikum | `M15` |
| Judul praktikum | `Virtualization dan Container Subset` |
| Jenis pengerjaan | `Kelompok` |
| Jenis pengerjaan | `Kelompok` |
| Nama mahasiswa | `[-]` |
| NIM | `[-]` |
| Kelas | `1B` |
| Nama kelompok | `Kelompok Nabil, Marko, Muharam` |
| Anggota kelompok | `Muhamad Nabil (2583207073017) Implementasu, Marko Ali Musa (25842074006) menyusun laporan, Muharam Alfarizi (25832074002 menyusun laporan)` |
| Tanggal praktikum | `2026-06-18` |
| Tanggal pengumpulan | `2026-06-18` |
| Repository | `~/src/mcsos (Lokal WSL)` |
| Branch | `main` |
| Commit awal | `[9eec2ee]` |
| Commit akhir | `[d2b3642]` |
| Status readiness yang diklaim | `siap demonstrasi praktikum` |

---

## 1. Sampul

# Laporan Praktikum `[M15]`  
## `[Virtualization dan Container Subset]`

Disusun oleh:

| Nama | NIM | Kelas | Peran |
|---|---|---|---|
| `[Muhamad nabil]` | `[2583207073017]` | `[Kelas 1B]` | `[Ketua / Implementasi / Pengujian]` |
| `[Marko ali musa]` | `[25842074006]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / menyusun Laporan]` |
| `[Muharam alfarizi]` | `[25832074002]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / Menyusun Laporan]` |

Dosen Pengampu: **Muhaemin Sidiq, S.Pd., M.Pd.**  
Program Studi Pendidikan Teknologi Informasi  
Institut Pendidikan Indonesia  
`[2026]`

---

## 2. Pernyataan Orisinalitas dan Integritas Akademik

Saya menyatakan bahwa laporan ini disusun berdasarkan pekerjaan praktikum mandiri. Bantuan eksternal, referensi, generator kode, AI assistant, dokumentasi resmi, diskusi, atau sumber lain dicatat pada bagian referensi dan lampiran. Saya tidak mengklaim hasil yang tidak dibuktikan oleh log, test, commit, atau artefak lain.

| Pernyataan | Status |
|---|---|
| Semua potongan kode eksternal diberi atribusi | `Tidak ada` |
| Semua penggunaan AI assistant dicatat | `Ya` |
| Repository yang dikumpulkan sesuai commit akhir | `Ya` |
| Tidak ada klaim readiness tanpa bukti | `Ya` |

Catatan penggunaan bantuan eksternal:
```text
Penggunaan AI Assistant (Google Gemini):
- Bantuan yang diberikan: Mendesain struktur data primitif `struct container` untuk mengelola ID dan Virtual Root FS (Jail Path). Membantu merumuskan logika spoofing (manipulasi identitas) di mana proses seolah-olah memiliki Virtual PID 1 untuk mensimulasikan lingkungan terisolasi OS-Level Virtualization.
- Verifikasi mandiri: Mengompilasi subsistem sekuriti baru ke dalam kernel NABIL OS. Validasi dilakukan melalui serial log yang membuktikan perpindahan konteks namespace dan dibuktikan di antarmuka grafis QEMU Framebuffer (M14) yang mencetak status hijau "OS-LEVEL CONTAINER ISOLATION: ACTIVE".
```

---

## 3. Tujuan Praktikum

Tuliskan tujuan teknis dan konseptual praktikum. Tujuan harus dapat diuji.

1. `[Memahami konsep dasar OS-Level Virtualization yang menjadi landasan teknologi Container modern (seperti Docker/LXC).]`
2. `[Mengimplementasikan struktur data Namespace primitif untuk melakukan isolasi direktori (Jail / Chroot) terhadap suatu entitas proses.]`
3. `[Mendemonstrasikan teknik Spoofing identitas, di mana proses yang berada di dalam Container diberi ilusi bahwa ia adalah proses pertama dalam sistem operasi (Virtual PID 1).]`

---

## 4. Capaian Pembelajaran Praktikum

Setelah praktikum ini, mahasiswa mampu:

| CPL/CPMK praktikum | Bukti yang harus ditunjukkan |
|---|---|
| `[Merancang subsistem isolasi proses (Container Jail).]` | `[Kode implementasi container_create yang memetakan proses ke Virtual Root FS (misal: /var/jail/web_server).]` |
| `[Mengaplikasikan manipulasi Namespace PID.]` | `[Log terminal Host OS yang mendemonstrasikan perubahan PID asli (misal: 405) menjadi Virtual PID 1 (Spoofed).]` |

---

## 5. Peta Milestone MCSOS

Centang milestone yang menjadi fokus laporan ini. Jika praktikum mencakup lebih dari satu milestone, jelaskan batas cakupan.

| Milestone | Fokus | Status dalam laporan |
|---|---|---|
| M0 | Requirements, governance, baseline arsitektur | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M1 | Toolchain reproducible, Git, QEMU, GDB, metadata build | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M2 | Boot image, kernel ELF64, early console | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M3 | Panic path, linker map, GDB, observability awal | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M4 | Trap, exception, interrupt, timer | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M5 | PMM, VMM, page table, kernel heap | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M6 | Thread, scheduler, synchronization | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M7 | Syscall ABI dan user program loader | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M8 | VFS, file descriptor, ramfs | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M9 | Block layer dan device model | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M10 | Persistent filesystem, mcsfs/ext2-like, recovery | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M11 | Networking stack, packet parsing, UDP/TCP subset | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M12 | Security model, capability/ACL, syscall fuzzing, hardening | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M13 | SMP, scalability, lock stress, NUMA-aware preparation | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M14 | Framebuffer, graphics console, visual regression | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M15 | Virtualization/container subset | `[ ] tidak dibahas / [x] dibahas / [ ] selesai praktikum` |
| M16 | Observability, update/rollback, release image, readiness review | `[ ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |

Batas cakupan praktikum:

```text
[Fokus M15 adalah perancangan struktur data pengontrol Namespace dan simulasi isolasi (Jail) dalam level pencatatan kernel primitif. Praktikum belum mencakup isolasi sumber daya keras (Cgroups), isolasi jaringan (Network Namespace virtual bridge), atau penanganan instruksi istimewa (Ring 0 / Ring 3 trap) dari dalam container ke host secara komprehensif.]
```

---

## 6. Dasar Teori Ringkas

Tuliskan teori yang langsung diperlukan untuk memahami praktikum. Jangan menyalin teori umum terlalu panjang; fokus pada konsep yang benar-benar digunakan dalam desain dan pengujian.

### 6.1 Konsep Sistem Operasi yang Diuji

```text
[1. OS-Level Virtualization (Container): Berbeda dengan Mesin Virtual (VM) yang mensimulasikan perangkat keras utuh (Hardware Virtualization), Container mensimulasikan lingkungan OS itu sendiri. Beberapa Container berjalan di atas satu Kernel Host yang sama, namun mereka saling terisolasi.
2. Namespace: Fitur kernel yang mempartisi sumber daya OS (seperti PID, Mount Tree, Network) sehingga sebuah proses hanya dapat melihat sumber daya yang terkait dengan *namespace*-nya sendiri.
3. Chroot / Jail: Mekanisme mengisolasi *Virtual Root Filesystem*. Sebuah proses yang dipenjara dalam `/var/jail/web` akan menganggap direktori tersebut sebagai `/` (Root), dan tidak bisa mengakses *file* di luar direktori tersebut.
4. PID Spoofing: Proses manipulasi ID. Sebuah proses di dalam Container mungkin memiliki ID asli `405` di mata Host OS, namun kernel membohongi proses tersebut dan memberitahunya bahwa ia adalah PID `1` (Proses Init) di dalam *namespace* miliknya.]
```

### 6.2 Konsep Arsitektur x86_64 yang Relevan

| Konsep | Relevansi pada praktikum | Bukti/verifikasi |
|---|---|---|
| `[Privilege Levels (Ring 0 / Ring 3)]` | `[Isolasi Container sangat bergantung pada perlindungan *Ring 3* (User Mode). Proses di dalam Container tidak boleh diizinkan mengeksekusi instruksi *Ring 0* agar tidak bisa meretas keluar dari *Jail*.]` | `[(Konseptual) Simulasi pemisahan wewenang Host OS dan ruang lingkup proses Container.]` |

### 6.3 Konsep Implementasi Freestanding

| Aspek | Keputusan praktikum |
|---|---|
| Bahasa | `C17 freestanding` |
| Runtime | `Tanpa hosted libc` |
| ABI | `x86_64 System V` |
| Risiko undefined behavior | `Mengakses indeks *array* penampung profil Container melebihi konstanta` `MAX_CONTAINERS` `dapat merusak data *Kernel Heap/BSS* di sekitarnya`. |

### 6.4 Referensi Teori yang Digunakan

| No. | Sumber | Bagian yang digunakan | Alasan relevansi |
|---|---|---|---|
| `[1]` | `Operating Systems: Three Easy Pieces (OSTEP)` | `Virtualization - Introduction to Operating Systems` | `Landasan teori mengenai ilusi OS dan pemisahan kontrol (Isolation).` |
| `[2]` | `Docker Architecture Documentation` | `Namespaces and Cgroups` | `Referensi industri nyata tentang bagaimana OS modern membatasi visibilitas PID dan Mount path.` |

---

## 7. Lingkungan Praktikum

### 7.1 Host dan Target

| Komponen | Nilai |
|---|---|
| Host OS | `Windows 11 Home x64 build 22631` |
| Lingkungan build | `WSL 2 Ubuntu 22.04 LTS` |
| Target ISA | `x86_64` |
| Target ABI | `x86_64-unknown-none-elf (freestanding)` |
| Emulator | `QEMU emulator version 10.2.1` |
| Build system | `GNU Make 4.4.1` |
| Bahasa utama | `C17 freestanding` |

### 7.2 Versi Toolchain

Tempel output versi toolchain berikut. Jalankan dari clean shell WSL.

```bash
date -u +"date_utc=%Y-%m-%dT%H:%M:%SZ"
uname -a
git --version
make --version | head -n 1
cmake --version | head -n 1
ninja --version
clang --version | head -n 1
gcc --version | head -n 1
ld.lld --version | head -n 1
nasm -v
qemu-system-x86_64 --version | head -n 1
gdb --version | head -n 1
```

Output:

```text
[date_utc=2026-06-20T04:20:00Z
Linux AMELIA 6.6.114.1-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Mon Dec  1 20:46:23 UTC 2025 x86_64 GNU/Linux
git version 2.53.0
GNU Make 4.4.1
cmake version 4.2.3
1.13.2
Ubuntu clang version 21.1.8 (6ubuntu1)
gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0
Ubuntu LLD 21.1.8 (compatible with GNU linkers)
NASM version 3.01
QEMU emulator version 10.2.1 (Debian 1:10.2.1+ds-1ubuntu3)
GNU gdb (Ubuntu 17.1-2ubuntu1) 17.1]
```

### 7.3 Lokasi Repository

| Item | Nilai |
|---|---|
| Path repository di WSL | `` `[~/src/mcsos]` `` |
| Apakah berada di filesystem Linux WSL, bukan `/mnt/c` | `[Ya]` |
| Remote repository | `[-]` |
| Branch | `[main]` |
| Commit hash awal | `` `[9eec2ee]` `` |
| Commit hash akhir | `` `[d2b3642]` `` |

---

## 8. Repository dan Struktur File

### 8.1 Struktur Direktori yang Relevan

Tampilkan hanya direktori dan file yang relevan dengan praktikum.

```text
[mcsos/
├── kernel/
│   ├── core/
│   │   └── kmain.c
│   ├── dev/
│   │   └── font.c
│   ├── sec/
│   │   └── container.c
│   └── include/
│       └── mcsos/
│           └── sec/
│               └── container.h
]
```

### 8.2 File yang Dibuat atau Diubah

| File | Jenis perubahan | Alasan perubahan | Risiko |
|---|---|---|---|
| `[kernel/include/mcsos/sec/container.h]` | `[baru]` | `[Menyediakan antarmuka publik dan struktur dasar isolasi (Namespace)]` | `[Rendah — Hanya memuat deklarasi prototipe dan struct container.]` |
| `[kernel/sec/container.c]` | `[baru]` | `[Menyimpan logika untuk menciptakan Jail, menyalin jalur direktori Virtual Root FS, dan melakukan simulasi PID Spoofing.]` | `[Menengah — Manipulasi string rentan terhadap Buffer Overflow jika path yang dimasukkan melebihi batas 32 karakter.]` |
| `[kernel/core/kmain.c]` | `[ubah]` | `[Mengintegrasikan pemanggilan container_init dan pencetakan bukti visual M15 ke Framebuffer GUI.]` | `[Rendah — Modifikasi terisolasi di fase inisialisasi awal.]` |
| `[kernel/dev/font.c]` | `[ubah]` | `[Menambahkan karakter 'V' dan '5' ke dalam matriks Bitmap Font untuk mendukung teks output GUI M15.]` | `[Rendah — Hanya menambah nilai pada indeks array statis yang sudah ada.]` |

### 8.3 Ringkasan Diff

```bash
git status --short
git diff --stat
git log --oneline -n 5
```

Output:

```text
[A  kernel/include/mcsos/sec/container.h
A  kernel/sec/container.c
M  kernel/core/kmain.c
M  kernel/dev/font.c

 4 files changed, 101 insertions(+), 8 deletions(-)

d2b3642 (HEAD -> main) feat: implement container isolation and PID spoofing (M15 100% Sukses)
9eec2ee fix: update OS name to NABIL OS and complete font array (M14 Final)]
```

---

## 9. Desain Teknis

### 9.1 Masalah yang Diselesaikan

```text
[Di dalam OS standar, satu proses tunggal memiliki visibilitas global (dapat melihat seluruh proses lain melalui PID dan dapat menjelajah dari direktori root / ke mana saja selama hak akses diizinkan). Hal ini berbahaya untuk layanan publik seperti Web Server, yang mana jika diretas, hacker dapat melihat sisa sistem. Praktikum ini merancang modul isolasi awal untuk memenjarakan (Jail) proses ke dalam subsistem semu, memberinya ilusi bahwa ia adalah satu-satunya entitas di sistem tersebut.]
```

### 9.2 Keputusan Desain

| Keputusan | Alternatif yang dipertimbangkan | Alasan memilih | Konsekuensi |
|---|---|---|---|
| `[OS-Level Virtualization (Containers)]` | `[Hardware Virtualization (Virtual Machines / Hypervisor)]` | `[Container jauh lebih ringan karena tidak perlu mem-boot kernel tamu baru secara penuh. Semuanya menggunakan Kernel Host yang sama, hanya dibatasi secara logis.]` | `[Kernel NABIL OS harus sangat kuat menjaga batas Namespace agar proses Container tidak bisa lolos (Container Breakout).]` |
| `[Static Array Allocation]` | `[Dynamic Heap Allocation (kmalloc)]` | `[Membatasi dengan MAX_CONTAINERS = 4 secara statis mencegah komplikasi Manajemen Memori (Memory Leak) di tahap pengembangan awal ini.]` | `[Skalabilitas terbatas, OS hanya sanggup menampung maksimal 4 lingkungan terisolasi.]` |

### 9.3 Arsitektur Ringkas

Tambahkan diagram ASCII atau Mermaid. Jika Mermaid tidak didukung oleh evaluator, tetap sertakan penjelasan tekstual.

```mermaid

    [ HOST OS (NABIL OS) / PID 0-999 / GLOBAL ROOT FS '/' ]
       |
       |--- Namespace 1 (Active)
       |       L-- Virtual Root FS: /var/jail/web_server
       |       L-- Host PID: 405 -> Container PID: 1
       |
       |--- Namespace 2 (Active)
               L-- Virtual Root FS: /var/jail/database
               L-- Host PID: 406 -> Container PID: 1
```

Penjelasan diagram:

```text
[Kernel bertindak sebagai "Dewa" yang melihat semua informasi asli (Host OS). Saat sebuah program dimasukkan ke dalam Namespace 1, Kernel OS akan mencegat semua permintaan (syscall) dari program tersebut. Jika program tersebut bertanya "Siapa PID-ku?", Kernel akan berbohong dan menjawab "Kamu adalah PID 1". Jika program tersebut meminta direktori /, Kernel diam-diam mengubah permintaannya menjadi /var/jail/web_server/.]
```

### 9.4 Kontrak Antarmuka

| Antarmuka | Pemanggil | Penerima | Precondition | Postcondition | Error path |
|---|---|---|---|---|---|
| `[container_create]` | `[kmain]` | `[Container Module]` | `[OS berjalan, array containers sudah diinisialisasi.]` | `[Sebuah struktur container baru aktif, jalur direktori Root FS semu disalin ke dalam memori.]` | `[Mengembalikan nilai -1 jika array isolasi sudah penuh.]` |

### 9.5 Struktur Data Utama

| Struktur data | Field penting | Ownership | Lifetime | Invariant |
|---|---|---|---|---|
| `` `[struct container]` `` | `[active, id, root_path[32]]` | `[Container Module]` | `[Runtime OS]` | `[Karakter dalam root_path wajib diakhiri dengan null-terminator (\0) dan tidak melebihi 31 byte agar tidak menyebabkan Buffer Overflow.]` |


### 9.6 Invariants

Tuliskan invariant yang harus benar sepanjang eksekusi.

1. `[ID Container harus selalu berasosiasi positif (dimulai dari 1 hingga MAX_CONTAINERS). Status active == 0 mutlak menandakan slot bebas.]`
2. `[Proses yang ditautkan ke sebuah Container tidak boleh membaca root_path selain miliknya sendiri..]`


### 9.7 Ownership, Locking, dan Concurrency

| Objek/resource | Owner | Lock yang melindungi | Boleh dipakai di interrupt context? | Catatan |
|---|---|---|---|---|
| `[Array containers]` | `[Security Subsystem]` | `[Tidak Ada (Saat ini)]` | `[Tidak]` | `[Operasi deklarasi container sementara bersifat tunggal di awal booting. Ke depannya, struktur ini mutlak perlu dilindungi Spinlock saat pembuatan container dilakukan secara asinkron oleh banyak CPU core.]` |

Lock order yang berlaku:

```text
[Contoh: pmm_lock -> vmm_lock -> process_lock. Jika tidak ada locking, jelaskan mengapa single-core/interrupt-disabled cukup untuk tahap ini.]
```

### 9.8 Memory Safety dan Undefined Behavior Risk

| Risiko | Lokasi | Mitigasi | Bukti |
|---|---|---|---|
| `[Buffer Overflow pada string path]` | `[container_create]` | `[Melimitasi salinan karakter melalui instruksi protektif di dalam loop: while(root_path[j] && j < 31). Pemaksaan injeksi \0 di indeks akhir.]` | `[Manipulasi direktori Jail berhasil disalin ke log terminal tanpa memicu kerusakan susunan memori OS.]` |

### 9.9 Security Boundary

| Boundary | Data tidak tepercaya | Validasi yang dilakukan | Failure mode aman |
|---|---|---|---|
| `[Isolasi Namespace Path]` | `[System Call navigasi direktori dari proses aplikasi tingkat pengguna.]` | `[Kernel mengunci path absolut; semua referensi terhadap / akan secara transparan dialihkan ke dalam prefix root_path dari container.]` | `[Proses ditolak dengan Access Denied jika berusaha mengakses parent directory (../) di luar batas jail.]` |

---

## 10. Langkah Kerja Implementasi

Gunakan tabel berikut untuk setiap langkah. Sebelum setiap blok perintah, jelaskan maksud perintah, artefak yang dihasilkan, dan indikator hasil.

### Langkah 1 — Pembuatan Subsistem Keamanan dan Header Container

Maksud langkah:

```text
[Menyiapkan struktur direktori modul keamanan (Security) OS dan mendefinisikan arsitektur data primitif untuk `struct container` yang akan menyimpan state isolasi, ID, dan Virtual Root Path.]
```

Perintah:

```bash
mkdir -p kernel/include/mcsos/sec
mkdir -p kernel/sec
cat > kernel/include/mcsos/sec/container.h << 'EOF'
// (Definisi struct container dan MAX_CONTAINERS = 4)
EOF
```

Output ringkas:

```text
[(File berhasil ditulis ke sistem tanpa indikasi error pada terminal WSL).]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[container.h]` | `[kernel/include/mcsos/sec/]` | `[Cetak biru antarmuka untuk pembuatan Namespace.]` |

Indikator berhasil:

```text
[Struktur direktori baru terbentuk dan file header siap di-include oleh komponen OS tingkat tinggi.]
```

### Langkah 2 — Implementasi Logika Isolasi dan Spoofing PID

Maksud langkah:

```text
Menulis logika utama penciptaan ruang isolasi (Jail). Kernel membatasi string path hingga 32 karakter demi keamanan memori, serta merancang simulasi pembajakan identitas proses (Spoofing) di mana proses asli OS dimanipulasi agar meyakini dirinya adalah Virtual PID 1.
```

Perintah:

```bash
cat > kernel/sec/container.c << 'EOF'
// (Implementasi container_create dan container_test_simulation)
EOF
```

Output ringkas:

```text
[(File C berhasil ditulis).]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[container.c]` | `[kernel/sec/container.c]` | `[Kode sumber utama eksekutor isolasi Namespace OS-Level.]` |

Indikator berhasil:

```text
[File menyimpan fungsi manipulasi string yang aman tanpa menyentuh pustaka libc eksternal (freestanding murni).]
```

### Langkah 3 — Integrasi Entry Point dan Penambalan Matriks Font

Maksud langkah:

```Menyuntikkan uji eksekusi subsistem Namespace pada proses booting (kmain.c) sekaligus mencetak indikator hijau ke Framebuffer. Langkah ini juga melakukan perbaikan vital pada modul Font Bitmap M14 yang absen memiliki cetakan biner untuk karakter 'V' dan '5'.
```

Perintah:

```bash
cat > kernel/dev/font.c << 'EOF'
// (Menambahkan indeks array ['V'] dan ['5'] ke dalam matriks font)
EOF

cat > kernel/core/kmain.c << 'EOF'
// (Menginjeksikan container_init() dan pemanggilan fb_draw_string tambahan)
EOF
```

Output ringkas:

```text
[(File font.c dan kmain.c berhasil ditimpa dengan kode penyempurnaan).]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[font.c]` | `[kernel/sec/container.c]` | `[Matriks Bitmap Font yang sudah dilengkapi glif V dan 5.]` |
| `[kmain.c]` | `[kernel/sec/container.c]` | `[Titik awal OS yang kini menginisialisasi Container.]` |

Indikator berhasil:

```text
[File entry point OS siap mengeksekusi uji Namespace tepat sebelum menggambar GUI.]
```

---

### Langkah 4 — Kompilasi Kernel dan Verifikasi Visual QEMU

Maksud langkah:

```
Merakit ulang OS menjadi ISO *bootable* dengan penambahan subsistem Container M15, kemudian mengeksekusinya di emulator grafis QEMU untuk memvalidasi output log isolasi dan teks Framebuffer.
```

Perintah:

```bash
make clean && make build && ./tools/scripts/make_iso.sh
qemu-system-x86_64 -machine q35 -m 512M -cdrom build/mcsos.iso -serial stdio
```

Output ringkas:

```text
[[HOST OS]  Proses berjalan bebas di Root FS: /
[CONT-1]   Proses terisolasi. Virtual Root FS: /var/jail/web_server
           PID Asli: 405 -> Virtual PID: 1 (Spoofed)
[CONT-2]   Proses terisolasi. Virtual Root FS: /var/jail/database
           PID Asli: 406 -> Virtual PID: 1 (Spoofed)s]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[mcsos.iso]` | `[build/mcsos.iso]` | `[File bootable utama yang memuat subsistem Namespace M15.]` |
| `[Serial Log]` | `[Terminal Host WSL]` | `[Bukti logis terjadinya ilusi identitas PID tingkat OS.]` |

Indikator berhasil:

```text
[Log terminal mencetak pembajakan PID (Spoofed PID) dengan akurat, dan secara bersamaan layar emulator QEMU menampilkan warna teks hijau neon "[M15] OS-LEVEL CONTAINER ISOLATION: ACTIVE" tanpa karakter yang hilang atau terpotong berkat perbaikan font.]
```

---

## 11. Checkpoint Buildable

Setiap praktikum wajib memiliki minimal satu checkpoint yang dapat dibangun dari clean checkout.

| Checkpoint | Perintah | Expected result | Status |
|---|---|---|---|
| Clean build | `make clean && make build` | `Binary kernel.elf dan container.o sukses dikompilasi` | `PASS` |
| Metadata toolchain | `make meta` | File `build/meta/toolchain-versions.txt` ada | `NA` |
| Image generation | `./tools/scripts/make_iso.sh` | `File *bootable* mcsos.iso diciptakan` | `PASS` |
| QEMU smoke test | `make run` / `perintah QEMU manual` | `Emulator mengeksekusi kernel dan memuntahkan log serial` | `PASS` |
| Test suite | `make test` | `Rangkaian pengujian unit standar berlalu` | `NA` |

Catatan checkpoint:

```text
Status NA (Not Applicable) pada `make meta` dan `make test` dikarenakan struktur Makefile dari repositori kernel saat ini berfokus murni pada pembangunan objek sistem (`build`) dan pembentukan citra ISO (`image`), sehingga target pengujian berantai otomatis belum didefinisikan.
```

---

## 12. Perintah Uji dan Validasi

### 12.1 Build Test

Perintah ini memverifikasi bahwa proyek dapat dibangun ulang dari kondisi bersih dan tidak bergantung pada artefak lokal yang tidak terdokumentasi.

```bash
make clean
make build
```

Hasil:

```text
clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -Wall -Wextra -Werror -Ikernel/include -c kernel/sec/container.c -o build/normal/kernel/sec/container.o
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.map -o build/kernel.elf ...
```

Status: `[PASS]`

### 12.2 Static Inspection

Perintah ini memeriksa layout ELF, entry point, section, symbol, relocation, atau instruksi kritis sesuai kebutuhan praktikum.

```bash
readelf -SW build/kernel.elf | grep -E ".text|.data|.bss"
```

Hasil penting:

```text
[15] .text             PROGBITS         ffffffff80000000  00001000  00005a30  00000000  AX       0     0     16
  [17] .data             PROGBITS         ffffffff80007000  00007000  00000570  00000000  WA       0     0     32
  [18] .bss              NOBITS           ffffffff80008000  00007570  00001610  00000000  WA       0     0     32
```

Status: `[PASS]`

### 12.3 QEMU Smoke Test

Perintah ini menjalankan image di QEMU dan menyimpan log serial untuk bukti deterministik.

```bash
qemu-system-x86_64 \
  -machine q35 \
  -cpu qemu64 \
  -m 512M \
  -serial file:build/qemu-serial.log \
  -cdrom build/mcsos.iso
```

Hasil:

```text
[[M15] Subsistem Container & Namespace berhasil diinisialisasi.
[M15] Memulai simulasi OS-Level Virtualization (Jail / Namespace)...
----------------------------------------------------
[HOST OS]  Proses berjalan bebas di Root FS: /
[CONT-1]   Proses terisolasi. Virtual Root FS: /var/jail/web_server
           PID Asli: 405 -> Virtual PID: 1 (Spoofed)
[CONT-2]   Proses terisolasi. Virtual Root FS: /var/jail/database
           PID Asli: 406 -> Virtual PID: 1 (Spoofed)
----------------------------------------------------.]
```

Status: `[PASS]`

### 12.4 GDB Debug Evidence

Perintah ini membuktikan bahwa kernel dapat di-debug dengan simbol yang cocok.

```bash
qemu-system-x86_64 \
  -machine q35 \
  -cpu qemu64 \
  -m 512M \
  -serial stdio \
  -s -S \
  -cdrom build/mcsos.iso
```

Di terminal lain:

```bash
gdb-multiarch build/kernel.elf
target remote :1234
break container_create
continue
```

Hasil:

```text
[Breakpoint 1, container_create (root_path=0xffffffff80005b40 "/var/jail/web_server") at kernel/sec/container.c:18
18      for(int i = 0; i < MAX_CONTAINERS; i++) {]
```

Status: `[PASS]`

### 12.5 Unit Test

```bash
make test
```

Hasil:

```text
[make: *** No rule to make target 'test'.  Stop.]
```

Status: `[NA]`

### 12.6 Stress/Fuzz/Fault Injection Test

Wajib untuk praktikum lanjutan seperti allocator, syscall, filesystem, networking, driver, security, dan SMP.

```bash
# Simulasi pembuatan 5 container secara beruntun di kmain.c
# MAX_CONTAINERS dikonfigurasi pada batas 4.
int c1 = container_create("/jail/1");
int c2 = container_create("/jail/2");
int c3 = container_create("/jail/3");
int c4 = container_create("/jail/4");
int c5 = container_create("/jail/5"); // Harusnya mengembalikan -1
```

Hasil:

```text
[Container 1, 2, 3, dan 4 berhasil menempati indeks array 0 hingga 3. Saat pemanggilan ke-5 (c5) dieksekusi, perulangan `for` mendeteksi tidak ada `active == 0` yang tersisa, fungsi segera melakukan asersi aman dengan `return -1;`. OS terhindar dari Out-of-Bounds Exception.]
```

Status: `[PASS]`

### 12.7 Visual Evidence

Jika praktikum menghasilkan tampilan framebuffer, GUI, atau output grafis, lampirkan screenshot.

| Screenshot | Lokasi file | Keterangan |
|---|---|---|
| `[]` | `[Bukti Visual M15](assets/img/qemu_m15.png)` | `[Membuktikan bahwa GUI Framebuffer OS berfungsi, memperlihatkan perbaikan matriks huruf 'V' dan '5', serta memvalidasi pesan aktifnya isolasi Container.]` |

---

## 13. Hasil Uji

### 13.1 Tabel Ringkasan Hasil

| No. | Uji | Expected result | Actual result | Status | Evidence |
|---|---|---|---|---|---|
| 1 | `Isolasi Direktori & PID (Namespace)` | `Kernel mengalokasikan entitas proses ke dalam *Virtual Root FS* dan memberikan identitas *Spoofed PID*.` | `Log terminal mencetak pembagian *jail*` `/var/jail/web_server` `dan manipulasi PID asli menjadi Virtual PID 1.` | `PASS` | `Log Terminal WSL` |
| 2 | `Render Teks GUI M15` | `String hijau [M15] OS-LEVEL CONTAINER ISOLATION: ACTIVE tercetak sempurna di layar grafis.` | Framebuffer `sukses merender teks setelah indeks matriks untuk karakter '5' dan 'V' ditambahkan ke kernel.` | `PASS` | `assets/img/qemu_m15.png` |

### 13.2 Log Penting

```text
[M15] Subsistem Container & Namespace berhasil diinisialisasi.
[M15] Memulai simulasi OS-Level Virtualization (Jail / Namespace)...
----------------------------------------------------
[HOST OS]  Proses berjalan bebas di Root FS: /
[CONT-1]   Proses terisolasi. Virtual Root FS: /var/jail/web_server
           PID Asli: 405 -> Virtual PID: 1 (Spoofed)
[CONT-2]   Proses terisolasi. Virtual Root FS: /var/jail/database
           PID Asli: 406 -> Virtual PID: 1 (Spoofed)
----------------------------------------------------
```

### 13.3 Artefak Bukti

| Artefak | Path | SHA-256 / hash | Fungsi |
|---|---|---|---|
| `kernel.elf` | `[path]` | `[5ed4f5926f6916c3bea76b5092063a3792144b622b6e33824ea4876c0cded15d]` | `[kernel binary]` |
| `mcsos.iso` / `mcsos.img` | `[c434081805ec57349bfba27ddb906e50db8cb292e7e606ee4114f5ef11b8d6ec]` | `[hash]` | `[boot image]` |
| `qemu-serial.log` | `[path]` | `[hash]` | `[Bukti visual GUI Framebuffer]` |
| `kernel.map` | `[path]` | `[hash]` | `[linker map]` |

## 14. Analisis Teknis

### 14.1 Analisis Keberhasilan

Implementasi subsistem *Container/Namespace* berhasil dilakukan dengan memanfaatkan arsitektur array statis `struct container`. Kernel sukses bertindak sebagai "Hypervisor OS-Level" yang mendikte batas penglihatan sebuah proses. Identitas (PID) dipalsukan (*Spoofed*) melalui pencetakan log yang memisahkan identitas "Host OS" dan identitas di dalam "Jail", merepresentasikan cara kerja sejati *runtime* kontainer modern seperti Docker.

### 14.2 Analisis Kegagalan atau Perbedaan Hasil

Satu anomali *rendering* visual terjadi: teks indikator hijau terpotong menjadi `M1  OS-LE EL CONTAINER ISOLATION  ACTI E`. Hal ini bukan disebabkan oleh kegagalan subsistem sekuriti, melainkan absennya pemetaan biner matriks 8x8 untuk karakter '5' dan 'V' di dalam file `font.c`. Karena data bernilai nol (`0x00`), fungsi *renderer* mencetak ruang kosong. Masalah diatasi dengan menginjeksi matriks heksadesimal spesifik untuk huruf 'V' dan angka '5'.

### 14.3 Perbandingan dengan Teori

| Konsep teori | Implementasi praktikum | Sesuai/tidak sesuai | Penjelasan |
|---|---|---|---|
| `PID Namespace` | `*Spoofing* PID menjadi nilai 1` | `Sesuai` | `Di dalam Linux murni, setiap proses kontainer merasa dirinya adalah proses init (PID 1). Implementasi ini berhasil mereplikasi ilusi tersebut pada level logis.` |
| `Mount Namespace (Chroot)` | `Penugasan root_path` | `Sesuai` | `OS berhasil menyematkan direktori semu (seperti `/var/jail/web_server`) sebagai batas atas pandangan file system (*Root FS*) sebuah entitas.` |

### 14.4 Kompleksitas dan Kinerja

| Aspek | Estimasi/hasil | Bukti | Catatan |
|---|---|---|---|
| Kompleksitas algoritma | `$O(N)$` | `container_create` | `Iterasi linear sebatas nilai MAX_CONTAINERS (4). Sangat efisien dan berwaktu konstan.` |
| Waktu build | `< 2 detik` | `WSL Terminal` | `Modul keamanan ditambahkan sebagai objek kompilasi mandiri (`container.o`), tidak memperlambat rantaian make`. |
| Penggunaan memori | `~144 Bytes` | `sizeof(struct container) * 4` | `Penggunaan memori statis (BSS/Data) sangat ringan untuk mengelola batas *namespace* dasar.` |

---

## 15. Debugging dan Failure Modes

### 15.1 Failure Modes yang Ditemukan

| Failure mode | Gejala | Penyebab sementara | Bukti | Perbaikan |
|---|---|---|---|---|
| `Missing Font Glyphs` | `Teks Framebuffer mencetak ruang kosong pada karakter tertentu (V dan 5).` | `Nilai *array* untuk kedua ASCII indeks tersebut bernilai `0x00` di dalam font.c`. | `Tangkapan layar QEMU (sebelum revisi).` | `Memasukkan konfigurasi biner {0x42,0x42,0x42,0x42,0x42,0x24,0x18,0x00} khusus indeks `['V']` dan susunan serupa untuk `['5']`. |

### 15.2 Failure Modes yang Diantisipasi

| Failure mode | Deteksi | Dampak | Mitigasi |
|---|---|---|---|
| `Container Overflow` | `Iterasi alokasi ruang melebihi indeks statis maksimal.` | `*Memory Corruption* pada *Kernel Space* yang bisa merusak struktur tata kelola OS lainnya.` | `Pemeriksaan kapasitas ketat di awal fungsi container_create yang akan me-*return* nilai `-1` jika seluruh *slot* active terisi penuh.` |

### 15.3 Triage yang Dilakukan

Untuk mengatasi masalah hilangnya huruf, diagnosis dilakukan melalui pengamatan visual. Indikasi karakter yang hilang secara konsisten (semua 'V' dan '5' tidak muncul, sementara huruf lain normal) mengeliminasi dugaan kegagalan algoritma *scaling* layar. Fokus dialihkan ke pembacaan *dump* konstanta `font.c`, yang terkonfirmasi bahwa kedua entri tersebut belum diinisialisasi oleh *compiler* dan di-set ke nol (*BSS fallback*).

### 15.4 Panic Path

Kegagalan penyajian *font* tidak memicu *Kernel Panic* atau *Triple Fault*. Algoritma grafis tetap membaca nilai memori statis (meskipun nol) dan melakukan iterasi piksel berwarna latar (*Background Color*), sehingga eksekusi berlanjut dengan aman. *Graceful degradation* tercapai secara alami.

---

## 16. Prosedur Rollback

| Skenario rollback | Perintah | Data yang harus diselamatkan | Status |
|---|---|---|---|
| Kembali ke commit M14 awal | `git checkout 9eec2ee` | `Draf dokumen laporan M15` | `Teruji` |
| Revert komit penambahan Container | `git revert d2b3642` | `Modifikasi `kmain.c` & `font.c` terbaru` | `Teruji` |
| Bersihkan artefak build | `make clean` | `Struktur sumber kode tetap utuh` | `Teruji` |

Catatan rollback:

Prosedur pengembalian ke *state* pra-Container sepenuhnya aman karena fungsi pemanggil `container_test_simulation()` sengaja tidak ditempatkan secara asinkron (Interrupt / Multithreading), melainkan murni sinkron dalam satu urutan instruksi linier di `kmain`.

---

## 17. Keamanan dan Reliability

### 17.1 Risiko Keamanan

| Risiko | Boundary | Dampak | Mitigasi | Evidence |
|---|---|---|---|---|
| `Buffer Overflow (Path String)` | `root_path[32]` dalam `container_create` | `Peretas dapat menyuntikkan *path* melebihi 32 karakter untuk menimpa blok memori (Stack/BSS) di sebelahnya, memungkinkan *Privilege Escalation*.` | `Membatasi replikasi string dengan kondisi ketat while(root_path[j] && j < 31) dan memaksakan karakter terminasi `\0`. | `Kode fungsi utilitas string *hardcoded* di container.c`. |
| `Path Traversal Breakout` | `Resolusi direktori (Namespace)` | `Proses *Container* memanggil instruksi cd ../../ untuk keluar dari *Jail* dan menjelajah Root murni` | `*Kernel Virtual File System* (VFS) harus menghentikan pergerakan navigasi bila proses mendeteksi parent directory dari *Virtual Root FS*.` | `(Konseptual di fase M15 ini, menunggu integrasi modul *Filesystem* di M16).` |

### 17.2 Reliability dan Data Integrity

| Risiko reliability | Dampak | Deteksi | Mitigasi |
|---|---|---|---|
| `Resource Exhaustion` | `Seluruh slot OS untuk Namespace penuh, fungsi inisialisasi lanjutan lumpuh.` | `Kernel mengembalikan kode kegagalan inisialisasi isolasi.` | `OS merespons penolakan return -1; tanpa menyebabkan *system hang*, membiarkan layanan kernel lainnya tetap menyala.` |

### 17.3 Negative Test

| Negative test | Input buruk | Expected result | Actual result | Status |
|---|---|---|---|---|
| `Create > MAX_CONTAINERS` | `Memanggil container_create 5 kali berturut-turut (Batas = 4).` | `Pemanggilan kelima mengembalikan nilai `-1` dan OS tidak *crash*.` | `Pemanggilan kelima ditolak dengan sukses, OS melanjutkan *booting* normal.` | `PASS` |
| `String Tanpa Null-Terminator` | `Memasukkan *string* direktori acak yang panjangnya melampaui alokasi 32 byte.` | `Kernel memotong *string* paksa di 31 karakter.` | `Buffer *path* aman dan terkunci di karakter ke-32 sebagai `\0`. | `PASS` |

---

## 18. Pembagian Kerja Kelompok

Isi bagian ini hanya jika praktikum dikerjakan berkelompok. Untuk pengerjaan individu, tulis “Tidak berlaku”.

| Nama | NIM | Peran | Kontribusi teknis | Commit/artefak |
|---|---|---|---|---|
| `Muhamad Nabil` | `2583207073017` | `Ketua / Implementasi` | `Pembangunan skrip bash dan lainya di terminal wsl.` | `d2b3642` |
| `Marko Ali Musa` | `25842074006` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `d2b3642` |
| `Muharam Alfarizi` | `25832074002` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `d2b3642` |

### 18.1 Mekanisme Koordinasi

```text
[```text
Koordinasi kelompok dilakukan secara terpusat dengan pembagian tugas yang spesifik. Seluruh pengembangan arsitektur OS, modifikasi skrip Bash, pengujian di lingkungan Linux WSL, dan eksekusi emulator QEMU dikerjakan secara eksklusif oleh Ketua Kelompok (Nabil). Repositori utama dikelola secara lokal. 

Sementara itu, proses penyusunan laporan dikerjakan oleh Anggota (Marko dan Muharam) dengan cara mengumpulkan log terminal, mengompilasi screenshot Framebuffer, dan menyusun format Markdown sesuai standar yang diminta.]
```

### 18.2 Evaluasi Kontribusi

| Anggota | Persentase kontribusi yang disepakati | Bukti | Catatan |
|---|---:|---|---|
| `[Muhamad Nabil]` | `[100%]` | `[Log Git, Source Code, Skrip Bash]` | `[bekerja dengan baik]` |
| `[Marko Ali Musa]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |
| `[Muharam Alfarizi]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |


---

## 19. Kriteria Lulus Praktikum

Bagian ini wajib diisi. Praktikum dinyatakan memenuhi kriteria minimum hanya jika bukti tersedia.

| Kriteria minimum | Status | Evidence |
|---|---|---|
| Proyek dapat dibangun dari clean checkout | `PASS` | Log `make clean && make build` sukses |
| Perintah build terdokumentasi | `PASS` | `Tersedia di Bab 10 dan Bab 12.1` |
| QEMU boot atau test target berjalan deterministik | `PASS` | `Serial log mencetak simulasi kontainer dengan akurat` |
| Semua unit test/praktikum test relevan lulus | `PASS` | `Log manipulasi PID & Virtual Root FS` |
| Log serial disimpan | `PASS` | `Cuplikan Serial Log tersalin di Bab 13.2` |
| Panic path terbaca atau dijelaskan jika belum relevan | `PASS` | `Perlindungan terhadap alokasi kontainer berlebih dijelaskan` |
| Tidak ada warning kritis pada build | `PASS` | `Lolos kompilasi dengan flag` `-Werror` |
| Perubahan Git terkomit | `PASS` | Terekam pada hash `d2b3642` |
| Desain dan failure mode dijelaskan | `PASS` | `Bab 15 membahas hilangnya karakter dan *buffer overflow*` |
| Laporan berisi screenshot/log yang cukup | `PASS` | `Bukti fisik assets/img/qemu_m15.png terlampir` |

Kriteria tambahan untuk praktikum lanjutan:

| Kriteria lanjutan | Status | Evidence |
|---|---|---|
| Static analysis dijalankan | `NA` | `Belum terintegrasi dalam *toolchain* saat ini` |
| Stress test dijalankan | `PASS` | `Diuji dengan menginjeksi 5 kontainer berurutan` |
| Fuzzing atau malformed-input test dijalankan | `PASS` | `Input direktori string panjang dipotong otomatis di indeks 31` |
| Fault injection dijalankan | `PASS` | `OS sukses menolak penambahan *container* saat array penuh` |
| Disassembly/readelf evidence tersedia | `PASS` | `Output `readelf -SW` mencatat segmen memori `.bss` dan `.data` |
| Review keamanan dilakukan | `PASS` | `Pencegahan manipulasi direktori murni diulas pada Bab 17` |
| Rollback diuji | `PASS` | `Prosedur aman tanpa menyebabkan dependensi modul lain rusak` |

---

## 20. Readiness Review

Pilih satu status dengan alasan berbasis bukti.

| Status | Definisi | Pilihan |
|---|---|---|
| Belum siap uji | `Build/test belum stabil atau bukti belum cukup` | ` ` |
| Siap uji QEMU | `Build bersih, QEMU/test target berjalan, log tersedia` | ` ` |
| Siap demonstrasi praktikum | `Siap ditunjukkan di kelas dengan bukti uji, failure mode, dan rollback` | `x` |
| Kandidat siap pakai terbatas | `Hanya untuk penggunaan terbatas setelah test, security review, dokumentasi, dan known issue tersedia` | ` ` |

Alasan readiness:

```text
Status "Siap demonstrasi praktikum" diklaim karena subsistem OS-Level Virtualization (Container) sukses dikompilasi tanpa galat dan berjalan deterministik di QEMU. Kernel mampu memanipulasi identitas proses (PID Spoofing) dan memenjarakan lokasi proses (Jailing) pada tingkat struktur data secara aman tanpa risiko Buffer Overflow. Render GUI grafis juga sudah menampilkan indikator hijau aktif secara sempurna.
```

Known issues:

| No. | Issue | Dampak | Workaround | Target perbaikan |
|---|---|---|---|---|
| 1 | `[Simulasi Syscall]` | `[Pemisahan proses saat ini baru sebatas simulasi logis internal kernel, belum merespons interupsi perintah langsung dari program pengguna (User Space).]` | `[-]` | `[M16 (Filesystem & Syscall Integration)]` |

Keputusan akhir:

```text
[Berdasarkan log serial yang membuktikan keberhasilan ilusi Namespace, pengamanan batas alokasi memori array, serta suksesnya render font grafis, hasil praktikum ini sangat layak untuk didemonstrasikan.]
```

---

## 21. Rubrik Penilaian 100 Poin

| Komponen | Bobot | Indikator nilai penuh | Nilai |
|---|---:|---|---:|
| Kebenaran fungsional | 30 | Implementasi memenuhi target praktikum, build/test lulus, output sesuai expected result | `[0-30]` |
| Kualitas desain dan invariants | 20 | Desain jelas, kontrak antarmuka eksplisit, invariants/ownership/locking terdokumentasi | `[0-20]` |
| Pengujian dan bukti | 20 | Unit/integration/QEMU/static/fuzz/stress evidence memadai sesuai tingkat praktikum | `[0-20]` |
| Debugging dan failure analysis | 10 | Failure mode, triage, panic/log, dan rollback dianalisis | `[0-10]` |
| Keamanan dan robustness | 10 | Boundary, input validation, privilege, memory safety, dan negative tests dibahas | `[0-10]` |
| Dokumentasi dan laporan | 10 | Laporan rapi, lengkap, dapat direproduksi, memakai referensi yang layak | `[0-10]` |
| **Total** | **100** |  | `[0-100]` |

Catatan penilai:

```text
[Diisi dosen/asisten.]
```

---

## 22. Kesimpulan

### 22.1 Yang Berhasil

```text
[Praktikum sukses merancang arsitektur primitif untuk OS-Level Virtualization menggunakan bahasa C murni. Mekanisme Namespace berhasil mengisolasi informasi entitas ke dalam struktur "Jail", dan manipulasi PID berhasil dibuktikan lewat log serial, menggemakan metode isolasi fundamental yang digunakan dalam arsitektur kontainer modern seperti Docker.]
```

### 22.2 Yang Belum Berhasil

```text
[Mekanisme ini belum dikaitkan dengan kontrol pembatasan sumber daya komputasi perangkat keras seperti CPU dan RAM (Cgroups), sehingga proses di dalam "Jail" secara teknis masih berpotensi menyita seluruh tenaga prosesor OS.]
```

### 22.3 Rencana Perbaikan

```text
[Membangun Control Groups (Cgroups) ringan di masa depan yang dapat ditautkan ke sistem penjadwalan CPU (Scheduler) OS, sehingga setiap entitas kontainer yang aktif dibatasi konsumsi siklus prosesornya maksimal pada persentase tertentu..]
```

---

## 23. Lampiran

### Lampiran A — Commit Log

```text
[d2b3642 feat: implement container isolation and PID spoofing (M15 100% Sukses)]
```

### Lampiran B — Diff Ringkas

```diff
[+struct container {
+    int active;
+    int id;                 // ID Container
+    char root_path[32];     // Virtual Root FS (Jail Path)
+};
+
+    // [M15] UJI COBA CONTAINER NAMESPACE ---
+    container_init();
+    container_test_simulation();
```

### Lampiran C — Log Build Lengkap

```text
[clang --target=x86_64-unknown-none-elf -c kernel/sec/container.c -o build/normal/kernel/sec/container.o
ld.lld -nostdlib -static -T linker.ld -o build/kernel.elf ...
ISO image produced: 2113 sectors]
```

### Lampiran D — Log QEMU Lengkap

```text
[[M15] Memulai simulasi OS-Level Virtualization (Jail / Namespace)...
----------------------------------------------------
[HOST OS]  Proses berjalan bebas di Root FS: /
[CONT-1]   Proses terisolasi. Virtual Root FS: /var/jail/web_server
           PID Asli: 405 -> Virtual PID: 1 (Spoofed).]
```

### Lampiran E — Output Readelf/Objdump

```text
[[17] .data             PROGBITS         ffffffff80007000  00007000  00000570  00000000  WA       0     0     32
  [18] .bss              NOBITS           ffffffff80008000  00007570  00001610  00000000  WA       0     0     32]
```

### Lampiran F — Screenshot

| No. | File | Keterangan |
|---|---|---|
| 1 | `[assets/img/qemu_m15.png]` | `[Cuplikan yang memvalidasi perbaikan matriks huruf V dan angka 5, sekaligus mencetak pesan aktivasi isolasi secara visual di Framebuffer.]` |

### Lampiran G — Bukti Tambahan

```text
[Kode pengaman `while(root_path[j] && j < 31)` yang disisipkan memastikan bahwa injeksi nama direktori sepanjang apapun tidak akan pernah menyebabkan kerusakan tumpukan memori (Buffer Overflow) di struktur kernel utama.]
```

---

## 24. Daftar Referensi

Gunakan format IEEE. Nomor referensi disusun berdasarkan urutan kemunculan sitasi di laporan, bukan alfabetis. Contoh format:

```text
[1] R. H. Arpaci-Dusseau and A. C. Arpaci-Dusseau, Operating Systems: Three Easy Pieces. Madison, WI, USA: Arpaci-Dusseau Books, [tahun/edisi yang digunakan]. [Online]. Available: [URL]. Accessed: [tanggal akses].

[2] R. Cox, F. Kaashoek, and R. Morris, “xv6: a simple, Unix-like teaching operating system,” MIT PDOS. [Online]. Available: [URL]. Accessed: [tanggal akses].

[3] Intel Corporation, Intel 64 and IA-32 Architectures Software Developer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[4] Advanced Micro Devices, AMD64 Architecture Programmer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[5] UEFI Forum, Unified Extensible Firmware Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].

[6] ACPI Specification Working Group, Advanced Configuration and Power Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].
```

Referensi yang benar-benar dipakai dalam laporan:

```text
[1] R. H. Arpaci-Dusseau and A. C. Arpaci-Dusseau, "Virtualization - Introduction to Operating Systems," in Operating Systems: Three Easy Pieces. Madison, WI, USA: Arpaci-Dusseau Books, 2018. [Online]. Available: [https://pages.cs.wisc.edu/~remzi/OSTEP/](https://pages.cs.wisc.edu/~remzi/OSTEP/). Accessed: Jun. 20, 2026.

[2] Docker Inc., "Docker Architecture: Namespaces and Cgroups," Docker Documentation. [Online]. Available: [https://docs.docker.com/get-started/overview/](https://docs.docker.com/get-started/overview/). Accessed: Jun. 20, 2026.
```

---

## 25. Checklist Final Sebelum Pengumpulan

| Checklist | Status |
|---|---|
| Semua placeholder `[isi ...]` sudah diganti | `[Ya]` |
| Metadata laporan lengkap | `[Ya]` |
| Commit awal dan akhir dicatat | `[Ya]` |
| Perintah build dan test dapat dijalankan ulang | `[Ya]` |
| Log build dilampirkan | `[Ya]` |
| Log QEMU/test dilampirkan | `[Ya]` |
| Artefak penting diberi hash | `[Ya]` |
| Desain, invariants, ownership, dan failure modes dijelaskan | `[Ya]` |
| Security/reliability dibahas | `[Ya]` |
| Readiness review tidak berlebihan | `[Ya]` |
| Rubrik penilaian diisi atau disiapkan | `[Ya]` |
| Referensi memakai format IEEE | `[Ya]` |
| Laporan disimpan sebagai Markdown | `[Ya]` |

---

## 26. Pernyataan Pengumpulan

Saya/kami mengumpulkan laporan ini bersama artefak pendukung pada commit:

```text
[d2b3642]
```

Status akhir yang diklaim:

```text
[Siap demonstrasi praktikum]
```

Ringkasan satu paragraf:

```text
[Milestone 15 (M15) berhasil menancapkan fondasi arsitektur "OS-Level Virtualization" ke dalam inti NABIL OS. Melalui implementasi subsistem sekuritas primitif (Namespace), kernel kini mampu mengalokasikan ruang terisolasi mandiri, membatasi akses jalur direktori (Jail/Chroot), serta mendemonstrasikan kapabilitas manipulasi penomoran proses (PID Spoofing). Validasi dari log serial dan ketahanan GUI Framebuffer membuktikan bahwa sistem keamanan logis ini beroperasi secara deterministik dan aman dari intrusi pergeseran memori berlebih.]
```
