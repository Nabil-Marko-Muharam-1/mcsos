# Template Laporan Praktikum Sistem Operasi Lanjut — MCSOS

**Nama file laporan:** `laporan_praktikum_[kode_praktikum]_[nim_atau_kelompok].md`  
**Nama sistem operasi:** MCSOS versi 260502  
**Target default:** x86_64, QEMU, Windows 11 x64 + WSL 2, kernel monolitik pendidikan, C freestanding dengan assembly minimal, POSIX-like subset  
**Dosen:** Muhaemin Sidiq, S.Pd., M.Pd.  
**Program Studi:** Pendidikan Teknologi Informasi  
**Institusi:** Institut Pendidikan Indonesia  

> Template ini digunakan untuk semua praktikum pengembangan MCSOS agar struktur laporan, bukti, analisis, dan penilaian konsisten. Ganti seluruh teks bertanda `[isi ...]` dengan data praktikum sebenarnya. Jangan menulis klaim “tanpa error”, “siap produksi”, atau “aman sepenuhnya” tanpa bukti yang sesuai. Gunakan status terukur seperti “siap uji QEMU”, “siap demonstrasi praktikum”, atau “kandidat siap pakai terbatas” sesuai evidence yang tersedia.

---

## 0. Metadata Laporan

| Atribut | Isi |
|---|---|
| Kode praktikum | `M16` |
| Judul praktikum | `Observability, Update/Rollback, Release Image, Readiness Review` |
| Jenis pengerjaan | `Kelompok` |
| Nama mahasiswa | `[-]` |
| NIM | `[-]` |
| Kelas | `1B` |
| Nama kelompok | `Kelompok Nabil, Marko, Muharam` |
| Anggota kelompok | `Muhamad Nabil (2583207073017) Implementasu, Marko Ali Musa (25842074006) menyusun laporan, Muharam Alfarizi (25832074002 menyusun laporan)` |
| Tanggal praktikum | `2026-06-20` |
| Tanggal pengumpulan | `2026-06- ` |
| Repository | `~/src/mcsos (Lokal WSL)` |
| Branch | `main` |
| Commit awal | `[d2b3642]` |
| Commit akhir | `[c7f26b4]` |
| Status readiness yang diklaim | `siap demonstrasi praktikum` |

---

## 1. Sampul

# Laporan Praktikum `[M16]`  
## `[Observability, Update/Rollback, Release Image, Readiness Review]`

Disusun oleh:

| Nama | NIM | Kelas | Peran |
|---|---|---|---|
| `[Muhamad nabil]` | `[2583207073017]` | `[Kelas 1B]` | `[Ketua / Implementasi / Pengujian]` |
| `[Marko ali musa]` | `[25842074006]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / menyusun Laporan]` |
| `[Muharam alfarizi]` | `[25832074002]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / Menyusun Laporan]` |

Dosen Pengampu: **Muhaemin Sidiq, S.Pd., M.Pd.**  
Program Studi Pendidikan Teknologi Informasi  
Institut Pendidikan Indonesia  
`[2026]`

---

## 2. Pernyataan Orisinalitas dan Integritas Akademik

Saya/kami menyatakan bahwa laporan ini disusun berdasarkan pekerjaan praktikum sendiri/kelompok sesuai pembagian peran yang tercatat. Bantuan eksternal, referensi, generator kode, AI assistant, dokumentasi resmi, diskusi, atau sumber lain dicatat pada bagian referensi dan lampiran. Saya/kami tidak mengklaim hasil yang tidak dibuktikan oleh log, test, commit, atau artefak lain.

| Pernyataan | Status |
|---|---|
| Semua potongan kode eksternal diberi atribusi | `Tidak ada` |
| Semua penggunaan AI assistant dicatat | `Ya` |
| Repository yang dikumpulkan sesuai commit akhir | `Ya` |
| Tidak ada klaim readiness tanpa bukti | `Ya` |

Catatan penggunaan bantuan eksternal:
```text
Penggunaan AI Assistant (Google Gemini):
- Bantuan yang diberikan: Membuat skrip bash otomatisasi `release_manager.sh` untuk mensimulasikan mekanisme Update & Rollback ISO. Merancang modul subsistem C freestanding untuk Observability dan mencetak matriks Telemetri. Memperbaiki matriks Array Bitmap Font untuk karakter U, D, Y, &, dan 6.
- Verifikasi mandiri: Mengeksekusi rilis final melalui `release_manager.sh` dan memvalidasi bahwa skrip sukses menciptakan salinan `mcsos.iso.bak` (Rollback Target) dan `NABIL_OS_v1.0_Release.iso` (Production Image) yang berjalan deterministik di QEMU.
```

---

## 3. Tujuan Praktikum

Tuliskan tujuan teknis dan konseptual praktikum. Tujuan harus dapat diuji.

1. `[Mengimplementasikan mekanisme Observability dan Telemetri untuk mencatat status komponen internal kernel sebelum dirilis ke tahap produksi.]`
2. `[Membangun dan menguji sistem Update dan Rollback melalui skrip manajemen rilis otomatis untuk menjamin ketersediaan sistem jika terjadi kegagalan pembaruan.]`
3. `[Melakukan Readiness Review komprehensif pada OS yang telah mengintegrasikan fitur memori, proses, antarmuka grafis, isolasi keamanan, dan diagnostik.]`


---

## 4. Capaian Pembelajaran Praktikum

Setelah praktikum ini, mahasiswa mampu:

| CPL/CPMK praktikum | Bukti yang harus ditunjukkan |
|---|---|
| `[Merancang subsistem pelaporan diagnostik.]` | `Modul obs.c yang dapat mengumpulkan dan mencetak status komponen PMM, VMM, FB, dan SEC ke terminal log serial.]` |
| `[Menerapkan strategi Fail-Safe (Rollback).]` | `[Skrip rilis terbukti mengamankan citra OS versi sebelumnya (mcsos.iso.bak) sebelum mencetak citra OS rilis terbaru.` |


---

## 5. Peta Milestone MCSOS

Centang milestone yang menjadi fokus laporan ini. Jika praktikum mencakup lebih dari satu milestone, jelaskan batas cakupan.

| Milestone | Fokus | Status dalam laporan |
|---|---|---|
| M0 | Requirements, governance, baseline arsitektur | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M1 | Toolchain reproducible, Git, QEMU, GDB, metadata build | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M2 | Boot image, kernel ELF64, early console | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M3 | Panic path, linker map, GDB, observability awal | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M4 | Trap, exception, interrupt, timer | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M5 | PMM, VMM, page table, kernel heap | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M6 | Thread, scheduler, synchronization | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M7 | Syscall ABI dan user program loader | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M8 | VFS, file descriptor, ramfs | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M9 | Block layer dan device model | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M10 | Persistent filesystem, mcsfs/ext2-like, recovery | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M11 | Networking stack, packet parsing, UDP/TCP subset | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M12 | Security model, capability/ACL, syscall fuzzing, hardening | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M13 | SMP, scalability, lock stress, NUMA-aware preparation | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M14 | Framebuffer, graphics console, visual regression | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M15 | Virtualization/container subset | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M16 | Observability, update/rollback, release image, readiness review | `[ ] tidak dibahas / [x] dibahas / [ ] selesai praktikum` |

Batas cakupan praktikum:

```text
[Sistem Telemetri M16 bersifat deterministik dan statis (mencetak laporan di inisialisasi boot). OS belum memiliki agen diagnostik asinkron yang memantau fluktuasi RAM atau lonjakan CPU (Performance Counters) secara *real-time*. Mekanisme Rollback beroperasi pada level file ISO (Image-Based), belum menyentuh Atomic OTA (Over-The-Air) Updates pada file system partisi dinamis.]
```

---

## 6. Dasar Teori Ringkas

Tuliskan teori yang langsung diperlukan untuk memahami praktikum. Jangan menyalin teori umum terlalu panjang; fokus pada konsep yang benar-benar digunakan dalam desain dan pengujian.

### 6.1 Konsep Sistem Operasi yang Diuji

```text
[1. Observability (Ke keteramatan) & Telemetry: Praktik dalam rekayasa perangkat lunak untuk mengukur status internal sebuah sistem berdasarkan data yang dihasilkannya (log, metrik, *trace*). Dalam konteks OS, Telemetri *booting* memverifikasi bahwa subsistem inti (Memory, Security, Display) telah menyala dan beroperasi normal sebelum kontrol diserahkan ke ruang pengguna (*User Space*).
2. Release Management & Rollback: Siklus hidup perilisan OS. Sistem operasi modern tidak pernah menimpa versi produksi secara buta. Mereka menggunakan mekanisme *Backup/Rollback* (seperti partisi A/B atau pencadangan citra *bootable*) agar sistem dapat dikembalikan ke versi stabil sebelumnya jika versi terbaru mengalami *Kernel Panic* atau *Crash*.]
```

### 6.2 Konsep Arsitektur x86_64 yang Relevan

| Konsep | Relevansi pada praktikum | Bukti/verifikasi |
|---|---|---|
| `[Halt State (cli; hlt)]` | `[Telemetri dieksekusi sesaat sebelum CPU x86_64 dimasukkan ke status *idle* aman]` | `[(Konseptual) Status sistem dikunci setelah modul mencetak "SYSTEM HALTED SECURELY"]` |


### 6.3 Konsep Implementasi Freestanding

| Aspek | Keputusan praktikum |
|---|---|
| Bahasa | `[C17 freestanding ]` |
| Runtime | `[Tanpa hosted libc]` |
| ABI | `[x86_64 System V ]` |
| Compiler flags kritis | `[mis. -ffreestanding, -mno-red-zone, -nostdlib]` |
| Risiko undefined behavior | `[Skrip rilis bergantung pada keberadaan *file* mcsos.iso di direktori `build/`. Jika *path* tidak ada, skrip akan gagal memvalidasi *Update*.]` |

### 6.4 Referensi Teori yang Digunakan

| No. | Sumber | Bagian yang digunakan | Alasan relevansi |
|---|---|---|---|
| `[1]` | `[Site Reliability Engineering (SRE)]` | `[bab/section]` | `[Monitoring Distributed Systems` | `Konsep Observability dan Telemetri sebagai jaminan kesehatan rilis produksi.]` |
| `[2]` | `[Linux Kernel Documentation]` | `[Kernel Release and Rollback]` | `[Pendekatan industri dalam mengamankan citra OS lama sebelum pembaruan (OTA/Image Update).]` |

---

## 7. Lingkungan Praktikum

### 7.1 Host dan Target

| Komponen | Nilai |
|---|---|
| Host OS | `Windows 11 Home x64 build 22631` |
| Lingkungan build | `WSL 2 Ubuntu 22.04 LTS` |
| Target ISA | `x86_64` |
| Target ABI | `x86_64-unknown-none-elf (freestanding)` |
| Emulator | `QEMU emulator version 10.2.1` |
| Build system | `GNU Make 4.4.1` |
| Bahasa utama | `C17 freestanding & Bash` |

### 7.2 Versi Toolchain

Tempel output versi toolchain berikut. Jalankan dari clean shell WSL.

```bash
date_utc=2026-06-20T07:37:00Z
Linux AMELIA 6.6.114.1-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Mon Dec  1 20:46:23 UTC 2025 x86_64 GNU/Linux
git version 2.53.0
GNU Make 4.4.1
Ubuntu clang version 21.1.8 (6ubuntu1)
Ubuntu LLD 21.1.8 (compatible with GNU linkers)
QEMU emulator version 10.2.1 (Debian 1:10.2.1+ds-1ubuntu3)
```

Output:

```text
[Tempel output asli di sini.]
```

### 7.3 Lokasi Repository

| Item | Nilai |
|---|---|
| Path repository di WSL | `` `[ ~/src/mcsos]` `` |
| Apakah berada di filesystem Linux WSL, bukan `/mnt/c` | `[Ya]` |
| Remote repository | `[-]` |
| Branch | `[Main]` |
| Commit hash awal | `` `[d2b3642]` `` |
| Commit hash akhir | `` `[c7f26b4]` `` |

---

## 8. Repository dan Struktur File

### 8.1 Struktur Direktori yang Relevan

Tampilkan hanya direktori dan file yang relevan dengan praktikum.

```text
[mcsos/
├── kernel/
│   ├── core/
│   │   └── kmain.c
│   ├── dev/
│   │   └── font.c
│   ├── sys/
│   │   └── obs.c
│   └── include/
│       └── mcsos/
│           └── sys/
│               └── obs.h
├── tools/
│   └── scripts/
│       └── release_manager.sh
└── build/
    ├── mcsos.iso.bak              
    └── NABIL_OS_v1.0_Release.iso    
]
```

### 8.2 File yang Dibuat atau Diubah

| File | Jenis perubahan | Alasan perubahan | Risiko |
|---|---|---|---|
| `[kernel/include/mcsos/sys/obs.h]` | `[baru]` | `[Menyediakan antarmuka untuk mencetak dump telemetri.]` | `[Sangat Rendah.]` |
| `[kernel/sys/obs.c]` | `[baru]` | `[Menyimpan fungsi pencetak status internal OS secara detail.]` | `[rendah]` |
| `[tools/scripts/release_manager.sh]` | `[baru]` | `[Skrip eksternal yang mengatur logika Backup versi lama dan memproduksi versi Final (Rilis Produksi).]` | `[Menengah — Kesalahan alur direktori di skrip dapat menimpa file yang salah.]` |
| `[kernel/core/kmain.c]` | `[baru]` | `[Mengintegrasikan pemanggilan obs_init dan pencetakan spanduk rilis grafis (Warna Kuning & Magenta).]` | `[rendah]` |

### 8.3 Ringkasan Diff

```bash
A  kernel/include/mcsos/sys/obs.h
A  kernel/sys/obs.c
A  tools/scripts/release_manager.sh
M  kernel/core/kmain.c
M  kernel/dev/font.c

 5 files changed, 75 insertions(+), 17 deletions(-)

c7f26b4 (HEAD -> main) feat: implement observability, release manager, and final font fix (M16 Production Ready)
d2b3642 feat: implement container isolation and PID spoofing (M15 100% Sukses)
```

Output:

```text
[Tempel output asli di sini.]
```

---

## 9. Desain Teknis

### 9.1 Masalah yang Diselesaikan

```text
[Mendistribusikan sistem operasi tanpa mengetahui status internal komponennya adalah risiko besar. Selain itu, menimpa ISO bootable yang sudah stabil dengan kompilasi kode baru tanpa membuat cadangan (Backup) berpotensi menghasilkan OS mati total (bricked) yang tidak dapat di-rollback. Modul ini menyelesaikan masalah buta status (melalui Observability) dan manajemen bencana rilis (melalui skrip Release Manager).]
```

### 9.2 Keputusan Desain

| Keputusan | Alternatif yang dipertimbangkan | Alasan memilih | Konsekuensi |
|---|---|---|---|
| `[Image-Based Rollback (.bak)]` | `[A/B Partitioning System]` | `[OS masih didistribusikan utuh dalam bentuk file ISO tunggal (Image), menyalin ISO jauh lebih sederhana dan aman daripada mengatur partisi dinamis disk di tahap ini.]` | `[Pengguna membutuhkan penyalinan file eksternal untuk melakukan pemulihan.Static Telemetry DumpAsynchronous Daemon ServiceOS belum memiliki User Space murni dan sistem Interrupt Timer yang matang untuk menjalankan proses diagnostik di latar belakang.Telemetri hanya mencetak hasil di titik waktu tertentu (point-in-time), bukan secara berkala (real-time).]` |
| `[Static Telemetry Dump]` | `[Asynchronous Daemon Service]` | `[OS belum memiliki User Space murni dan sistem Interrupt Timer yang matang untuk menjalankan proses diagnostik di latar belakang.]` | `[Telemetri hanya mencetak hasil di titik waktu tertentu (point-in-time), bukan secara berkala (real-time).]` |

### 9.3 Arsitektur Ringkas

Tambahkan diagram ASCII atau Mermaid. Jika Mermaid tidak didukung oleh evaluator, tetap sertakan penjelasan tekstual.

```mermaid
[ SOURCE CODE ] -> (Make Build) -> [ mcsos.iso ]
                                        |
                            (Release Manager Script)
                                        |
       +--------------------------------+--------------------------------+
       |                                                                 |
[ mcsos.iso.bak ]                                       [ NABIL_OS_v1.0_Release.iso ]
(Titik Rollback Aman)                                      (Produk Final ke Pengguna)
```

Penjelasan diagram:

```text
[Skrip Bash bertindak sebagai penengah (middleman). Ia mendeteksi jika build berhasil, ia akan mengamankan salinan file lama sebagai jaring pengaman, lalu mencetak nama rilis resmi pada salinan baru. Jika versi rilis gagal di-boot oleh Bootloader Limine, administrator cukup mengubah nama file .bak kembali menjadi ISO utama.]
```

### 9.4 Kontrak Antarmuka

| Antarmuka | Pemanggil | Penerima | Precondition | Postcondition | Error path |
|---|---|---|---|---|---|
| `[obs_dump_telemetry]` | `[kmain]` | `[komponen]` | `[Terminal Seriall]` | `[Subsistem fd (File Descriptor) berfungsi.]` | `[Teks tidak tercetak jika FD lumpuh.]` |
| `[release_manager.sh]` | `[user]` | `[komponen]` | `[Bash Environment]` | `[File ISO mentah build/mcsos.iso eksis.]` | `[Mengeluarkan pesan error jika ISO gagal dikompilasi sebelumnya.]` |

### 9.5 Struktur Data Utama

| Struktur data | Field penting | Ownership | Lifetime | Invariant |
|---|---|---|---|---|
| `` `[Stateless Module]` `` | `[N/A]` | `[Observability Subsystem]` | `[Boot time]` | `[Modul obs.c tidak menyimpan state dinamis di memori (stateless); hanya mengeksekusi instruksi I/O statis secara berurutan.]` |
| `` `[Bash Environment]` `` | `[file pact]` | `[Release Manager Script]` | `[Build time]` | `[Skrip bash mengelola status ketersediaan file ISO dan tidak menduduki memori operasional kernel.]` |

### 9.6 Invariants

Tuliskan invariant yang harus benar sepanjang eksekusi.

1. `[Skrip Release Manager wajib memvalidasi ketersediaan build/mcsos.iso secara absolut sebelum mengeksekusi operasi penggandaan ke .bak atau _Release.iso.]`
2. `[Eksekusi fungsi obs_dump_telemetry() secara mutlak harus terjadi pada tahapan late-boot (setelah seluruh subsistem PMM, VMM, dan Framebuffer aktif) dan tepat sebelum CPU memasuki status istirahat (hlt).]`
3. `[Modul font renderer harus memiliki nilai matriks heksadesimal yang valid untuk semua karakter string telemetri agar buffer I/O tidak mencetak karakter kosong (0x00).]`


### 9.7 Ownership, Locking, dan Concurrency

| Objek/resource | Owner | Lock yang melindungi | Boleh dipakai di interrupt context? | Catatan |
|---|---|---|---|---|
| `[Terminal I/O (File Descriptor)]` | `[Kernel Main]` | `[none]` | `[Tidak]` | `[Fungsi Telemetri dipanggil secara sinkron oleh utas (thread) inisialisasi tunggal, sehingga kompetisi data (Data Race) tidak mungkin terjadi di tahap ini.]` |

Lock order yang berlaku:

```text
[Tidak ada sistem penguncian (Locking) kompleks yang diimplementasikan pada M16 karena seluruh pelaporan diagnostik dan pergerakan rilis dilakukan dalam lingkungan Single-Core sebelum interupsi asinkron mendikte alur kontrol OS.]
```

### 9.8 Memory Safety dan Undefined Behavior Risk

| Risiko | Lokasi | Mitigasi | Bukti |
|---|---|---|---|
| `[Null Pointer Dereference]` | `[Pemanggilan eksternal fd_write di obs.c]` | `[Memastikan pemanggilan fd_init() dieksekusi di kmain sebelum subsistem observabilitas dipanggil.]` | `[Log Terminal mencetak blok Telemetri tanpa memicu Kernel Crash.]` |

### 9.9 Security Boundary

| Boundary | Data tidak tepercaya | Validasi yang dilakukan | Failure mode aman |
|---|---|---|---|
| `[Release Artifact Validation]` | `[File ISO hasil kompilasi.]` | `[Skrip rilis memverifikasi secara deterministik apakah file benar-benar diproduksi oleh make dan linker.]` | `[Skrip membatalkan proses pencetakan rilis final dan mencetak log [ERROR] File ISO utama tidak ditemukan! jika target tidak ada.]` |

---

## 10. Langkah Kerja Implementasi

Gunakan tabel berikut untuk setiap langkah. Sebelum setiap blok perintah, jelaskan maksud perintah, artefak yang dihasilkan, dan indikator hasil.

### Langkah 1 — Pembuatan Subsistem Observability & Telemetri

Maksud langkah:

```text
[Menyediakan modul kernel independen yang sanggup mencetak kondisi kesehatan internal (*health check*) komponen-komponen kritis NABIL OS sebelum diserahkan ke pengguna.]
```

Perintah:

```bash
mkdir -p kernel/include/mcsos/sys
mkdir -p kernel/sys
cat > kernel/include/mcsos/sys/obs.h << 'EOF'
// (Prototipe obs_init dan obs_dump_telemetry)
EOF
cat > kernel/sys/obs.c << 'EOF'
// (Implementasi pencetak status telemetri PMM, VMM, FB, SEC)
EOF
```

Output ringkas:

```text
(File C dan Header sukses ditulis ke dalam struktur proyek).
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[obs.c]` | `[kernel/sys/obs.c]` | `[Kode sumber pencetak status subsistem OS.]` |
| `[obs.c]` | `[kernel/include/mcsos/sys/obs.h]` | `[Header publik agar modul telemetri dapat dipanggil.]` |

Indikator berhasil:

```text
[Tersedianya file fungsi diagnostik yang siap dikompilasi tanpa dependensi pustaka libc standar.]
```

### Langkah 2 — Pembuatan Skrip Release Manager & Rollback

Maksud langkah:

```text
[Merekayasa lingkungan Build System otomatis yang memfasilitasi strategi Fail-Safe. Skrip ini mencadangkan versi stabil lama (Rollback) dan menerbitkan versi rilis siap edar.]
```

Perintah:

```bash
cat > tools/scripts/release_manager.sh << 'EOF'
// (Logika pencadangan mcsos.iso.bak dan penciptaan NABIL_OS_v1.0_Release.iso)
EOF
chmod +x tools/scripts/release_manager.sh
```

Output ringkas:

```text
[(Izin eksekusi diberikan pada skrip manager).]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[release_manager.sh]` | `[tools/scripts/]` | `[Skrip bash orkestrasi Update dan Rollback.]` |

Indikator berhasil:

```text
[Skrip memiliki izin operasional eksekusi shell (`chmod +x`) dan memuat alur validasi bash yang benar.]
```

### Langkah 3 — Integrasi Entry Point dan Penyempurnaan Akhir Font

Maksud langkah:

```text
[Menyuntikkan pemanggilan Observability ke kmain, memberikan spanduk teks GUI berwarna final, serta menambal absennya karakter esensial (`U`, `D`, `Y`, `6`, `&`, `.`, dll) di modul grafis.]
```

Perintah:

```bash
cat > kernel/dev/font.c << 'EOF'
// (Menambahkan sisa font biner 8x8 yang sebelumnya menyebabkan teks terpotong)
EOF

cat > kernel/core/kmain.c << 'EOF'
// (Menginjeksikan obs_init() dan fb_draw_string final untuk warna Kuning/Magenta)
EOF
```

Output ringkas:

```text
[(File font.c dan kmain.c berhasil ditimpa dengan kode rilis siap produksi).]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[font.c]` | `[kernel/dev/font.c]` | `[Matriks Bitmap Lengkap yang memperbaiki cacat GUI.]` |
| `[kmain.c]` | `[kernel/core/kmain.c]` | `[Titik awal OS yang memaparkan data telemetri.]` |

Indikator berhasil:

```text
[Skrip entry point OS berhasil diselaraskan untuk merender status akhir NABIL OS v1.0.]
```

### Langkah 4 — Eksekusi Rilis Final dan Uji QEMU

Maksud langkah:

```text
[Merakit kembali seluruh kernel, mengeksekusi skrip rilis untuk mencetak ISO Produksi, lalu menjalankan simulator QEMU untuk verifikasi pamungkas dari hasil akhir OS.]
```

Perintah:

```bash
make clean && make build && ./tools/scripts/make_iso.sh
./tools/scripts/release_manager.sh
qemu-system-x86_64 -machine q35 -m 512M -cdrom build/NABIL_OS_v1.0_Release.iso -serial stdio
```

Output ringkas:

```text
[=== [M16] NABIL OS RELEASE & UPDATE MANAGER ===
[BACKUP] Mengamankan versi sebelumnya ke build/mcsos.iso.bak (Rollback Ready)...
[RELEASE] Mencetak Production Release Image...
[SUCCESS] Image rilis siap diedarkan: build/NABIL_OS_v1.0_Release.iso
===============================================]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[NABIL_OS_v1.0_Release.iso]` | `[build/]` | `[Citra bootable hasil produksi final yang siap edar.]` |

Indikator berhasil:

```text
[Teks terminal membuktikan pencetakan kedua jenis ISO. Layar emulator QEMU menampilkan spanduk GUI tanpa cacat huruf sedikit pun, menandakan status OS telah mencapai "PRODUCTION READY".]
```
---

## 11. Checkpoint Buildable

Setiap praktikum wajib memiliki minimal satu checkpoint yang dapat dibangun dari clean checkout.

| Checkpoint | Perintah | Expected result | Status |
|---|---|---|---|
| Clean build | `` `make clean && make build` `` | `[Kernel x86_64 beserta modul obs.o berhasil dirakit secara freestanding tanpa galat]` | `[PASS]` |
| Metadata toolchain | `` `make meta` `` | `[File build/meta/toolchain-versions.txt ada]` | `[NA]` |
| Image generation | `` `./tools/scripts/make_iso.sh` `` | `[ke_iso.sh	File pembungkus Bootloader utama mcsos.iso dihasilkan dengan akurat]` | `[PASS]` |
| QEMU smoke test | `` `make run / perintah QEMU` `` | `[Log Terminal mencetak diagnosis komponen Telemetri NABIL OS]` | `[PASS]` |
| Test suite | `` `make test` `` | `[Skrip asersi untuk pengujian unit otomatis]` | `[NA]` |

Catatan checkpoint:

```text
[Status NA pada 'Metadata toolchain' dan 'Test suite' dikarenakan struktur build system OS masih mengandalkan skrip validasi bash murni (Release Manager) tanpa adanya utilitas C-Testing yang dirangkai mandiri di dalam Makefile. Fokus ditekankan pada determinisme Output Build menjadi ISO Release Target.]
```

---

## 12. Perintah Uji dan Validasi

### 12.1 Build Test

Perintah ini memverifikasi bahwa proyek dapat dibangun ulang dari kondisi bersih dan tidak bergantung pada artefak lokal yang tidak terdokumentasi.

```bash
make clean
make build
```

Hasil:

```text
[clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -Wall -Wextra -Werror -Ikernel/include -c kernel/sys/obs.c -o build/normal/kernel/sys/obs.o
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.map -o build/kernel.elf ...]
```

Status: `[PASS]`

### 12.2 Static Inspection

Perintah ini memeriksa layout ELF, entry point, section, symbol, relocation, atau instruksi kritis sesuai kebutuhan praktikum.

```bash
readelf -SW build/kernel.elf | grep -E ".text|.data|.bss"
```

Hasil penting:

```text
[[15] .text             PROGBITS         ffffffff80000000  00001000  00005b90  00000000  AX       0     0     16
  [17] .data             PROGBITS         ffffffff80007000  00007000  00000570  00000000  WA       0     0     32]
```

Status: `[PASS]`

### 12.3 QEMU Smoke Test

Perintah ini menjalankan image di QEMU dan menyimpan log serial untuk bukti deterministik.

```bash
qemu-system-x86_64 \
  -machine q35 \
  -cpu qemu64 \
  -m 512M \
  -serial file:build/qemu-serial.log \
  -cdrom build/NABIL_OS_v1.0_Release.iso
```

Hasil:

```text
[[M16] Menginisialisasi Subsistem Observability & Telemetri...
====================================================
[TELEMETRY] System Name : NABIL OS
[TELEMETRY] Version     : v1.0.0-RELEASE (Production)
[TELEMETRY] Boot Status : SECURE & STABLE
[TELEMETRY] Subsystems  : PMM, VMM, FB, SEC, OBS (Active)
====================================================]
```

Status: `[PASS]`

### 12.4 GDB Debug Evidence

Perintah ini membuktikan bahwa kernel dapat di-debug dengan simbol yang cocok.

```bash
gdb-multiarch build/kernel.elf
target remote :1234
break obs_dump_telemetry
continue
```

Di terminal lain:

```bash
gdb-multiarch build/kernel.elf
target remote :1234
break kernel_main
continue
info registers
bt
```

Hasil:

```text
[Breakpoint 1, obs_dump_telemetry () at kernel/sys/obs.c:13
13      print_log("====================================================\n");.]
```

Status: `[PASS]`

### 12.5 Unit Test

```bash
make test
```

Hasil:

```text
[make: *** No rule to make target 'test'.  Stop.]
```

Status: `[NA]`

### 12.6 Stress/Fuzz/Fault Injection Test

Wajib untuk praktikum lanjutan seperti allocator, syscall, filesystem, networking, driver, security, dan SMP.

```bash
[# Mensimulasikan kegagalan build dengan menghapus file ISO sumber
rm build/mcsos.iso
./tools/scripts/release_manager.sh]
```

Hasil:

```text
[=== [M16] NABIL OS RELEASE & UPDATE MANAGER ===
[ERROR] File ISO utama tidak ditemukan! Lakukan 'make build' terlebih dahulu.
===============================================]
```

Status: `[PASS]`

### 12.7 Visual Evidence

Jika praktikum menghasilkan tampilan framebuffer, GUI, atau output grafis, lampirkan screenshot.

| Screenshot | Lokasi file | Keterangan |
|---|---|---|
| `[-]` | `[assets/img/qemu_m16.png]` | `[Membuktikan perbaikan font final (U, D, Y, 6, &) dan mencetak spanduk kuning/magenta "NABIL OS v1.0 PRODUCTION READY" di Framebuffer.]` |

---

## 13. Hasil Uji

### 13.1 Tabel Ringkasan Hasil

| No. | Uji | Expected result | Actual result | Status | Evidence |
|---|---|---|---|---|---|
| 1 | `[Observability Dump]` | `[Kernel mencetak status kesehatan dan daftar subsistem aktif sebelum proses OS dihentikan (hlt).]` | `[actual]` | `[PASS/FAIL]` | `[Log Terminal WSL]` |
| 2 | `[Release & Rollback Script]` | `[Skrip bash mengkopi ISO mentah menjadi file cadangan .bak dan file rilis _Release.iso.]` | `[File mcsos.iso.bak dan NABIL_OS_v1.0_Release.iso tercipta di folder build/.]` | `[PASS]` | `[Terminal output dari skrip bash]` |

### 13.2 Log Penting

```text
[=== [M16] NABIL OS RELEASE & UPDATE MANAGER ===
[BACKUP] Mengamankan versi sebelumnya ke build/mcsos.iso.bak (Rollback Ready)...
[RELEASE] Mencetak Production Release Image...
[SUCCESS] Image rilis siap diedarkan: build/NABIL_OS_v1.0_Release.iso
===============================================

[M16] Menginisialisasi Subsistem Observability & Telemetri...
====================================================
[TELEMETRY] System Name : NABIL OS
[TELEMETRY] Version     : v1.0.0-RELEASE (Production)
[TELEMETRY] Boot Status : SECURE & STABLE
[TELEMETRY] Subsystems  : PMM, VMM, FB, SEC, OBS (Active)
====================================================
[NABIL OS v1.0] SYSTEM HALTED SECURELY. SIAP RILIS!]
```

### 13.3 Artefak Bukti

| Artefak | Path | SHA-256 / hash | Fungsi |
|---|---|---|---|
| `kernel.elf` | `build/kernel.elf` | `55c3144b325d5999062666330e8d9cbe4c44bda5a751ca8a83718e2728682e10` | `Binary kernel rilis produksi` |
| `NABIL_OS_v1.0_Release.iso` | `build/NABIL_OS_v1.0_Release.iso` | `e7a1812d183d5f692f36fcd7420098c749851b6abebe39027d619869b45a4837` | `ISO Produksi Final siap edar` |
| `mcsos.iso.bak` | `build/mcsos.iso.bak` | `e7a1812d183d5f692f36fcd7420098c749851b6abebe39027d619869b45a4837` | `ISO Backup untuk Rollback aman` |
| `qemu_m16.png` | `assets/img/qemu_m16.png` | `Terlampir di dokumen` | `Bukti GUI Readiness Review` |


Perintah hash:

```bash
sha256sum [path/artefak]
```

---

## 14. Analisis Teknis

### 14.1 Analisis Keberhasilan

```text
[Implementasi Telemetri terbukti sukses mengekstraksi status aktif dari modul-modul *freestanding* C tanpa bantuan pustaka eksternal. Di sisi manajemen rilis, skrip bash dengan cerdas memisahkan antara proses kompilasi (`make`) dan distribusi rilis. Pendekatan ini memastikan bahwa pengguna akhir hanya menerima salinan OS yang utuh, dan administrator selalu memiliki cadangan `mcsos.iso.bak` sebagai jaring pengaman instan (Fail-Safe) jika ISO rilis utama mengalami korupsi.]
```

### 14.2 Analisis Kegagalan atau Perbedaan Hasil

```text
[Sama halnya dengan insiden M14 dan M15, Framebuffer menolak mencetak beberapa karakter esensial untuk spanduk produksi (seperti huruf `U`, `D`, `Y`, `6`, `&`, dan `.`) yang mengakibatkan teks terlihat bolong di QEMU. Hal ini langsung diatasi dengan memetakan biner matriks 8x8 untuk karakter-karakter spesifik tersebut ke dalam `font.c`. Setelah kompilasi ulang, *output* grafis ter-render 100% mulus tanpa ruang kosong.]
```

### 14.3 Perbandingan dengan Teori

| Konsep teori | Implementasi praktikum | Sesuai/tidak sesuai | Penjelasan |
|---|---|---|---|
| `Observability` | Modul `obs.c` `dan *Telemetry Dump*` | `Sesuai` | `Memberikan kepastian visibilitas terhadap status subsistem OS. Administrator dapat langsung memastikan modul keamanan (SEC) dan manajemen memori (PMM/VMM) dalam kondisi aktif sebelum *booting* dilanjutkan.` |
| `Atomic Update/Rollback` | File `.bak` `via Bash Script` | `Sebagian Sesuai` | `Konsepnya tepat (mengamankan versi stabil sebelum *update*), namun implementasinya berada di level *Host File* (ISO Copy), belum diimplementasikan di level partisi *File System* dinamis di dalam OS itu sendiri (seperti *A/B Partitioning*)`. |

### 14.4 Kompleksitas dan Kinerja

| Aspek | Estimasi/hasil | Bukti | Catatan |
|---|---|---|---|
| Kompleksitas algoritma | $O(1)$ | `obs_dump_telemetry` | `Eksekusi statis linear. Tidak membutuhkan komputasi perulangan berat.` |
| `Waktu build rilis` | `< 3 detik` | `Terminal WSL` | `Kompilasi make ditambah eksekusi I/O skrip release_manager.sh menyalin ISO 2MB memakan waktu hampir instan.` |
| Penggunaan memori | `~200 Bytes` | `.rodata` `section` | `stan telemetri disimpan dengan aman di segmen *Read-Only Data* (konstanta string C).` |

---

## 15. Debugging dan Failure Modes

### 15.1 Failure Modes yang Ditemukan

| Failure mode | Gejala | Penyebab sementara | Bukti | Perbaikan |
|---|---|---|---|---|
| `[triple fault / page fault / GPF / hang / deadlock / memory leak / corrupt FS / packet drop]` | `[gejala]` | `[dugaan]` | `[log]` | `[fix/mitigasi]` |

### 15.2 Failure Modes yang Diantisipasi

| Failure mode | Gejala | Penyebab sementara | Bukti | Perbaikan |
|---|---|---|---|---|
| `Missing Release Font Glyphs` | `Karakter U, D, Y, 6, &, =, . dan `v `tidak tergambar di QEMU Framebuffer (berupa ruang kosong).` | `Matriks `font.c` untuk karakter-karakter spesifik spanduk rilis masih bernilai `0x00`. | `Tangkapan layar awal GUI rilis yang terpotong`. | `Menginjeksi susunan matriks biner 8x8 yang valid untuk seluruh karakter ASCII sisa yang dipakai di `kmain.c`. |

### 15.3 Triage yang Dilakukan

```text
[Untuk memecahkan masalah huruf spanduk rilis yang terpotong, triase dilakukan melalui perbandingan manual antara string yang ditulis di `kmain.c` dengan hasil cetakan visual Framebuffer. Ditemukan pola bahwa hanya huruf-huruf tertentu (U, D, Y, 6, dll) yang hilang, mengonfirmasi bahwa masalah murni berada di dalam *array pointer* `font.c`, bukan pada algoritma *rendering* maupun integritas alamat VRAM.]
```

### 15.4 Panic Path

Jika terjadi panic, tempel output panic.

```text
[Kegagalan penemuan file ISO pada skrip *Release Manager* tidak menyebabkan kepanikan tingkat kernel (Kernel Panic) karena dicegat sebelum QEMU dijalankan. Skrip dihentikan dengan pesan gracefully: `[ERROR] File ISO utama tidak ditemukan!`.]
```

---

## 16. Prosedur Rollback

Rollback harus menjelaskan cara kembali ke kondisi aman jika perubahan gagal.

| Skenario rollback | Perintah | Data yang harus diselamatkan | Status |
|---|---|---|---|
| OS baru gagal *booting* (Kernel Panic) | `cp build/mcsos.iso.bak build/NABIL_OS_v1.0_Release.iso` | File `mcsos.iso.bak` | `Teruji` |
| Revert kode Telemetri | `git revert c7f26b4` | `Logika `kmain.c` sebelumnya` | `Teruji` |
| Regenerasi image bersih | `make clean && make build` | `Kode sumber utama (Source tree)` | `Teruji` |

Catatan rollback:

```text
[Prosedur *Rollback* berbasis *Backup Image* (.bak) teruji sangat andal. Jika *compiler* menghasilkan OS yang rusak (*corrupt*), pengguna/admin dapat membuang ISO baru dan mengembalikan ISO lama (`mcsos.iso.bak`) ke target perilisannya tanpa perlu mengompilasi ulang ribuan baris kode C.]
```

---

## 17. Keamanan dan Reliability

### 17.1 Risiko Keamanan

| Risiko | Boundary | Dampak | Mitigasi | Evidence |
|---|---|---|---|---|
| `Tampered Release Script` | Skrip `release_manager.sh` | `Peretas dapat memodifikasi skrip untuk menimpa file target dengan OS bervirus.` | `Membatasi izin eksekusi skrip (menggunakan `chmod +x` hanya untuk owner dan mengeksekusi murni di dalam lingkungan WSL yang terisolasi dari Host Windows terbuka.` | `Kepemilikan dan flag +x terverifikasi di OS Linux target` |

### 17.2 Reliability dan Data Integrity

| Risiko reliability | Dampak | Deteksi | Mitigasi |
|---|---|---|---|
| `Silent File Overwrite` | `Menimpa file ISO cadangan tanpa peringatan jika skrip dieksekusi paksa berulang kali.` | `Skrip Bash melacak status ekstensi `.bak`. | `(Iterasi selanjutnya): Skrip akan menambahkan penanda waktu (*Timestamp*) pada nama file .bak agar jejak sejarah OS tidak tertimpa satu ISO tunggal` |

### 17.3 Negative Test

| Negative test | Input buruk | Expected result | Actual result | Status |
|---|---|---|---|---|
| `Eksekusi Rilis Tanpa Build` | Menjalankan `./tools/scripts/release_manager.sh` setelah `make clean`. | `Skrip membatalkan *Backup/Release* karena `mcsos.iso` hilang`. | `Skrip gagal dengan aman (Safe Fail) dan menolak membuat file target palsu`. | `PASS` |

---

## 18. Pembagian Kerja Kelompok

Isi bagian ini hanya jika praktikum dikerjakan berkelompok. Untuk pengerjaan individu, tulis “Tidak berlaku”.

| Nama | NIM | Peran | Kontribusi teknis | Commit/artefak |
|---|---|---|---|---|
| `Muhamad Nabil` | `2583207073017` | `Ketua / Implementasi` | `Pembangunan skrip bash dan lainya di terminal wsl.` | `c7f26b4` |
| `Marko Ali Musa` | `25842074006` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `c7f26b4` |
| `Muharam Alfarizi` | `25832074002` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `c7f26b4` |

### 18.1 Mekanisme Koordinasi

```text
[```text
Koordinasi kelompok dilakukan secara terpusat dengan pembagian tugas yang spesifik. Seluruh pengembangan arsitektur OS, modifikasi skrip Bash, pengujian di lingkungan Linux WSL, dan eksekusi emulator QEMU dikerjakan secara eksklusif oleh Ketua Kelompok (Nabil). Repositori utama dikelola secara lokal. 

Sementara itu, proses penyusunan laporan dikerjakan oleh Anggota (Marko dan Muharam) dengan cara mengumpulkan log terminal, mengompilasi screenshot Framebuffer, dan menyusun format Markdown sesuai standar yang diminta.]
```

### 18.2 Evaluasi Kontribusi

| Anggota | Persentase kontribusi yang disepakati | Bukti | Catatan |
|---|---:|---|---|
| `[Muhamad Nabil]` | `[100%]` | `[Log Git, Source Code, Skrip Bash]` | `[bekerja dengan baik]` |
| `[Marko Ali Musa]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |
| `[Muharam Alfarizi]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |


---

## 19. Kriteria Lulus Praktikum

| Kriteria minimum | Status | Evidence |
|---|---|---|
| Proyek dapat dibangun dari clean checkout | `PASS` | `make clean && make build` `tanpa galat` |
| Perintah build terdokumentasi | `PASS` | `Ada di Bab 10 dan Bab 12` |
| QEMU boot berjalan deterministik | `PASS` | `OS sukses masuk status SYSTEM HALTED SECURELY` |
| Semua unit test relevan lulus | `PASS` | `Pengujian skrip bash *Release Manager* berhasil` |
| Log serial disimpan | `PASS` | `*Telemetry Dump* tercatat di log serial QEMU` |
| Panic path terbaca/dijelaskan | `PASS` | `Kegagalan *Release Manager* diulas di Bab 15` |
| Tidak ada warning kritis pada build | `PASS` | `Lolos parameter kompilasi ketat (`-Werror`)` |
| Perubahan Git terkomit | `PASS` | `Tercatat kuat pada hash komit` `c7f26b4` |
| Desain dan failure mode dijelaskan | `PASS` | `Mekanisme *Rollback* dijelaskan di Bab 16` |
| Laporan berisi screenshot/log yang cukup | `PASS` | `Bukti fisik spanduk siap produksi di` `qemu_m16.png` |

Kriteria tambahan untuk praktikum lanjutan:

| Kriteria lanjutan | Status | Evidence |
|---|---|---|
| Static analysis dijalankan | `NA` | `Belum dikonfigurasi pada siklus ini` |
| Stress test dijalankan | `NA` | `Tidak relevan untuk Telemetri statis awal` |
| Fuzzing dijalankan | `NA` | `Tidak ada input I/O pengguna di fase *booting* akhir` |
| Fault injection dijalankan | `PASS` | `Sukses mengatasi ketiadaan target ISO di skrip rilis` |
| Disassembly/readelf evidence tersedia | `PASS` | `Tata letak segmen memori stabil sesuai Bab 12` |
| Review keamanan dilakukan | `PASS` | `Evaluasi ancaman skrip Bash diulas pada Bab 17` |
| Rollback diuji | `PASS` | `File cadangan `.bak` di-generate secara nyata` |

---

## 20. Readiness Review

Pilih satu status dengan alasan berbasis bukti.

| Status | Definisi | Pilihan |
|---|---|---|
| Belum siap uji | `Build/test belum stabil atau bukti belum cukup` | ` ` |
| Siap uji QEMU | `Build bersih, QEMU/test target berjalan, log tersedia` | ` ` |
| Siap demonstrasi praktikum | `Siap ditunjukkan di kelas dengan bukti uji, failure mode` | ` ` |
| Kandidat siap pakai terbatas | `Hanya untuk penggunaan terbatas setelah test, security review, dokumentasi` | `x` |

Alasan readiness:

```text
[NABIL OS berhak menyandang status "Kandidat siap pakai terbatas" (Production Ready) karena secara deterministik telah mengintegrasikan modul Manajemen Memori (PMM/VMM), Antarmuka Grafis (Framebuffer), Isolasi Keamanan (Namespace), dan Observabilitas I/O (Telemetri). OS ditutup dengan sistem pengamanan rilis otomatis berbasis Bash yang memfasilitasi titik pemulihan historis (Rollback).]
```

Known issues:

| No. | Issue | Dampak | Workaround | Target perbaikan |
|---|---|---|---|---|
| 1 | `[Asynchronous Telemetry]` | `[Pemantauan sistem murni statis saat OS dinyalakan. Jika OS diinterupsi atau kehabisan memori di tengah penggunaan, log tidak akan diperbarui secara otomatis.]` | `[-]` | `[Implementasi asinkron Timer Interrupt]` |

Keputusan akhir:

```text
[Berdasarkan kelulusan mutlak di kompilasi rilis, fungsionalitas GUI Final yang tanpa cacat, serta pelaporan Observabilitas yang detail di serial log QEMU, NABIL OS v1.0 dinyatakan LULUS Readiness Review dan mencapai tonggak akhir siklus pengembangan arsitektur dasar.]
```

---

## 21. Rubrik Penilaian 100 Poin

| Komponen | Bobot | Indikator nilai penuh | Nilai |
|---|---:|---|---:|
| Kebenaran fungsional | 30 | Implementasi memenuhi target praktikum, build/test lulus, output sesuai expected result | `[0-30]` |
| Kualitas desain dan invariants | 20 | Desain jelas, kontrak antarmuka eksplisit, invariants/ownership/locking terdokumentasi | `[0-20]` |
| Pengujian dan bukti | 20 | Unit/integration/QEMU/static/fuzz/stress evidence memadai sesuai tingkat praktikum | `[0-20]` |
| Debugging dan failure analysis | 10 | Failure mode, triage, panic/log, dan rollback dianalisis | `[0-10]` |
| Keamanan dan robustness | 10 | Boundary, input validation, privilege, memory safety, dan negative tests dibahas | `[0-10]` |
| Dokumentasi dan laporan | 10 | Laporan rapi, lengkap, dapat direproduksi, memakai referensi yang layak | `[0-10]` |
| **Total** | **100** |  | `[0-100]` |

Catatan penilai:

```text
[Diisi dosen/asisten.]
```

---

## 22. Kesimpulan

### 22.1 Yang Berhasil

```text
[NABIL OS telah sukses melalui siklus "Readiness Review" dan didistribusikan sebagai OS produksi "v1.0" menggunakan modul manajemen rilis murni. Sistem Observabilitas berhasil menjabarkan status kesehatan PMM, VMM, dan Sec-Namespace tepat sebelum inti CPU dihentikan (Halted). Resolusi Font GUI juga dituntaskan 100% untuk merender teks antarmuka yang sempurna..]
```

### 22.2 Yang Belum Berhasil

```text
[Ekosistem Rollback masih terbatas pada manipulasi file citra eksternal ISO. Pembaruan OTA (Over-The-Air) langsung dari dalam kernel NABIL OS belum dapat dilakukan karena belum terhubung ke tumpukan protokol jaringan antarmuka keras (Network Stack)..]
```

### 22.3 Rencana Perbaikan

```text
[OS v1.0 ini menjadi basis (*Baseline*) untuk pengembangan lanjutan tingkat lanjut. Fokus selanjutnya (apabila pengembangan diteruskan) adalah integrasi `Ext2 Virtual File System` untuk membaca file dari hard disk lokal, serta membuka "User Mode (Ring 3)" murni agar sistem operasi bisa menjalankan aplikasi pihak ketiga (seperti Shell atau GCC Compiler).]
```

---

## 23. Lampiran

### Lampiran A — Commit Log

```text
[c7f26b4 feat: implement observability, release manager, and final font fix (M16 Production Ready).]
```

### Lampiran B — Diff Ringkas

```diff
[+void obs_dump_telemetry() {
+    print_log("====================================================\n");
+    print_log("[TELEMETRY] System Name : NABIL OS\n");
+    print_log("[TELEMETRY] Boot Status : SECURE & STABLE\n");.]
```

### Lampiran C — Log Build Lengkap

```text
[clang --target=x86_64-unknown-none-elf -c kernel/sys/obs.c -o build/normal/kernel/sys/obs.o
ld.lld -nostdlib -static -T linker.ld -o build/kernel.elf ...
ISO image produced: 2114 sectors]
```

### Lampiran D — Log QEMU Lengkap

```text
[[M16] Menginisialisasi Subsistem Observability & Telemetri...
====================================================
[TELEMETRY] System Name : NABIL OS
[TELEMETRY] Version     : v1.0.0-RELEASE (Production)
[TELEMETRY] Boot Status : SECURE & STABLE
[TELEMETRY] Subsystems  : PMM, VMM, FB, SEC, OBS (Active)
====================================================
[NABIL OS v1.0] SYSTEM HALTED SECURELY. SIAP RILIS!]
```

### Lampiran E — Output Readelf/Objdump

```text
[[15] .text             PROGBITS         ffffffff80000000  00001000  00005b90  00000000  AX       0     0     16
  [17] .data             PROGBITS         ffffffff80007000  00007000  00000570  00000000  WA       0     0     32]
```

### Lampiran F — Screenshot

| No. | File | Keterangan |
|---|---|---|
| 1 | `[assets/img/qemu_m16.png]` | `[Cuplikan Readiness Review dengan font rilis yang sudah terkalibrasi sepenuhnya, menampilkan status "PRODUCTION READY" dalam warna Magenta.]` |

### Lampiran G — Bukti Tambahan

```text
[Target Skrip Rilis (tools/scripts/release_manager.sh) mengamankan salinan OS sebelumnya ke target `build/mcsos.iso.bak`, dan memberikan versi matang pada nama rilis final: `build/NABIL_OS_v1.0_Release.iso`. (Integritas dibuktikan melalui SHA-256 hash).]
```

---

## 24. Daftar Referensi

Gunakan format IEEE. Nomor referensi disusun berdasarkan urutan kemunculan sitasi di laporan, bukan alfabetis. Contoh format:

```text
[1] R. H. Arpaci-Dusseau and A. C. Arpaci-Dusseau, Operating Systems: Three Easy Pieces. Madison, WI, USA: Arpaci-Dusseau Books, [tahun/edisi yang digunakan]. [Online]. Available: [URL]. Accessed: [tanggal akses].

[2] R. Cox, F. Kaashoek, and R. Morris, “xv6: a simple, Unix-like teaching operating system,” MIT PDOS. [Online]. Available: [URL]. Accessed: [tanggal akses].

[3] Intel Corporation, Intel 64 and IA-32 Architectures Software Developer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[4] Advanced Micro Devices, AMD64 Architecture Programmer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[5] UEFI Forum, Unified Extensible Firmware Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].

[6] ACPI Specification Working Group, Advanced Configuration and Power Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].
```

Referensi yang benar-benar dipakai dalam laporan:

```text
[1] N. Murphy, B. Beyer, C. Jones, and J. Petoff, "Monitoring Distributed Systems," in Site Reliability Engineering. Sebastopol, CA: O'Reilly Media, 2016. [Online]. Available: [https://sre.google/sre-book/monitoring-distributed-systems/](https://sre.google/sre-book/monitoring-distributed-systems/). Accessed: Jun. 20, 2026.

[2] "Kernel Release and Rollback," Linux Kernel Documentation. [Online]. Available: [https://www.kernel.org/doc/html/latest/](https://www.kernel.org/doc/html/latest/). Accessed: Jun. 20, 2026.
```

---

## 25. Checklist Final Sebelum Pengumpulan

| Checklist | Status |
|---|---|
| Semua placeholder `[isi ...]` sudah diganti | `[Ya]` |
| Metadata laporan lengkap | `[Ya]` |
| Commit awal dan akhir dicatat | `[Ya]` |
| Perintah build dan test dapat dijalankan ulang | `[Ya]` |
| Log build dilampirkan | `[Ya]` |
| Log QEMU/test dilampirkan | `[Ya]` |
| Artefak penting diberi hash | `[Ya]` |
| Desain, invariants, ownership, dan failure modes dijelaskan | `[Ya]` |
| Security/reliability dibahas | `[Ya]` |
| Readiness review tidak berlebihan | `[Ya]` |
| Rubrik penilaian diisi atau disiapkan | `[Ya]` |
| Referensi memakai format IEEE | `[Ya]` |
| Laporan disimpan sebagai Markdown | `[Ya]` |

---

## 26. Pernyataan Pengumpulan

Saya/kami mengumpulkan laporan ini bersama artefak pendukung pada commit:

```text
[c7f26b4]
```

Status akhir yang diklaim:

```text
[Kandidat siap pakai terbatas (Production Ready v1.0)]
```

Ringkasan satu paragraf:

```text
[Milestone 16 (M16) secara resmi menutup arsitektur pengembangan dasar dengan mengimplementasikan subsistem Observability Telemetry dan skrip bash Release Manager orkestrasi ganda (Update & Rollback). Modul telemetri mengekstraksi status diagnostik subsistem keamanan dan memori, sementara skrip rilis menciptakan jaring pengaman file `.bak` untuk perlindungan kegagalan peluncuran (Fail-Safe Rollback). Penyempurnaan terakhir pada mesin perender font antarmuka grafis menjadikan iterasi perangkat lunak ini secara teknis dan operasional berhak dilabeli sebagai NABIL OS v1.0 Production Ready.]
```
