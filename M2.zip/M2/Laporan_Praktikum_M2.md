# Template Laporan Praktikum Sistem Operasi Lanjut — MCSOS

**Nama file laporan:** `laporan_praktikum_[kode_praktikum]_[nim_atau_kelompok].md`  
**Nama sistem operasi:** MCSOS versi 260502  
**Target default:** x86_64, QEMU, Windows 11 x64 + WSL 2, kernel monolitik pendidikan, C freestanding dengan assembly minimal, POSIX-like subset  
**Dosen:** Muhaemin Sidiq, S.Pd., M.Pd.  
**Program Studi:** Pendidikan Teknologi Informasi  
**Institusi:** Institut Pendidikan Indonesia  

> Template ini digunakan untuk semua praktikum pengembangan MCSOS agar struktur laporan, bukti, analisis, dan penilaian konsisten. Ganti seluruh teks bertanda `[isi ...]` dengan data praktikum sebenarnya. Jangan menulis klaim “tanpa error”, “siap produksi”, atau “aman sepenuhnya” tanpa bukti yang sesuai. Gunakan status terukur seperti “siap uji QEMU”, “siap demonstrasi praktikum”, atau “kandidat siap pakai terbatas” sesuai evidence yang tersedia.

---

## 0. Metadata Laporan

| Atribut | Isi |
|---|---|
| Kode praktikum | `M2` |
| Judul praktikum | `Boot Image, Kernel ELF64, dan Early Serial Console MCSOS 260502` |
| Jenis pengerjaan | `Kelompok` |
| Nama mahasiswa | `[-]` |
| NIM | `[-]` |
| Kelas | `1B` |
| Nama kelompok | `Kelompok Nabil, Marko, Muharam` |
| Anggota kelompok | `Muhamad Nabil (2583207073017) Implementasu, Marko Ali Musa (25842074006) menyusun laporan, Muharam Alfarizi (25832074002 menyusun laporan)` |
| Tanggal praktikum | `2026-06- ` |
| Tanggal pengumpulan | `2026-06- ` |
| Repository | `~/src/mcsos` |
| Branch | `main` |
| Commit awal | `2e39289` |
| Commit akhir | `adc1765` |
| Status readiness yang diklaim | `Siap uji QEMU tahap M2` |

---

## 1. Sampul

# Laporan Praktikum `[M2]`  
## `[Boot Image, Kernel ELF64, dan Early Serial Console MCSOS 260502]`

Disusun oleh:

| Nama | NIM | Kelas | Peran |
|---|---|---|---|
| `[Muhamad nabil]` | `[2583207073017]` | `[Kelas 1B]` | `[Ketua / Implementasi / Pengujian]` |
| `[Marko ali musa]` | `[25842074006]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / menyusun Laporan]` |
| `[Muharam alfarizi]` | `[25832074002]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / Menyusun Laporan]` |

Dosen Pengampu: **Muhaemin Sidiq, S.Pd., M.Pd.**  
Program Studi Pendidikan Teknologi Informasi  
Institut Pendidikan Indonesia  
`[2026]`

---

## 2. Pernyataan Orisinalitas dan Integritas Akademik

Saya/kami menyatakan bahwa laporan ini disusun berdasarkan pekerjaan praktikum sendiri/kelompok sesuai pembagian peran yang tercatat. Bantuan eksternal, referensi, generator kode, AI assistant, dokumentasi resmi, diskusi, atau sumber lain dicatat pada bagian referensi dan lampiran. Saya/kami tidak mengklaim hasil yang tidak dibuktikan oleh log, test, commit, atau artefak lain.

| Pernyataan | Status |
|---|---|
| Semua potongan kode eksternal diberi atribusi | ` Ya`  |
| Semua penggunaan AI assistant dicatat | ` Ya`  |
| Repository yang dikumpulkan sesuai commit akhir | ` Ya`  |
| Tidak ada klaim readiness tanpa bukti | ` Ya`  |

Catatan penggunaan bantuan eksternal:

```text
- Alat: Google Gemini (AI Assistant)
- Prompt ringkas: Permintaan bantuan untuk memformat log terminal menjadi tabel Markdown yang rapi, menganalisis pesan error ShellCheck (SC2188) pada skrip preflight, dan menyusun kerangka dokumen Readiness Review.
- Sumber: Chat interaktif dengan Gemini.
- Bagian yang dibantu: Perbaikan baris kode redirection `> "$REPORT"` menjadi operasi no-op `: > "$REPORT"` menggunakan perintah sed, serta penyusunan draf narasi pelaporan teknis.
- Verifikasi mandiri yang dilakukan: Mengeksekusi secara langsung perintah perbaikan di terminal WSL Ubuntu, memvalidasi ulang dengan perintah `make grade`, dan memastikan hash commit M2 tersimpan secara valid tanpa mengubah fungsionalitas kernel.
```
---

## 3. Tujuan Praktikum

Tuliskan tujuan teknis dan konseptual praktikum. Tujuan harus dapat diuji.

1. `[Tujuan teknis 1: Menghasilkan kernel berformat ELF64 x86_64 freestanding yang dapat diinspeksi secara deterministik.]`
2. `[Tujuan teknis 2: Membuat boot image MCSOS M2 (berformat ISO dengan Limine bootloader) yang dapat dijalankan pada lingkungan QEMU/OVMF.]  `
3. `[Tujuan konseptual 1: Membuktikan jalur boot awal secara berurutan: firmware (OVMF) -> bootloader (Limine) -> kernel entry (kmain) -> serial output (COM1) -> controlled halt loop.]`
4. `[Tujuan validasi: Menyediakan early serial console sebagai kanal observability pertama untuk mengumpulkan bukti jalannya sistem operasi tanpa bergantung pada display/framebuffer.  ]`

---

## 4. Capaian Pembelajaran Praktikum

Setelah praktikum ini, mahasiswa mampu:

| CPL/CPMK praktikum | Bukti yang harus ditunjukkan |
|---|---|
| `[Mampu membuat source kernel freestanding C17 dan linker script untuk higher-half kernel ELF64 tahap awal.  ]` | `[Berkas luaran build/kernel.elf, build/kernel.map, dan artefak inspeksi build/inspect/readelf-header.txt dengan entry point 0xffffffff80000000.]` |
| `[Mampu membuat accessor port I/O x86_64 untuk UART 16550 COM1 dan menginisialisasi serial console awal.]` | `[Bukti disassembly (objdump-disassembly.txt) memuat instruksi out dan in, serta log build/qemu-serial.log yang berisi marker deterministik M2.]` |
| `[Mampu merakit bootloader Limine menjadi ISO bootable dan menjalankannya di QEMU/OVMF secara headless.  ]` | `[Terdapat fail luaran build/mcsos.iso, terverifikasi oleh checksum SHA-256 (mcsos.iso.sha256), dan tidak muncul error saat eksekusi make run.]` |
| `[Mampu memeriksa kembali readiness M0 dan M1 serta menyusun readiness review M2 berbasis bukti, bukan klaim subjektif.]` | `[Lulus pengujian preflight otomatis (build/meta/m2-preflight.txt) dan selesainya dokumen docs/readiness/M2-boot-image.md pada repositori.]` |

---

## 5. Peta Milestone MCSOS

Centang milestone yang menjadi fokus laporan ini. Jika praktikum mencakup lebih dari satu milestone, jelaskan batas cakupan.

| Milestone | Fokus | Status dalam laporan |
|---|---|---|
| M0 | Requirements, governance, baseline arsitektur | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M1 | Toolchain reproducible, Git, QEMU, GDB, metadata build | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M2 | Boot image, kernel ELF64, early console | `[ ] tidak dibahas / [x] dibahas / [ ] selesai praktikum` |
| M3 | Panic path, linker map, GDB, observability awal | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M4 | Trap, exception, interrupt, timer | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M5 | PMM, VMM, page table, kernel heap | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M6 | Thread, scheduler, synchronization | `[x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M7 | Syscall ABI dan user program loader | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M8 | VFS, file descriptor, ramfs | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M9 | Block layer dan device model | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M10 | Persistent filesystem, mcsfs/ext2-like, recovery | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M11 | Networking stack, packet parsing, UDP/TCP subset | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M12 | Security model, capability/ACL, syscall fuzzing, hardening | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M13 | SMP, scalability, lock stress, NUMA-aware preparation | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M14 | Framebuffer, graphics console, visual regression | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M15 | Virtualization/container subset | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M16 | Observability, update/rollback, release image, readiness review | `[ x ] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |

Batas cakupan praktikum:

```text
[Praktikum Modul 2 ini secara eksklusif berfokus pada pembuktian jalur paling awal dari eksekusi perangkat lunak (Boot Path). Target utamanya adalah membuktikan bahwa kode sumber C freestanding dan instruksi inline assembly dapat dikompilasi menjadi kernel.elf murni yang dapat dimuat oleh bootloader (Limine) dan menghasilkan respons di QEMU UEFI (OVMF)[cite: 23].

Praktikum ini memiliki batasan yang tegas (Non-goals). Laporan ini tidak mengimplementasikan:
1. Manajemen memori (Memory Manager).
2. Penanganan Interupsi (IDT, interrupt handler, timer, atau panic subsystem penuh).
3. Framebuffer, filesystem, block driver, network stack, scheduler, maupun mode userspace.
4. Pengujian pada perangkat keras fisik (hardware bring-up fisik) [cite: 57-60].

Keberhasilan praktikum ini tidak dapat diklaim sebagai bukti bahwa kernel aman, stabil, bebas cacat, atau siap untuk produksi[cite: 61].]
```

---

## 6. Dasar Teori Ringkas

Tuliskan teori yang langsung diperlukan untuk memahami praktikum. Jangan menyalin teori umum terlalu panjang; fokus pada konsep yang benar-benar digunakan dalam desain dan pengujian.

### 6.1 Konsep Sistem Operasi yang Diuji

```text
[Praktikum Modul 2 memvalidasi konsep dasar perpindahan kendali eksekusi (handoff) dari perangkat keras menuju kernel sistem operasi [cite: 104-105]. Konsep utama yang diuji meliputi:
1. Bootloader (Limine): Program awal yang dimuat oleh firmware (OVMF) yang bertanggung jawab menyiapkan platform CPU ke mode long mode x86_64, menyediakan memori awal, dan memuat berkas kernel [cite: 101-105].
2. Executable and Linkable Format (ELF64): Format standar file biner (*executable*) sistem yang terstruktur atas *header*, *program header*, dan *section* yang dimengerti oleh bootloader untuk ditempatkan ke dalam memori[cite: 102].
3. Linker Script: Bahasa perintah deklaratif yang mengatur pemetaan alamat memori virtual *higher-half kernel* (dimulai dari `0xffffffff80000000`) dan menentukan fungsi *entry point* (`kmain`) [cite: 546-550].
4. Early Serial Console: Kanal *observability* (inspeksi) paling awal bagi pengembang OS untuk mencetak jejak *debugging* sebelum driver tampilan (*framebuffer*) kompleks diimplementasikan [cite: 53-54, 439-443].]
```

### 6.2 Konsep Arsitektur x86_64 yang Relevan

| Konsep | Relevansi pada praktikum | Bukti/verifikasi |
|---|---|---|
| `[Port-Mapped I/O (PMIO)]` | `[Kernel harus berkomunikasi dengan perangkat eksternal primitif (UART 16550 / COM1) menggunakan sistem alamat I/O tersendiri yang terpisah dari memori sistem.  ]` | `[Pemanggilan instruksi rakitan outb dan inb yang terbukti pada cuplikan dekompilasi objdump-disassembly.txt . ]` |
| `[x86_64 Long Mode]` | `[Arsitektur target 64-bit yang dipersyaratkan oleh kontrak bootloader Limine sebelum mengeksekusi entry point kernel .  ]` | `[Bukti arsitektur terbaca sebagai "Advanced Micro Devices X86-64" pada readelf-header.txt .]` |
| `[Hardware Interrupt Control]` | `[Kernel belum memiliki penanganan interupsi (IDT) yang aman. Interupsi tak terduga dapat memicu interupsi ganda/fatal (triple fault).n]` | `[Penggunaan instruksi rakitan cli (Clear Interrupt Flag) dan hlt (Halt) pada fungsi halt_forever() .]` |

### 6.3 Konsep Implementasi Freestanding

| Aspek | Keputusan praktikum |
|---|---|
| Bahasa | `[C17 freestanding dipadukan dengan inline assembly x86_64 secara terkendali.]` |
| Runtime | `[ Tanpa keberadaan pustaka host (hosted libc), objek permulaan standar (crt0), atau fungsi main() bawaan sistem operasi Linux WSL. Fungsi pelengkap manipulasi memori primitif (memset, memcpy, memmove) direkayasa ulang secara manual .]` |
| ABI | `[Mematuhi konvensi x86_64 System V Application Binary Interface (ABI) konvensional untuk standar pelewatan parameter .  ]` |
| Compiler flags kritis | `[-ffreestanding (mematikan standar libc eksternal), -nostdlib (mematikan pengikatan librari bawaan compiler), dan -mno-red-zone (mematikan optimasi memori asinkron di bawah stack pointer).  ]` |
| Risiko undefined behavior | `[Terjadinya buffer overflow atau kerusakan stack akibat kegagalan sinkronisasi memori. Termasuk interupsi perangkat asinkron yang menghantam area data apabila sistem dikompilasi tanpa parameter pencegahan Red Zone .  ]` |

### 6.4 Referensi Teori yang Digunakan

| No. | Sumber | Bagian yang digunakan | Alasan relevansi |
|---|---|---|---|
| `[1]` | `[LLVM Project, "Clang Compiler User's Manual - Freestanding Builds"]` | `[Parameter kompiler Clang]` | `[Mengonfirmasi perlakuan khusus flag -ffreestanding dan mitigasi Red Zone untuk mencegah kompiler LLVM berasumsi OS memiliki utilitas standard library utuh.]` |
| `[2]` | `[Limine Bootloader Project, "Limine Bare Bones", OSDev Wiki   ]` | `[Spesifikasi Bootloader]` | `[Menjelaskan kontrak antar-muka (handoff) spesifikasi Limine yang memuat berkas kernel langsung dari CD-ROM (ISO) melalui berkas kendali limine.conf.]` |

---

## 7. Lingkungan Praktikum

### 7.1 Host dan Target

| Komponen | Nilai |
|---|---|
| Host OS | `Windows 11 x64` |
| Lingkungan build | `WSL 2 Ubuntu 26.04 LTS` |
| Target ISA | `x86_64` |
| Target ABI | `x86_64-unknown-none-elf` |
| Emulator | `QEMU version 10.2.1` |
| Firmware emulator | `/usr/share/OVMF/OVMF_CODE_4M.fd` |
| Debugger | `GNU gdb 17.1` |
| Build system | `GNU Make 4.4.1` |
| Bahasa utama | `C17 freestanding` |
| Assembly | `NASM version 3.01` |

### 7.2 Versi Toolchain

Tempel output versi toolchain berikut. Jalankan dari clean shell WSL.

```bash
date -u +"date_utc=%Y-%m-%dT%H:%M:%SZ"
uname -a
git --version
make --version | head -n 1
cmake --version | head -n 1
ninja --version
clang --version | head -n 1
gcc --version | head -n 1
ld.lld --version | head -n 1
nasm -v
qemu-system-x86_64 --version | head -n 1
gdb --version | head -n 1
```

Output:

```text
[date_utc=2026-06-12T10:35:12Z
Linux AMELIA 6.6.114.1-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Mon Dec 1 20:46:23 UTC 2025 x86_64 GNU/Linux
git version 2.53.0
GNU Make 4.4.1
cmake version 4.2.3
1.13.2
Ubuntu clang version 21.1.8 (6ubuntu1)
gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0
Ubuntu LLD 21.1.8 (compatible with GNU linkers)
NASM version 3.01
QEMU emulator version 10.2.1 (Debian 1:10.2.1+ds-1ubuntu3)
GNU gdb (Ubuntu 17.1-2ubuntu1) 17.1]
```

### 7.3 Lokasi Repository

| Item | Nilai |
|---|---|
| Path repository di WSL | `` `[~/src/mcsos]` `` |
| Apakah berada di filesystem Linux WSL, bukan `/mnt/c` | `[Ya]` |
| Remote repository | `[-]` |
| Branch | `[main]` |
| Commit hash awal | `` `[2e39289]` `` |
| Commit hash akhir | `` `[adc1765]` `` |

---

## 8. Repository dan Struktur File

### 8.1 Struktur Direktori yang Relevan

Tampilkan hanya direktori dan file yang relevan dengan praktikum.
[cite_start]Struktur berikut mencerminkan hierarki repositori setelah implementasi kernel dasar dan skrip automasi M2 [cite: 136-180].

```text
mcsos/
├── configs/
│   └── limine/
│       └── limine.conf
├── docs/
│   ├── architecture/
│   │   ├── invariants.md
│   │   └── overview.md
│   ├── readiness/
│   │   └── M2-boot-image.md
│   ├── security/
│   │   └── threat_model.md
│   └── testing/
│       └── verification_matrix.md
├── kernel/
│   ├── arch/x86_64/include/mcsos/arch/
│   │   └── io.h
│   ├── core/
│   │   ├── kmain.c
│   │   └── serial.c
│   └── lib/
│       └── memory.c
├── linker.ld
├── Makefile
└── tools/
    └── scripts/
        ├── fetch_limine.sh
        ├── grade_m2.sh
        ├── inspect_kernel.sh
        ├── m2_preflight.sh
        ├── make_iso.sh
        ├── run_qemu.sh
        └── run_qemu_debug.sh
```

### 8.2 File yang Dibuat atau Diubah

| File | Jenis perubahan | Alasan perubahan | Risiko |
|---|---|---|---|
| `[kernel/core/kmain.c]` | `[Baru]` | `[Implementasi entry point utama kernel x86_64.]` | `[Tinggi: Kesalahan logika di tahap awal ini berakibat pada triple fault dan reboot loop.]` |
| `[kernel/core/serial.c & io.h]` | `[baru/ubah/hapus]` | `[Menyediakan driver primitif (polling-based) untuk akses UART COM1.]` | `[Sedang: Kesalahan I/O port bisa membuat fungsi serial_write diam tak merespons (hang).]` |
| `[kernel/lib/memory.c]` | `[Baru]` | `[Mengganti pustaka bawaan libc Ubuntu agar kernel murni freestanding.]` | `[Tinggi: Adanya bug pada pointer memcpy/memset akan merusak keseluruhan memory state kernel.]` |
| `[linker.ld]` | `[baru/ubah/hapus]` | `[Menetapkan alamat pemetaan kernel secara eksplisit ke memori area higher-half.]` | `[Tinggi: Tata letak alamat yang salah akan menyebabkan bootloader (Limine) menolak memuat kernel .  ]` |
| `[configs/limine/limine.conf]` | `[Baru]` | `[Mendefinisikan konfigurasi kontrak bootloader dan parameter sistem .  ]` | `[Rendah: Kesalahan pengetikan mudah dilacak dan diuji.]` |
| `[Makefile]` | `[ubah]` | `[Menyesuaikan toolchain M2 untuk membangun objek baru, menautkannya ke ld.lld, dan mendefinisikan target pengujian.]` | `[Sedang: Kesalahan parameter (seperti hilangnya -mno-red-zone) dapat merusak determinisme dan keamanan build .  ]` |
| `[tools/scripts/*.sh]` | `[Baru]` | `[Mengotomasi proses pengambilan ( fetch) bootloader, pembuatan fail ISO, dan eksekusi QEMU headless .  ]` | `[Rendah: Kegagalan skrip hanya berimbas pada host environment, bukan pada keamanan OS di perangkat keras fisik.]` |


### 8.3 Ringkasan Diff

```bash
nabil@AMELIA:~/src/mcsos$ git status --short
nabil@AMELIA:~/src/mcsos$ 

nabil@AMELIA:~/src/mcsos$ git diff --stat 2e39289 HEAD
 configs/limine/limine.conf                 |   7 +
 docs/architecture/overview.md              |   9 +
 docs/readiness/M2-boot-image.md            |  54 +++++++++++++++
 docs/security/threat_model.md              |   5 +
 docs/testing/verification_matrix.md        |   5 +
 kernel/arch/x86_64/include/mcsos/arch/io.h |  18 +++++
 kernel/core/kmain.c                        |  16 +++++
 kernel/core/serial.c                       |  38 +++++++++++
 kernel/lib/memory.c                        |  36 ++++++++++
 linker.ld                                  |  45 +++++++++++++
 Makefile                                   |  54 ++++++++++++++-
 tools/scripts/fetch_limine.sh              |  26 +++++++
 tools/scripts/grade_m2.sh                  |  35 ++++++++++
 tools/scripts/inspect_kernel.sh            |  23 +++++++
 tools/scripts/m2_preflight.sh              |  79 ++++++++++++++++++++++
 tools/scripts/make_iso.sh                  |  41 ++++++++++++
 tools/scripts/run_qemu.sh                  |  68 +++++++++++++++++++
 tools/scripts/run_qemu_debug.sh            |  43 ++++++++++++
 18 files changed, 602 insertions(+), 0 deletions(-)

nabil@AMELIA:~/src/mcsos$ git log --oneline -n 5
adc1765 docs: add M2 readiness review
80cbc2f M2: add bootable kernel ELF and early serial console
2e39289 M1: add reproducible toolchain readiness baseline
```

Output:

```text
[Tempel output asli di sini.]
```

---

## 9. Hasil Uji

[cite_start]Bagian ini memuat bukti autentik dari seluruh proses kompilasi, pembuatan *image*, dan eksekusi pada emulator QEMU [cite: 1231-1240].

### 9.1 Output `make build` dan `make inspect`
Kompilasi Clang dan proses penautan (LLD) berhasil tanpa *error*.
```text
clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -fno-stack-protector -fno-stack-check -fno-pic -fno-pie -fno-lto -m64 -march=x86-64 -mabi=sysv -mno-red-zone -mno-mmx -mno-sse -mno-sse2 -mcmodel=kernel -Wall -Wextra -Werror -Ikernel/arch/x86_64/include -c kernel/core/kmain.c -o build/kernel/core/kmain.o
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.map -o build/kernel.elf  build/kernel/core/kmain.o  build/kernel/core/serial.o  build/kernel/lib/memory.o
OK: kernel ELF inspection passed
```

### 9.2 Keputusan Desain

| Keputusan | Alternatif yang dipertimbangkan | Alasan memilih | Konsekuensi |
|---|---|---|---|
| Penggunaan **Serial Console** (UART COM1) sebagai output utama | Framebuffer / VGA Text Mode GUI | [cite_start]UART beroperasi murni melalui instruksi I/O port (`inb`/`outb`) yang deterministik dan terisolasi, sehingga lebih stabil untuk pelacakan kegagalan *boot* awal [cite: 53-54, 439-443]. | [cite_start]Sistem operasi awal tidak memiliki antarmuka visual (layar *headless*) dan murni bergantung pada fail log (`qemu-serial.log`) [cite: 79-80]. |
| Implementasi manipulasi memori primitif secara kustom (`memory.c`) | Menggunakan pustaka *host libc* standar (`string.h`) | Kernel *bare-metal* tidak boleh mengandalkan OS *host*. [cite_start]Ketergantungan pada *libc* Linux Ubuntu akan menyebabkan kegagalan *linking* atau *triple fault* saat dijalankan di QEMU [cite: 81-82, 444-447]. | [cite_start]Pengembang harus merekayasa ulang fungsi dasar seperti `memcpy`, `memset`, dan `memmove` dari awal [cite: 448-483]. |
| Penetapan *Bootloader* Limine Protocol | Bootloader GNU GRUB (Multiboot / Multiboot2) | [cite_start]Limine memiliki spesifikasi modern yang mendukung langsung pemuatan (*loading*) arsitektur ELF64 ke memori *higher-half* tanpa memerlukan *hacks* kompilator x86_32 [cite: 101-103]. | [cite_start]Arsitektur OS sangat terikat pada rilis *branch* biner Limine (`v11.x-binary`) dan konfigurasi `limine.conf` [cite: 668-670]. |

### 9.3 Arsitektur Ringkas

mermaid
flowchart TD
    A[Firmware: QEMU + OVMF UEFI] -->|Memuat ISO & Menjalankan EFI| B[Bootloader: Limine]
    B -->|Membaca limine.conf & Memuat ELF64| C[Kernel Entry: kmain]
    C -->|Instruksi outb/inb| D[Driver: Serial COM1]
    D -->|Kanal Observabilitas Awal| E[File: qemu-serial.log]
    C -->|cli; hlt| F[State: Controlled Halt Loop]
    

### 9.4 Kontrak Antarmuka

| Antarmuka | Pemanggil | Penerima | Precondition | Postcondition | Error path |
|---|---|---|---|---|---|
| `[kmain(void)]` | `[Bootloader (Limine)]` | `[Kernel (M2)]` | `[CPU berada dalam arsitektur mode long mode (64-bit), dan stack memori awal sudah disediakan secara valid oleh bootloader .]` | `[Serial console berhasil diinisiasi dan mencetak log, lalu CPU dalam posisi diam tertahan.]` | `[Menghasilkan galat Triple Fault atau QEMU Reboot Loop jika alamat rusak]` |
| `[outb(port, value)]` | `[serial_init, serial_write ]` | `[CPU / Port Eksternal ]` | `[Alamat I/O port harus merupakan register perangkat UART yang terpetakan (mis. 0x3F8 untuk COM1).]` | `[Instruksi rakitan secara langsung menuliskan 8-bit instruksi ke register fisik perangkat keras .]` | `[Pengabaian atau gangguan (hardware exception) interupsi liar jika port tidak eksis.]` |

### 9.5 Struktur Data Utama

| Struktur data | Field penting | Ownership | Lifetime | Invariant |
|---|---|---|---|---|
| `` `[[N/A pada M2]]` `` | `[N/A]` | `[N/A]` | `[N/A]` | `[M2 murni mengeksekusi instruksi primitif. Memori belum dipetakan.]` |
| `` `[Format ELF64]` `` | `[Entry point, PHDRS, LOAD segment]` | `[Skrip LLD Linker]` | `[Statis (Melekat pada kernel.elf)]` | `[Segmen memori text (eksekusi) dan data harus terpisah secara alamat pada ELF-Header 0xffffffff80000000 .  ]` |

### 9.6 Invariants

Invariant yang harus dipegang teguh sepanjang tahapan kompilasi dan eksekusi pada M2:
1. Invariant ELF64: Berkas akhir kernel harus terdeteksi secara utuh sebagai arsitektur Advanced Micro Devices X86-64 bertipe EXEC, bukan skrip, bukan biner Windows (PE), dan bukan objek host Linux standar .  
2. Invariant Freestanding C: Seluruh implementasi C sama sekali tidak boleh menautkan (link) pustaka libc bawaan host eksternal untuk menghindari Undefined Reference .  
3. Invariant Handoff: Fungsi entry point kernel (kmain) mutlak dilarang untuk melakukan perintah return karena OS tidak memiliki sistem bawahan untuk dikembalikan (akan menyebabkan Kernel Panic atau Triple Fault) .  
4. Invariant Stack Protection: Kompilator tidak memanipulasi Red Zone (-mno-red-zone), mengamankan integritas struktur data pada saat interupsi perangkat asinkron menyerang ruang eksekusi stack .  

### 9.7 Ownership, Locking, dan Concurrency

| Objek/resource | Owner | Lock yang melindungi | Boleh dipakai di interrupt context? | Catatan |
|---|---|---|---|---|
| `[Port UART COM1 (0x3F8u)]` | `[Kernel (serial.c)]` | `[None (Lock-free)]` | `[Tidak (Belum diaktifkan)]` | `[Interaksi perangkat dilakukan murni dengan metode busy-wait polling (while (!serial_transmit_empty())) .  ]` |

Lock order yang berlaku:

```text
[Pola hierarki Locking atau sinkronisasi (seperti Spinlock/Mutex) belum diperlukan pada tahap Modul 2. Hal ini dikarenakan:
1. Kernel saat ini beroperasi pada komputasi Single-Core (ketiadaan Symmetric Multiprocessing/SMP) .  
2. Tidak ada Interrupt Request (IRQ), Thread, maupun entitas multitasking yang bersaing memperebutkan akses I/O. Interupsi diamankan dengan eksekusi paksa cli; hlt (Clear Interrupts, Halt CPU) ]
```

### 9.8 Memory Safety dan Undefined Behavior Risk

| Risiko | Lokasi | Mitigasi | Bukti |
|---|---|---|---|
| `[Red Zone Overlap / Stack Corruption]` | `[Flag Kompilator Makefile]` | `[Menonaktifkan asumsi alokasi host compiler terhadap sisa ruang di bawah stack pointer.]` | `[Pemberian perintah -mno-red-zone secara spesifik pada argumen variabel CFLAGS .  ]` |
| `[Pointer Overlap Aliasing]` | `[kernel/lib/memory.c (memmove)]` | `[Melakukan deteksi komparasi overlap posisi pointer alamat pengirim (src) dan memori tujuan (dest) sebelum melakukan penyalinan data forward atau backward .  ]` | `[Keberadaan blok logika percabangan evaluasi alamat memori if (d < s) pada fungsi C murni.  ]` |

### 9.9 Security Boundary

| Boundary | Data tidak tepercaya | Validasi yang dilakukan | Failure mode aman |
|---|---|---|---|
| `[Bootloader Handoff Boundary]` | `[Parameter Info Boot dari Limine (Struktur register data dan alamat memori EFI)]` | `[Kernel secara sengaja menolak/mengabaikan parameter eksternal apapun dari argumen kmain untuk memperkecil risiko permukaan serang (attack surface) pada tahap modul edukasi awal .  ]` | `[Eksekusi terbatas langsung pada serial_write, diikuti gerbang fail-closed di halt_forever() .  ]` |
| `[Supply Chain / Kompilasi Host Boundary]` | `[Biner Host Compiler dan Libc Runtime Ubuntu WSL]` | `[Pra-validasi pemeriksaan simbol fungsional GNU secara statik.]` | `[Skrip make inspect menggunakan perintah inspeksi utilitas nm atau readelf untuk memastikan absennya relokasi fungsional eksternal secara diam-diam. Eksekusi berhenti otomatis (halt process) jika deteksi gagal .  ]` |

---

## 10. Langkah Kerja Implementasi

### Langkah 1 — Pemeriksaan Preflight Lingkungan M2

Maksud langkah:
```text
Memastikan bahwa repositori bersih, berada di lingkungan filesystem Linux WSL (bukan `/mnt/c`), dan fondasi prasyarat M0/M1 (dokumen arsitektur serta objek freestanding M1) tidak rusak sebelum membangun OS Modul 2[cite: 900].

Perintah:

```bash
[./tools/scripts/m2_preflight.sh]
```

Output ringkas:

```text
[== M2 preflight MCSOS 260502 ==
root=/home/nabil/src/mcsos
date_utc=2026-06-12T10:22:48Z
OK filesystem: repository bukan /mnt/c, /mnt/d, atau /mnt/e
...
OK M0 file: docs/architecture/overview.md
OK M1 proof object: ELF64 x86_64
OK: preflight M2 selesai]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[Laporan Preflight]` | `[build/meta/m2-preflight.txt]` | `[Bukti statis bahwa lingkungan kerja memenuhi syarat M2 awal.  ]` |

Indikator berhasil:

```text
[Tidak ada pesan error (exit 1), dan diakhiri dengan baris "OK: preflight M2 selesai"[cite: 368].]
```

### Langkah 2 — `[Pembangunan Infrastruktur Source & Validasi Skrip]`

Maksud langkah:

```text
[Menyusun direktori OS (kernel, arch, configs), mengetikkan kode sumber C minimalis (port I/O, serial driver, runtime memory, kernel entry kmain), linker script, serta memastikan semua skrip shell pengujian valid secara tata bahasa (linting)[cite: 906, 908].]
```

Perintah:

```bash
make check-scripts]
```

Output ringkas:

```text
[# (Setelah perbaikan redirection no-op dengan sed pada m2_preflight.sh)
for s in tools/scripts/*.sh; do bash -n "$s"; done
if command -v shellcheck >/dev/null 2>&1; then shellcheck tools/scripts/*.sh; else echo "WARN: shellcheck tidak tersedia"; fi]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[Kode Sumber Kernel]` | `[kernel/core/ & kernel/lib/]` | `[Implementasi logika boot awal OS .  ]` |
| `[Linker Script]` | `[linker.ld` | `[Skrip pengarah kompilator ke alamat 0xffffffff80000000 .  ]` |

Indikator berhasil:

```text
[Eksekusi make check-scripts (atau bash -n) berjalan tanpa mengembalikan exit status error[cite: 910].]
```

### Langkah 3 — Kompilasi Kernel ELF64 Freestanding

Maksud langkah:

```text
[Membuktikan bahwa kode sumber C yang dibuat dapat dikompilasi oleh Clang (tanpa pustaka Linux host) dan ditautkan (LD.LLD) menjadi berkas kernel OS murni[cite: 914].]
```

Perintah:

```bash
make distclean
make check-src
make build]
```

Output ringkas:

```text
[mkdir -p build/kernel/core/
clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -fno-stack-protector -fno-stack-check -fno-pic -fno-pie -fno-lto -m64 -march=x86-64 -mabi=sysv -mno-red-zone -mno-mmx -mno-sse -mno-sse2 -mcmodel=kernel -Wall -Wextra -Werror -Ikernel/arch/x86_64/include -c kernel/core/kmain.c -o build/kernel/core/kmain.o
...
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.map -o build/kernel.elf  build/kernel/core/kmain.o  build/kernel/core/serial.o  build/kernel/lib/memory.o]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[Biner Kernel]` | `[build/kernel.elf]` | `[Executable OS mentah.  ]` |
| `[Peta Memori Kernel]` | `[build/kernel.map]` | `[Referensi penempatan blok fungsi dan alokasi statis dari LLD.   ]` |

Indikator berhasil:

```text
[Tidak ada compiler warning atau error berantai, dan berkas `kernel.elf` tercipta di direktori build.]
```

### Langkah 4 — Inspeksi Arsitektur Kernel ELF

Maksud langkah:

```text
[Memastikan kernel bukan executable aplikasi Linux/Windows biasa dan entry point fungsi utama ditempatkan pada alamat higher-half sesuai desain linker[cite: 920].]
```

Perintah:

```bash
make inspect]
```

Output ringkas:

```text
[ELF Header:
  Magic:   7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00
  Class:                             ELF64
  Machine:                           Advanced Micro Devices X86-64
  Entry point address:               0xffffffff80000000
...
OK: kernel ELF inspection passed]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[Teks Inspeksi Header]` | `[build/inspect/readelf-header.txt]` | `[Bukti kelas arsitektur target x86_64 . ]` |
| `[Teks Simbol]` | `[build/inspect/nm-symbols.txt]` | `[Bukti eksistensi fungsi kmain.]` |

Indikator berhasil:

```text
[Output menampilkan "Class: ELF64", "Machine: Advanced Micro Devices X86-64", "Entry point: 0xffffffff80000000", serta ditutup oleh pesan "OK: kernel ELF inspection passed" [cite: 636-642, 926-930].]
```

### Langkah 5 — Ekstraksi Bootloader & Perangkaian ISO Image

Maksud langkah:

```text
[Mengunduh komponen bootloader Limine (sebagai pengatur boot UEFI), mengumpulkan semua aset, dan membungkus `kernel.elf` menjadi file biner ISO siap eksekusi (.iso)[cite: 932, 937].]
```

Perintah:

```bash
make image]
```

Output ringkas:

```text
[Cloning into 'third_party/limine'...
...
xorriso 1.5.6 : RockRidge filesystem manipulator, libburnia project.
...
Limine BIOS stages installed successfully.
65cb687d8c0be10041ac0339f10aeb7293b922717e1bab297b40147b6bbd146e  build/mcsos.iso
OK: ISO dibuat pada build/mcsos.iso]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[ISO Image]` | `[build/mcsos.iso]` | `[Berkas bootable untuk sistem virtual/mesin riil.]` |
| `[Checksum SHA-256]` | `[build/mcsos.iso.sha256] ` | `[Penjamin integritas biner berkas ISO.]` |

Indikator berhasil:

```text
[Media ISO dibuat tanpa error dari xorriso dan nilai hash SHA-256 tercetak dengan sukses.]
```

### Langkah 6 — Validasi Runtime Emulator QEMU Headless

Maksud langkah:

```text
[Menguji coba citra ISO pada emulator mesin x86_64 (QEMU) ber-firmware OVMF untuk membuktikan bahwa jalur boot berhasil menyerahkan kendali dari Limine ke kernel kita, dibuktikan lewat penangkapan teks di port serial[cite: 942].]
```

Perintah:

```bash
make run]
```

Output ringkas:

```text
[qemu-system-x86_64: terminating on signal 15 from pid 1144 (timeout)
OK: QEMU serial log valid: build/qemu-serial.log]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[Serial Log]` | `[build/qemu-serial.log]` | `[Fail penangkap teks keluaran dari UART COM1 OS kita.  ]` |

Indikator berhasil:

```text
[QEMU mati terinterupsi timeout 10 detik (normal, karena kernel halt loop), dan log serial berhasil mengonfirmasi ketersediaan pesan marker M2[cite: 945].]
```

### Langkah 7 — Validasi Akhir dan Pengamanan Version Control

Maksud langkah:

```text
[Melakukan pengujian otomatis tingkat akhir (grading) untuk mendeteksi seluruh parameter kelulusan, lalu mengamankan status kode yang berhasil ke dalam Git history[cite: 947, 950].]
```

Perintah:

```bash
make grade
git add Makefile linker.ld configs kernel tools docs
git commit -m "M2: add bootable kernel ELF and early serial console"]
```

Output ringkas:

```text
[OK artifact: build/kernel.elf
OK artifact: build/mcsos.iso
OK artifact: build/qemu-serial.log
OK: M2 local grading checks passed
[main 80cbc2f] M2: add bootable kernel ELF and early serial console]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[Hash Commit]` | `[build/meta/m2-commit.txt]` | `[Identifikasi permanen status OS yang fungsional. ]` |

Indikator berhasil:

```text
[Skrip menampilkan `OK: M2 local grading checks passed` dan repositori mencetak commit hash `80cbc2f`[cite: 897, 953].]
```

---

## 11. Checkpoint Buildable

Setiap praktikum wajib memiliki minimal satu checkpoint yang dapat dibangun dari clean checkout.

| Checkpoint | Perintah | Expected result | Status |
|---|---|---|---|
| Clean build | `make distclean && make build` | Kernel target (`kernel.elf`) dan map memori terbangun tanpa peringatan/error | PASS |
| Metadata preflight | `./tools/scripts/m2_preflight.sh` | File laporan `build/meta/m2-preflight.txt` ada dan berstatus OK | PASS |
| Image generation | `make image` | `build/mcsos.iso` beserta nilai *checksum* SHA-256 terbentuk | PASS |
| QEMU smoke test | `make run` | Log serial `build/qemu-serial.log` memuat tiga *marker* OS M2 | PASS |
| Test suite (Grading) | `make grade` | Seluruh *test* lokal lulus (`OK: M2 local grading checks passed`) | PASS |

Catatan checkpoint:
```text
Seluruh checkpoint dari kompilasi awal (clean build) hingga pengujian otomatis (grading lokal) telah berhasil dilewati secara mulus. Lingkungan pengembangan WSL 2 Ubuntu, Clang, dan LLD terbukti bekerja secara deterministik menghasilkan artefak yang dapat diandalkan pada Modul 2 ini.
```
---

## 12. Perintah Uji dan Validasi

### 12.1 Build Test

Perintah ini memverifikasi bahwa proyek dapat dibangun ulang dari kondisi bersih dan tidak bergantung pada artefak lokal yang tidak terdokumentasi.

```bash
make distclean
make build
```

Hasil:

```text
[clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -fno-stack-protector -fno-stack-check -fno-pic -fno-pie -fno-lto -m64 -march=x86-64 -mabi=sysv -mno-red-zone -mno-mmx -mno-sse -mno-sse2 -mcmodel=kernel -Wall -Wextra -Werror -Ikernel/arch/x86_64/include -c kernel/lib/memory.c -o build/kernel/lib/memory.o
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.map -o build/kernel.elf  build/kernel/core/kmain.o  build/kernel/core/serial.o  build/kernel/lib/memory.o]
```

Status: `[PASS]`

### 12.2 Static Inspection

Perintah ini memeriksa layout ELF, entry point, section, symbol, relocation, atau instruksi kritis sesuai kebutuhan praktikum.

```bash
make inspect
```

Hasil penting:

```text
[Elf file type is EXEC (Executable file)
Entry point 0xffffffff80000000
There are 2 program headers, starting at offset 64

Program Headers:
  Type           Offset   VirtAddr           PhysAddr           FileSiz  MemSiz   Flg Align
  LOAD           0x001000 0xffffffff80000000 0xffffffff80000000 0x00038c 0x00038c R E 0x1000
  LOAD           0x002000 0xffffffff80001000 0xffffffff80001000 0x000068 0x000068 R   0x1000

 Section to Segment mapping:
  Segment Sections...
   00     .text 
   01     .rodata]
```

Status: `[PASS]`

### 12.3 QEMU Smoke Test

Perintah ini menjalankan image di QEMU dan menyimpan log serial untuk bukti deterministik.

```bash
make run
```

Hasil:

```text
[MCSOS 260502 M2 boot path entered
 [M2] early serial online
[M2] kernel reached controlled halt loop]
```

Status: `[PASS]`

### 12.4 GDB Debug Evidence

Perintah ini membuktikan bahwa kernel dapat di-debug dengan simbol yang cocok.

```bash
make debug
```

Di terminal lain:

```bash
gdb build/kernel.elf
target remote localhost:1234
break kmain
continue
```

Hasil:

```text
[[Skenario mode *Remote Debugging* menggunakan GDB merupakan materi pengayaan (*enrichment*) pada Modul 2 dan tidak wajib dieksekusi secara primer pada sesi pelaporan evaluasi utama. Skenario `make run` telah memvalidasi logika boot.]]
```

Status: `[NA]`

### 12.5 Unit Test

```bash
make grade
```

Hasil:

```text
[OK artifact: build/kernel.elf
OK artifact: build/kernel.map
OK artifact: build/inspect/readelf-header.txt
OK artifact: build/inspect/readelf-program-headers.txt
OK artifact: build/inspect/objdump-disassembly.txt
OK artifact: build/inspect/nm-symbols.txt
OK artifact: build/mcsos.iso
OK artifact: build/mcsos.iso.sha256
OK artifact: build/qemu-serial.log
OK: M2 local grading checks passed]
```

Status: `[PASS]`

### 12.6 Stress/Fuzz/Fault Injection Test

Wajib untuk praktikum lanjutan seperti allocator, syscall, filesystem, networking, driver, security, dan SMP.

```bash
[Tidak dijalankan]
```

Hasil:

```text
[[Praktikum M2 berfokus pada tahapan inisialisasi lingkungan *Bootloader* dan awal siklus Kernel (*Early Serial Console*). Uji tekanan sistem, injeksi galat (*Fault Injection*), dan uji *fuzzing* belum dikerjakan karena OS belum memiliki fitur manajemen memori dinamis atau syscall.]]
```

Status: `[NA]`

### 12.7 Visual Evidence

Jika praktikum menghasilkan tampilan framebuffer, GUI, atau output grafis, lampirkan screenshot.

| Screenshot | Lokasi file | Keterangan |
|---|---|---|
| `[NA]` | `[NA]` | `[Praktikum OS Modul 2 dieksekusi murni secara headless (tanpa UI/framebuffer eksternal) dengan melempar parameter -display none ke QEMU. Respons eksekusi dibuktikan secara tekstual dan deterministik lewat keluaran port COM1 di berkas qemu-serial.log.]` |

---

## 13. Hasil Uji

### 13.1 Tabel Ringkasan Hasil

| No. | Uji | Expected result | Actual result | Status | Evidence |
|---|---|---|---|---|---|
| 1 | Validasi Lingkungan (*Preflight*) | Repositori bersih dari Windows Mount, `check_env` valid | Preflight mendeteksi lingkungan kerja yang aman untuk M2 | PASS | `build/meta/m2-preflight.txt` |
| 2 | Kompilasi Kernel ELF64 | Pembuatan `kernel.elf` C *freestanding* tanpa galat | Eksekusi target `make build` selesai tanpa *warning* kritis | PASS | `build/kernel.elf` |
| 3 | Inspeksi Integritas Arsitektur | *Header* biner terdeteksi sebagai mesin `X86-64` dengan *entry point* di `0xffffffff80000000` | Pengecekan otomatis via utilitas `readelf` terverifikasi akurat | PASS | `build/inspect/readelf-header.txt` |
| 4 | Manufaktur *Boot Image* | Integrasi Limine ke dalam sebuah `mcsos.iso` *bootable* | Berkas ISO terakit sukses lewat intervensi perangkat `xorriso` | PASS | `build/mcsos.iso` |
| 5 | *Runtime* QEMU (*Smoke Test*) | Emulator membaca ISO dan menembakkan pesan *boot* ke *port* serial | Log COM1 merekam *marker* `early serial online` sebelum *timeout* | PASS | `build/qemu-serial.log` |
| 6 | *Grading* CI Lokal | Seluruh struktur direktori lulus uji integritas `make grade` | Terminal mencetak `OK: M2 local grading checks passed` | PASS | Log Terminal |

### 13.2 Log Penting

[cite_start]Kutipan keluaran *port* komunikasi serial COM1 yang menangkap aktivitas internal `kernel.elf` saat dijalankan oleh mesin virtual QEMU [cite: 192-196, 793-798]:

```text
MCSOS 260502 M2 boot path entered
 [M2] early serial online
[M2] kernel reached controlled halt loop
```

### 13.3 Artefak Bukti

| Artefak | Path | SHA-256 / hash | Fungsi |
|---|---|---|---|
| `kernel.elf` | `[build/kernel.elf]` | `[[Jalankan: sha256sum build/kernel.elf]]` | `[Executable Kernel Bare-metal utama berformat ELF64.]` |
| `mcsos.iso` / `build/mcsos.iso` | `[build/mcsos.iso]` | `[65cb687d8c0be10041ac0339f10aeb7293b922717e1bab297b40147b6bbd146e]` | `[Media Boot Image berisi Kernel dan Bootloader Limine.]` |
| `qemu-serial.log` | `[build/qemu-serial.log]` | `[[Jalankan: sha256sum build/qemu-serial.log]]` | `[Log observability awal dari UART COM1]` |
| `kernel.map` | `[build/kernel.map]` | `[[Jalankan: sha256sum build/kernel.map]]` | `[Peta memori penempatan statis fungsi dari LLD (linker).]` |
| `objdump.txt` | `[build/inspect/objdump-disassembly.txt]` | `[[Jalankan: sha256sum build/inspect/objdump-disassembly.txt]]` | `[Bukti disassembly translasi instruksi C ke Assembly]` |

Perintah hash:

```bash
sha256sum [path/artefak]
```

---

## 14. Analisis Teknis

### 14.1 Analisis Keberhasilan

```text
[Keberhasilan pengujian dibuktikan secara objektif melalui berkas `qemu-serial.log` yang memuat seluruh marker eksekusi OS [cite: 193-196, 796-798]. Hasil uji berhasil karena desain teknis OS sangat mematuhi prinsip "invariants" M2. Kompilasi dieksekusi dengan argumen `-ffreestanding` dan `-mno-red-zone` untuk mencegah kompiler merangkai asumsi keberadaan pustaka `libc` host, sementara linker `ld.lld` secara akurat meletakkan instruksi `kmain` di blok memori higher-half (`0xffffffff80000000`) [cite: 81-82, 546-550]. Bebasnya kernel dari interupsi eksternal didukung oleh penutupan instruksi di `kmain` menggunakan `cli; hlt` (controlled halt loop), yang mencegah terjadinya *triple fault* [cite: 511-512].]
```

### 14.2 Analisis Kegagalan atau Perbedaan Hasil

```text
[Pada pengujian riil lokal, sistem mengeksekusi `timeout 10s` saat uji coba QEMU, mengeluarkan kode sinyal 15 (SIGTERM)[cite: 789]. Ini bukan sebuah kegagalan (Failure), melainkan respons desain yang sudah diekspektasi (Difference in behavior). Kernel M2 sengaja dirancang untuk berhenti beroperasi secara diam pada siklus "halt_forever()". Karena tidak ada rutin "return" atau "shutdown", QEMU dimatikan paksa setelah batas waktu uji untuk memungkinkan skrip automasi (`make run` dan `make grade`) berlanjut dan membedah fail log serialnya [cite: 511-512, 806-807, 1144].

Satu-satunya kegagalan sintaks murni (*linting error*) terjadi pada skrip `m2_preflight.sh`, di mana utilitas ShellCheck menolak baris redirection kosong `> "$REPORT"` dengan status Error 1 (SC2188) . Perbaikan langsung diaplikasikan dengan merespons *warning* tersebut menggunakan operasi *no-op* titik dua (`: > "$REPORT"`) menggunakan perintah `sed`, sehingga kompilasi kembali berstatus PASS.]
```

### 14.3 Perbandingan dengan Teori

| Konsep teori | Implementasi praktikum | Sesuai/tidak sesuai | Penjelasan |
|---|---|---|---|
| `[Modus Alamat Kernel Tinggi (Higher-half Kernel)]` | `[ Penempatan entry point kernel menggunakan utilitas penaut (LLD).]` | `[ Sesuai ]` | `[ Skrip linker.ld menetapkan segmen di 0xffffffff80000000 dan diinspeksi keakuratannya menggunakan readelf .  ]` |
| `[Kontrak Handoff Bootloader]` | `[ Pelepasan kendali sistem awal dari firmware UEFI ke OS.]` | `[ Sesuai]` | `[ Eksekusi file kernel.elf dikoordinasikan langsung oleh bootloader biner Limine tanpa penanganan peta memori yang rumit .]` |
| `[Memory Runtime Independen (Freestanding)]` | `[Absensi fasilitas standar OS eksternal (string.h). ]` | `[Sesuai ]` | `[ Penyediaan prosedur fungsi primitif mandiri untuk memset, memcpy, dan memmove telah dikerjakan di kernel/lib/memory.c]` |
| `[I/O Port Addressing]` | `[Komunikasi perangkat keras secara langsung (UART) ]` | `[Sesuai ]` | `[ Memanfaatkan sintaks eksekusi inline assembly outb dan inb untuk berdialog dengan port 0x3F8u (COM1) .  ]` |

### 14.4 Kompleksitas dan Kinerja

| Aspek | Estimasi/hasil | Bukti | Catatan |
|---|---|---|---|
| Kompleksitas algoritma | `[Konstan & Linier]` | `[Source code]` | `[serial_putc menggunakan metode iterasi sibuk konstan/O(1) (busy-wait polling) sebelum transmit . Fungsi manipulasi di memory.c berjalan dalam linier/O(N) .]` |
| Waktu build | `[< 2 Detik]` | `[Log terminal kompilasi]` | `[Source tree sangat minimalis . Eksekusi Makefile berlangsung hampir instan karena tidak ada blok logika VFS/PMM.  ]` |
| Waktu boot QEMU | `[10 Detik]` | `[Log make run]` | `[Diakhiri secara terkendali via timeout bash karena berhentinya kernel (Halt) .]` |
| Penggunaan memori | `[N/A]` | `[Log M2]` | `[M2 belum mengimplementasikan Physical/Virtual Memory Manager (PMM/VMM) atau utilitas heap/paging .]` |
| Latensi/throughput | `[N/A]` | `[Log M2]` | `[Tidak diukur. Optimasi kecepatan OS (selain overhead syscall dan penjadwalan) adalah non-goals praktikum fase Boot Path .]` |

---

## 15. Debugging dan Failure Modes

### 15.1 Failure Modes yang Ditemukan

| Failure mode | Gejala | Penyebab sementara | Bukti | Perbaikan |
|---|---|---|---|---|
| `[SC2188 Warning (ShellCheck Linting Error)]` | `[Eksekusi target CI lokal make check-scripts gagal (Error 1).]` | `[Sintaks redirection file pada bash tanpa utilitas pembuka command awal .]` | `[Pesan terminal: ^--^ SC2188 (warning): This redirection doesn't have a command.]` | `[Penginjeksian utilitas no-op (:) sebelum simbol redirection memecahkan masalah.]` |

### 15.2 Failure Modes yang Diantisipasi

| Failure mode | Deteksi | Dampak | Mitigasi |
|---|---|---|---|
| `[QEMU Reboot Loop (Triple Fault)]` | `[Komputer mati-nyala berulang / QEMU tertutup tiba-tiba ketika dijalankan .  ]` | `[Kernel tidak tereksekusi, serial log kosong.]` | `[Pengecekan Entry Point eksplisit dengan instruksi utilitas readelf dan inspeksi file objek dekompilasi menggunakan objdump .]` |
| `[Undefined Symbol Linkage)]` | `[Linker LLD membanting peringatan kompilasi seperti undefined symbol: memcpy .  ]` | `[Pembuatan biner kernel.elf gagal di tempat.]` | `[Mengimpor berkas rutin dasar kernel/lib/memory.c secara mandiri agar kompilator yang mengeksekusi dalam mode freestanding tetap memilki rujukannya .]` |
| `[Repositori NTFS Corruption]` | `[Pesan sistem ERROR: repository berada di filesystem Windows muncul di terminal .  ]` | `[Rusaknya akses bit executable dan injeksi CRLF ke dalam skrip bash.]` | `[Pemindahan hard copy data kerja langsung menuju partisi asal ~/src/mcsos di ekstensi Linux (ext4) milik instalasi WSL 2 .  ]` |

### 15.3 Triage yang Dilakukan

```text
[Prosedur triase diagnosis dipandu oleh lapisan automasi M2 [cite: 91-95]. Jika preflight lolos, lapisan kedua (make build) mendeteksi kesalahan sintaksis di tingkat *compiler*. Lapisan ketiga (`make inspect`) membedah luaran biner statis menggunakan `readelf` dan `objdump` guna mengeliminasi peluang kesalahan instruksi/struktur ELF atau kelalaian *red zone* kompilasi . Jika QEMU bermasalah saat runtime (Lapisan kelima), diagnosis dipusatkan pertama-tama pada fail output `build/qemu-serial.log` dan pembacaan konfigurasi spesifikasi `limine.conf`, baru dilanjutkan observasi dinamis di monitor QEMU menggunakan `gdb-multiarch` [cite: 1035-1041].]
```

### 15.4 Panic Path

Jika terjadi panic, tempel output panic.

```text
[Mekanisme logikal *Panic Path* penuh atau implementasi "Kernel Panic" yang menampilkan baris register sistem dan *backtrace* (seperti pada Linux/BSD) sama sekali belum relevan untuk direkayasa pada M2 karena absennya kapabilitas penanganan rutin interupsi perangkat keras (IDT)[cite: 58, 1181]. Saat ini, ketika OS dihadapkan pada titik penutupan jalan (akhir gerbang eksekusi *kmain*), gerbang penyelamatan utama OS didelegasikan murni ke rutinitas *controlled halt loop* pasif [cite: 511-512]:

__attribute__((noreturn)) static void halt_forever(void) {
    for (;;) {
        __asm__ volatile ("cli; hlt" : : : "memory");
    }
}]
```

---

## 16. Prosedur Rollback

Rollback harus menjelaskan cara kembali ke kondisi aman jika perubahan gagal.

| Skenario rollback | Perintah | Data yang harus diselamatkan | Status |
|---|---|---|---|
| Kembali ke commit awal (M1) | `git checkout 2e39289` | Dokumentasi log atau *script* sementara jika ada | Belum teruji |
| Revert commit praktikum (M2) | `git revert 80cbc2f` | Tidak ada | Belum teruji |
| Bersihkan artefak build | `make distclean` | Source code aman | Teruji |
| Regenerasi image | `make image` | Image ISO lama tertimpa | Teruji |

Catatan rollback:

```text
Skenario pembersihan (clean) dan regenerasi fail ISO telah teruji secara aktif selama siklus kompilasi berulang di M2. Skenario "git revert" dan "git checkout" belum dieksekusi secara langsung dalam sesi praktikum ini karena seluruh kompilasi awal berhasil dengan baik. Jika sewaktu-waktu Modul 3 merusak source code Modul 2, rollback ke commit `80cbc2f` adalah titik pemulihan (*restore point*) resmi yang paling aman.
```
---

## 17. Keamanan dan Reliability

### 17.1 Risiko Keamanan

| Risiko | Boundary | Dampak | Mitigasi | Evidence |
|---|---|---|---|---|
| `[Eksekusi rantai pasok (Supply Chain) bermasalah dari Bootloader ]` | `[ Bootloader (Limine)]` | `[Pengambilalihan kendali eksekusi sebelum kmain dijalankan. ]` | `[ Mengunci klon Limine murni pada cabang biner resmi (v11.x-binary) tanpa membangun ulang dari sumber yang tidak diketahui. ]` | `[ Log skrip fetch_limine.sh dan berkas build/meta/limine-revision.txt .  ]` |
| `[Stack Corruption akibat interupsi asinkron ]` | `[ Host Compiler (Clang ABI)]` | `[ Kerusakan struktur memori kernel M2 (kernel panic/hang).]` | `[ Memaksa kompilator menonaktifkan Red Zone (-mno-red-zone) di Makefile]` | `[Argumen kompilasi di Makefile .]` |

### 17.2 Reliability dan Data Integrity

| Risiko reliability | Dampak | Deteksi | Mitigasi |
|---|---|---|---|
| `[Kemacetan eksekusi awal (Hang) ]` | `[ QEMU diam tanpa output, OS gagal melakukan boot. ]` | `[ Serial log (qemu-serial.log) kosong atau timeout melampaui batas tanpa sinyal dari OS.]` | `[Menempatkan instruksi driver serial serial_write langsung pada baris pertama kmain sebelum operasi apapun . ]` |
| `[ Reboot Loop akibat Triple Fault]` | `[Emulator mesin virtual akan melakukan proses restart secara tak berkesudahan.  ]` | `[QEMU keluar dengan status galat tak terduga (bukan interupsi skrip timeout standar). ]` | `[Mencegah OS M2 melakukan return di akhir fungsi utama dengan menjebaknya di halt_forever() (cli; hlt) . ]` |

### 17.3 Negative Test

| Negative test | Input buruk | Expected result | Actual result | Status |
|---|---|---|---|---|
| `[Injeksi parameter Bootloader dari limine.conf]` | `[--invalid-args]` | `[Kernel M2 tidak memproses masukan eksternal (mengabaikan argumen).]` | `[Pengujian overflow kompleks belum dapat dilakukan di M2.]` | `[NA]` |
| `[Uji Buffer Overflowf]` | `[Masukan panjang pada serial_write]` | `[Crash / OS gagal mencetak]` | `[Pengujian overflow kompleks belum dapat dilakukan di M2.]` | `[NA]` |

---

## 18. Pembagian Kerja Kelompok

Isi bagian ini hanya jika praktikum dikerjakan berkelompok. Untuk pengerjaan individu, tulis “Tidak berlaku”.

| Nama | NIM | Peran | Kontribusi teknis | Commit/artefak |
|---|---|---|---|---|
| `Muhamad Nabil` | `2583207073017` | `Ketua / Implementasi` | `Pembangunan skrip bash dan lainya di terminal wsl.` | `adc1765` |
| `Marko Ali Musa` | `25842074006` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `adc1765` |
| `Muharam Alfarizi` | `25832074002` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `adc1765` |

### 18.1 Mekanisme Koordinasi

```text
[```text
Koordinasi kelompok dilakukan secara terpusat dengan pembagian tugas yang spesifik. Seluruh pengembangan arsitektur OS, modifikasi skrip Bash, pengujian di lingkungan Linux WSL, dan eksekusi emulator QEMU dikerjakan secara eksklusif oleh Ketua Kelompok (Nabil). Repositori utama dikelola secara lokal. 

Sementara itu, proses penyusunan laporan dikerjakan oleh Anggota (Marko dan Muharam) dengan cara mengumpulkan log terminal, mengompilasi screenshot Framebuffer, dan menyusun format Markdown sesuai standar yang diminta.]
```

### 18.2 Evaluasi Kontribusi

| Anggota | Persentase kontribusi yang disepakati | Bukti | Catatan |
|---|---:|---|---|
| `[Muhamad Nabil]` | `[100%]` | `[Log Git, Source Code, Skrip Bash]` | `[bekerja dengan baik]` |
| `[Marko Ali Musa]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |
| `[Muharam Alfarizi]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |


---

## 19. Kriteria Lulus Praktikum

Bagian ini wajib diisi. Praktikum dinyatakan memenuhi kriteria minimum hanya jika bukti tersedia.

| Kriteria minimum | Status | Evidence |
|---|---|---|
| Proyek dapat dibangun dari clean checkout | ` PASS`  | Output `make distclean && make build` [Bab 9.1] |
| Perintah build terdokumentasi | ` PASS`  | Bab 10 (Langkah Kerja Implementasi) |
| QEMU boot atau test target berjalan deterministik | ` PASS`  | `build/qemu-serial.log` [Bab 9.4] |
| Semua unit test/praktikum test relevan lulus | ` PASS`  | Log `make grade` ` menunjukkan OK [Bab 12.5]`  |
| Log serial disimpan | PASS | Tersimpan di `build/qemu-serial.log` |
| Panic path terbaca atau dijelaskan jika belum relevan | ` PASS`  | ` Dijelaskan di Bab 15.4 (Belum relevan, didelegasikan ke halt_forever)`  |
| Tidak ada warning kritis pada build | ` PASS`  | ` Output make build bersih`  |
| Perubahan Git terkomit | ` PASS`  | Commit hash `adc1765` dan `80cbc2f` |
| Desain dan failure mode dijelaskan | ` PASS`  | ` Bab 9 (Desain) & Bab 15 (Failure Modes)`  |
| Laporan berisi screenshot/log yang cukup | ` PASS`  | ` Log disisipkan di Bab 9, 12, 13, dan Lampiran`  |

Kriteria tambahan untuk praktikum lanjutan:

| Kriteria lanjutan | Status | Evidence |
|---|---|---|
| Static analysis dijalankan | ` PASS`  | `make check-scripts` (ShellCheck) |
| Stress test dijalankan | ` NA`  | ` Belum relevan untuk target M2`  |
| Fuzzing atau malformed-input test dijalankan | ` NA`  | ` Belum relevan untuk target M2`  |
| Fault injection dijalankan | ` NA`  | ` Belum relevan untuk target M2`  |
| Disassembly/readelf evidence tersedia | ` PASS`  | `build/inspect/readelf-header.txt` |
| Review keamanan dilakukan | ` PASS`  | ` Bab 17.1 (Risiko Keamanan)`  |
| Rollback diuji | ` PASS`  | ` Bab 16 (Pembersihan via make distclean)`  |

---

## 20. Readiness Review

Pilih satu status dengan alasan berbasis bukti.

| Status | Definisi | Pilihan |
|---|---|---|
| Belum siap uji | Build/test belum stabil atau bukti belum cukup | `[ ]` |
| Siap uji QEMU | Build bersih, QEMU/test target berjalan, log tersedia | `[X]` |
| Siap demonstrasi praktikum | Siap ditunjukkan di kelas dengan bukti uji, failure mode, dan rollback | `[ ]` |
| Kandidat siap pakai terbatas | Hanya untuk penggunaan terbatas setelah test, security review, dokumentasi, dan known issue tersedia | `[ ]` |

Alasan readiness:

```text
Status "Siap uji QEMU" diklaim karena kode sumber M2 telah berhasil melewati seluruh lapisan inspeksi lokal tanpa intervensi manual. Biner `kernel.elf` divalidasi keutuhannya sebagai arsitektur `x86_64` oleh utilitas `readelf`, *image* `mcsos.iso` tercipta dengan verifikasi *hash* SHA-256 yang terekam, dan eksekusi pada *emulator* QEMU Headless terbukti deterministik dengan ditangkapnya seluruh *marker boot* pada fail log serial UART (COM1).
```
Known issues:

| No. | Issue | Dampak | Workaround | Target perbaikan |
|---|---|---|---|---|
| 1 | `[Kernel Macet Terkendali (Halt)]` | `[Eksekusi make run akan terlihat seperti hang (diam tak merespons) di terminal.]` | `[Skrip peluncur QEMU diinjeksi dengan perintah utilitas pembunuh waktu timeout 10s agar proses rilis dan berlanjut ke skrip berikutnya.]` | `[M3 (Implementasi Panic Path & GDB dinamis)]` |

Keputusan akhir:

```text
[Berdasarkan bukti kompilasi statik yang bersih (freestanding tanpa host libc), inspeksi format ELF64, dan luaran qemu-serial.log yang deterministik, hasil praktikum ini sah dan layak disebut "Siap uji QEMU tahap awal" untuk milestone M2. OS ini belum layak mendemonstrasikan kapabilitas operasional utuh karena belum memiliki manajemen interupsi perangkat keras (IDT) dan manajemen memori.]
```

---

## 21. Rubrik Penilaian 100 Poin

| Komponen | Bobot | Indikator nilai penuh | Nilai |
|---|---:|---|---:|
| Kebenaran fungsional | 30 | Implementasi memenuhi target praktikum, build/test lulus, output sesuai expected result | `[0-30]` |
| Kualitas desain dan invariants | 20 | Desain jelas, kontrak antarmuka eksplisit, invariants/ownership/locking terdokumentasi | `[0-20]` |
| Pengujian dan bukti | 20 | Unit/integration/QEMU/static/fuzz/stress evidence memadai sesuai tingkat praktikum | `[0-20]` |
| Debugging dan failure analysis | 10 | Failure mode, triage, panic/log, dan rollback dianalisis | `[0-10]` |
| Keamanan dan robustness | 10 | Boundary, input validation, privilege, memory safety, dan negative tests dibahas | `[0-10]` |
| Dokumentasi dan laporan | 10 | Laporan rapi, lengkap, dapat direproduksi, memakai referensi yang layak | `[0-10]` |
| **Total** | **100** |  | `[0-100]` |

Catatan penilai:

```text
[Diisi dosen/asisten.]
```

---

## 22. Kesimpulan

### 22.1 Yang Berhasil

```text
[Praktikum ini sukses merekayasa arsitektur perpindahan kendali dari Firmware (OVMF) ke Bootloader (Limine), lalu menembak tereksekusinya Kernel Entry murni. Proses kompilasi menggunakan kompilator Clang dan LLD Linker berhasil menegakkan invariant `freestanding` (tanpa keterlibatan sistem host), memetakan instruksi pada memori tinggi (higher-half), dan menghidupkan port serial komunikasi (UART 16550) secara deterministik tanpa crash bawaan.]
```

### 22.2 Yang Belum Berhasil

```text
[M2 bersifat non-goal pada komputasi lanjutan. Sehingga sistem operasi primitif ini belum berhasil (atau lebih tepatnya belum ditujukan) untuk menerima input papan ketik dari user (interrupt handling), tidak bisa mengalokasikan memori dinamis (PMM/VMM), dan tidak memiliki sistem penanganan galat aktif di luar penguncian sirkuit CPU pasif (Halt).]
```

### 22.3 Rencana Perbaikan

```text
[Langkah logis untuk Modul 3 (M3) adalah membongkar fungsi `halt_forever` dan menggantikannya dengan sistem Observability Awal & Panic Path yang terstruktur. Ini termasuk memetakan tautan simbol (Linker Map) secara terprogram agar Kernel M2 kelak dapat melaporkan di fungsi mana sistemnya mengalami kerusakan secara presisi (Backtrace Debugging).]
```

---

## 23. Lampiran

### Lampiran A — Commit Log

```text
[adc1765 docs: add M2 readiness review
80cbc2f M2: add bootable kernel ELF and early serial console
2e39289 M1: add reproducible toolchain readiness baseline]
```

### Lampiran B — Diff Ringkas

```diff
[18 files changed, 602 insertions(+), 0 deletions(-)
 create mode 100644 kernel/arch/x86_64/include/mcsos/arch/io.h
 create mode 100644 kernel/core/kmain.c
 create mode 100644 kernel/core/serial.c
 create mode 100644 linker.ld
 create mode 100644 Makefile]
```

### Lampiran C — Log Build Lengkap

```text
[mkdir -p build/kernel/core/
clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -fno-stack-protector -fno-stack-check -fno-pic -fno-pie -fno-lto -m64 -march=x86-64 -mabi=sysv -mno-red-zone -mno-mmx -mno-sse -mno-sse2 -mcmodel=kernel -Wall -Wextra -Werror -Ikernel/arch/x86_64/include -c kernel/core/kmain.c -o build/kernel/core/kmain.o
mkdir -p build/kernel/core/
clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -fno-stack-protector -fno-stack-check -fno-pic -fno-pie -fno-lto -m64 -march=x86-64 -mabi=sysv -mno-red-zone -mno-mmx -mno-sse -mno-sse2 -mcmodel=kernel -Wall -Wextra -Werror -Ikernel/arch/x86_64/include -c kernel/core/serial.c -o build/kernel/core/serial.o
mkdir -p build/kernel/lib/
clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -fno-stack-protector -fno-stack-check -fno-pic -fno-pie -fno-lto -m64 -march=x86-64 -mabi=sysv -mno-red-zone -mno-mmx -mno-sse -mno-sse2 -mcmodel=kernel -Wall -Wextra -Werror -Ikernel/arch/x86_64/include -c kernel/lib/memory.c -o build/kernel/lib/memory.o
mkdir -p build
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.map -o build/kernel.elf  build/kernel/core/kmain.o  build/kernel/core/serial.o  build/kernel/lib/memory.o]
```

### Lampiran D — Log QEMU Lengkap

```text
[MCSOS 260502 M2 boot path entered
 [M2] early serial online
[M2] kernel reached controlled halt loop]
```

### Lampiran E — Output Readelf/Objdump

```text
[ELF Header:
  Magic:   7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00 
  Class:                             ELF64
  Data:                              2's complement, little endian
  Version:                           1 (current)
  OS/ABI:                            UNIX - System V
  ABI Version:                       0
  Type:                              EXEC (Executable file)
  Machine:                           Advanced Micro Devices X86-64
  Entry point address:               0xffffffff80000000.]
```

### Lampiran F — Screenshot

| No. | File | Keterangan |
|---|---|---|
| 1 | `[[NA]]` | `[Praktikum M2 tidak menuntut pembuktian visual / berbasis tangkapan layar antarmuka pengguna karena dijalankan di QEMU mode Headless (-display none).]` |

### Lampiran G — Bukti Tambahan

```text
[[Output Grading Akhir Lokal di Terminal]
OK artifact: build/kernel.elf
OK artifact: build/kernel.map
OK artifact: build/inspect/readelf-header.txt
OK artifact: build/inspect/readelf-program-headers.txt
OK artifact: build/inspect/objdump-disassembly.txt
OK artifact: build/inspect/nm-symbols.txt
OK artifact: build/mcsos.iso
OK artifact: build/mcsos.iso.sha256
OK artifact: build/qemu-serial.log
OK: M2 local grading checks passed]
```

---

## 24. Daftar Referensi

Gunakan format IEEE. Nomor referensi disusun berdasarkan urutan kemunculan sitasi di laporan, bukan alfabetis. Contoh format:

```text
[1] R. H. Arpaci-Dusseau and A. C. Arpaci-Dusseau, Operating Systems: Three Easy Pieces. Madison, WI, USA: Arpaci-Dusseau Books, [tahun/edisi yang digunakan]. [Online]. Available: [URL]. Accessed: [tanggal akses].

[2] R. Cox, F. Kaashoek, and R. Morris, “xv6: a simple, Unix-like teaching operating system,” MIT PDOS. [Online]. Available: [URL]. Accessed: [tanggal akses].

[3] Intel Corporation, Intel 64 and IA-32 Architectures Software Developer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[4] Advanced Micro Devices, AMD64 Architecture Programmer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[5] UEFI Forum, Unified Extensible Firmware Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].

[6] ACPI Specification Working Group, Advanced Configuration and Power Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].
```

Referensi yang benar-benar dipakai dalam laporan:

```text
[1] LLVM Project, "Clang Compiler User's Manual - Freestanding Builds". [Online]. Available: [https://clang.llvm.org/docs/UsersManual.html](https://clang.llvm.org/docs/UsersManual.html). Accessed: 2026-06-12.

[2] Limine Bootloader Project, "Limine Bare Bones", OSDev Wiki. [Online]. Available: [https://wiki.osdev.org/Limine_Bare_Bones](https://wiki.osdev.org/Limine_Bare_Bones). Accessed: 2026-06-12.

[3] Advanced Micro Devices, AMD64 Architecture Programmer’s Manual Volume 2: System Programming. [Online]. Available: [https://www.amd.com/system/files/TechDocs/24593.pdf](https://www.amd.com/system/files/TechDocs/24593.pdf). Accessed: 2026-06-12.
```
---

## 25. Checklist Final Sebelum Pengumpulan

| Checklist | Status |
|---|---|
| Semua placeholder `[isi ...]` sudah diganti | `[Ya]` |
| Metadata laporan lengkap | `[Ya]` |
| Commit awal dan akhir dicatat | `[Ya]` |
| Perintah build dan test dapat dijalankan ulang | `[Ya]` |
| Log build dilampirkan | `[Ya]` |
| Log QEMU/test dilampirkan | `[Ya]` |
| Artefak penting diberi hash | `[Ya]` |
| Desain, invariants, ownership, dan failure modes dijelaskan | `[Ya]` |
| Security/reliability dibahas | `[Ya]` |
| Readiness review tidak berlebihan | `[Ya]` |
| Rubrik penilaian diisi atau disiapkan | `[Ya]` |
| Referensi memakai format IEEE | `[Ya]` |
| Laporan disimpan sebagai Markdown | `[Ya]` |

---

## 26. Pernyataan Pengumpulan

Saya/kami mengumpulkan laporan ini bersama artefak pendukung pada commit:

```text
[adc1765 ]
```

Status akhir yang diklaim:

```text
[Siap uji QEMU tahap M2]
```

Ringkasan satu paragraf:

```text
[Praktikum Modul 2 untuk sistem operasi MCSOS 260502 telah berhasil membuktikan pembuatan arsitektur boot path deterministik. Kode sumber C murni diintegrasikan bersama skrip linker untuk menghasilkan kernel ELF64 x86_64 berlandaskan mode freestanding. Berkas image bootable (`mcsos.iso`) yang memuat protokol Limine berhasil diluncurkan via QEMU UEFI (OVMF), dengan catatan keberhasilan terekam transparan pada log komunikasi port UART awal. Laporan dibatasi hanya untuk bukti operasional gerbang awal dan ditutup sebelum mengeksplorasi infrastruktur manajemen interupsi.]
```
