# Template Laporan Praktikum Sistem Operasi Lanjut — MCSOS

**Nama file laporan:** `laporan_praktikum_[kode_praktikum]_[nim_atau_kelompok].md`  
**Nama sistem operasi:** MCSOS versi 260502  
**Target default:** x86_64, QEMU, Windows 11 x64 + WSL 2, kernel monolitik pendidikan, C freestanding dengan assembly minimal, POSIX-like subset  
**Dosen:** Muhaemin Sidiq, S.Pd., M.Pd.  
**Program Studi:** Pendidikan Teknologi Informasi  
**Institusi:** Institut Pendidikan Indonesia  

> Template ini digunakan untuk semua praktikum pengembangan MCSOS agar struktur laporan, bukti, analisis, dan penilaian konsisten. Ganti seluruh teks bertanda `[isi ...]` dengan data praktikum sebenarnya. Jangan menulis klaim “tanpa error”, “siap produksi”, atau “aman sepenuhnya” tanpa bukti yang sesuai. Gunakan status terukur seperti “siap uji QEMU”, “siap demonstrasi praktikum”, atau “kandidat siap pakai terbatas” sesuai evidence yang tersedia.

---

## 0. Metadata Laporan

| Atribut | Isi |
|---|---|
| Kode praktikum | `M4` |
| Judul praktikum | `cite_start Interrupt Descriptor Table, Exception Trap Path, Trap Frame, dan Fault-Handling Awal` |
| Jenis pengerjaan | `Kelompok` |
| Nama mahasiswa | `[-]` |
| NIM | `[-]` |
| Kelas | `1B` |
| Nama kelompok | `Kelompok Nabil, Marko, Muharam` |
| Anggota kelompok | `Muhamad Nabil (2583207073017) Implementasu, Marko Ali Musa (25842074006) menyusun laporan, Muharam Alfarizi (25832074002 menyusun laporan)` |
| Tanggal praktikum | `2026-06- ` |
| Tanggal pengumpulan | `2026-06- ` |
| Repository | `~/src/mcsos` |
| Branch | `m4-idt-exception-path` |
| Commit awal | `4134947` |
| Commit akhir | `b37e980` |
| Status readiness yang diklaim | `Siap uji QEMU` |

---

## 1. Sampul

# Laporan Praktikum `[M4]`  
## `[cite_start Interrupt Descriptor Table, Exception Trap Path, Trap Frame, dan Fault-Handling Awal]`

Disusun oleh:

| Nama | NIM | Kelas | Peran |
|---|---|---|---|
| `[Muhamad nabil]` | `[2583207073017]` | `[Kelas 1B]` | `[Ketua / Implementasi / Pengujian]` |
| `[Marko ali musa]` | `[25842074006]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / menyusun Laporan]` |
| `[Muharam alfarizi]` | `[25832074002]` | `[Kelas 1B]` | `[Anggota / Dokumentasi / Menyusun Laporan]` |

Dosen Pengampu: **Muhaemin Sidiq, S.Pd., M.Pd.**  
Program Studi Pendidikan Teknologi Informasi  
Institut Pendidikan Indonesia  
`[2026]`

---

## 2. Pernyataan Orisinalitas dan Integritas Akademik

Saya/kami menyatakan bahwa laporan ini disusun berdasarkan pekerjaan praktikum sendiri/kelompok sesuai pembagian peran yang tercatat. Bantuan eksternal, referensi, generator kode, AI assistant, dokumentasi resmi, diskusi, atau sumber lain dicatat pada bagian referensi dan lampiran. Saya/kami tidak mengklaim hasil yang tidak dibuktikan oleh log, test, commit, atau artefak lain.

| Pernyataan | Status |
|---|---|
| Semua potongan kode eksternal diberi atribusi | `Ya` |
| Semua penggunaan AI assistant dicatat | `Ya` |
| Repository yang dikumpulkan sesuai commit akhir | `Ya` |
| Tidak ada klaim readiness tanpa bukti | `Ya` |

Catatan penggunaan bantuan eksternal:

```text
- Alat: Google Gemini (AI Assistant).
- Prompt ringkas: Meminta panduan penyesuaian instruksi dan perbaikan *typo* pada kompilasi assembler (GNU GAS) untuk Modul 4 dari PDF panduan praktikum.
- Sumber: Interaksi berbasis dokumen "OS_panduan_M4.pdf".
- Bagian yang dibantu: Perbaikan direktif `.size` absolut pada berkas `isr.S`, penataan skrip Makefile, injeksi logik QEMU M4 run script, dan perumusan dokumen laporan akhir.
- Verifikasi mandiri: Seluruh baris kode dikompilasi, diaudit statis dengan skrip preflight, serta divalidasi respons terminal dan emulator (QEMU).
```

---

## 3. Tujuan Praktikum

Tuliskan tujuan teknis dan konseptual praktikum. Tujuan harus dapat diuji.

1. `[Tujuan teknis 1: Membuat struktur IDT (Interrupt Descriptor Table) untuk mode 64-bit yang sejajar secara kompilasi, serta mendeklarasikan 32 vektor exception (0-31) .]`
2. `[Tujuan teknis 2: Menerapkan Assembly Stubs minimalis untuk menormalisasi interupsi CPU (dengan dan tanpa error code) menjadi struktur Trap Frame yang terpadu (x86_64_trap_frame_t) sebelum mengoperkannya ke Dispatcher C .]`
3. `[Tujuan konseptual 1: Membuktikan bahwa interupsi yang dapat dipulihkan (seperti Breakpoint / #BP) dapat dieksekusi melalui pemicu int3, mengembalikan eksekusi dengan iretq, sedangkan jebakan bahaya lainnya dipaksa masuk ke jalur terminasi darurat (Panic Fail-Closed) .]`
4. `[Tujuan validasi: Membuktikan stabilitas instruksi rakitan (LIDT & IRETQ) secara forensik memalui luaran deterministik objdump dan skrip audit nm, serta mengekstrak keseluruhan bukti ke dalam evidence/M4/manifest.txt.]`

---

## 4. Capaian Pembelajaran Praktikum

Setelah praktikum ini, mahasiswa mampu:

| CPL/CPMK praktikum | Bukti yang harus ditunjukkan |
|---|---|
| `[capaian 1]` | `[log, screenshot, test, diff, diagram, analisis]` |
| `[capaian 2]` | `[log, screenshot, test, diff, diagram, analisis]` |
| `[capaian 3]` | `[log, screenshot, test, diff, diagram, analisis]` |

---

## 5. Peta Milestone MCSOS

Centang milestone yang menjadi fokus laporan ini. Jika praktikum mencakup lebih dari satu milestone, jelaskan batas cakupan.

| Milestone | Fokus | Status dalam laporan |
|---|---|---|
| M0 | Requirements, governance, baseline arsitektur | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M1 | Toolchain reproducible, Git, QEMU, GDB, metadata build | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M2 | Boot image, kernel ELF64, early console | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M3 | Panic path, linker map, GDB, observability awal | `[ ] tidak dibahas / [ ] dibahas / [x] selesai praktikum` |
| M4 | Trap, exception, interrupt, timer | `[ ] tidak dibahas / [x] dibahas / [ ] selesai praktikum` |
| M5 | PMM, VMM, page table, kernel heap | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M6 | Thread, scheduler, synchronization | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M7 | Syscall ABI dan user program loader | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M8 | VFS, file descriptor, ramfs | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M9 | Block layer dan device model | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M10 | Persistent filesystem, mcsfs/ext2-like, recovery | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M11 | Networking stack, packet parsing, UDP/TCP subset | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M12 | Security model, capability/ACL, syscall fuzzing, hardening | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M13 | SMP, scalability, lock stress, NUMA-aware preparation | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M14 | Framebuffer, graphics console, visual regression | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M15 | Virtualization/container subset | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |
| M16 | Observability, update/rollback, release image, readiness review | `[x] tidak dibahas / [ ] dibahas / [ ] selesai praktikum` |

Batas cakupan praktikum:

```text
[Praktikum M4 secara eksplisit dibatasi hanya pada implementasi CPU Exception Vectors 0-31 (misalnya #BP, #GP, #PF, dll.). Sistem secara sah menginisiasi IDT statis dan merutekan interupsi eksperimental.

NON-GOALS (Batasan Tegas):
Praktikum ini tidak menyentuh pengaturan perangkat interrupt asinkron seperti Programmable Interrupt Controller (PIC), Advanced Programmable Interrupt Controller (APIC), interrupt jaringan (IRQ), timer/HPET, serta tidak ada penjadwal preemptive (Preemptive Scheduling) maupun subsistem pengguna/Userspace [cite: 30, 39-40].]
```

---

## 6. Dasar Teori Ringkas

Tuliskan teori yang langsung diperlukan untuk memahami praktikum. Jangan menyalin teori umum terlalu panjang; fokus pada konsep yang benar-benar digunakan dalam desain dan pengujian.

### 6.1 Konsep Sistem Operasi yang Diuji

```text
[Praktikum ini memperkenalkan CPU Trap Handling menggunakan IDT (Interrupt Descriptor Table). IDT adalah struktur memori yang bertugas menampung daftar alamat fungsi penyelesai masalah (Handler) bagi berbagai interupsi dan anomali arsitektural (Exception). IDT M4 dikompilasi secara terprogram untuk menyuntikkan instruksi khusus (lidt) agar mendelegasikan alur eksekusi dari Assembly Stub tingkat rendah (isr.S) menuju fungsi pemecah yang terbaca logika (Trap Dispatcher C) saat kondisi kritis terjadi [cite: 13-19, 25-27].]
```

### 6.2 Konsep Arsitektur x86_64 yang Relevan

| Konsep | Relevansi pada praktikum | Bukti/verifikasi |
|---|---|---|
| `[IDTR & lidt ]` | `[ Register IDTR menyimpan alamat dan batas memori tabel IDT. lidt wajib dipanggil sebelum IDT aktif.]` | `[Tercetaknya idt_base dan idt_limit di Log QEMU. Instruksi lidt ditemukan pada objdump]` |
| `[Trap Frame Alignment]` | `[ OS wajib memastikan tata letak dan penanganan register antara Assembly (pushq) vs C-Struct sejalan. Khususnya penyisipan error-code dummy (0) pada vektor yang tak memilikinya.]` | `[ Keberhasilan skrip m4_audit_elf.sh memetakan simbol x86_64_exception_stubs.]` |
| `[ Instruction int3 & iretq]` | `[Vektor 3 (#BP) sengaja dipanggil untuk menguji kembalinya laju eksekusi perangkat CPU via utilitas pengembali interupsi (iretq).]` | `[ Log tercetak [M4] returned from breakpoint handler. Instruksi iretq terdeteksi di fail dekompilasi ELF.]` |

### 6.3 Konsep Implementasi Freestanding

| Aspek | Keputusan praktikum |
|---|---|
| Bahasa | `[C17 freestanding dan Assembly mesin (GNU GAS).  ]` |
| Runtime | `[Murni tanpa campur tangan libc dari host Linux.]` |
| ABI | `[Menghormati spesifikasi panggilan x86_64 System V.]` |
| Compiler flags kritis | `[--target=x86_64-unknown-none-elf, -ffreestanding, -nostdlib, dan -mno-red-zone untuk menghindari stack-corruption.]` |
| Risiko undefined behavior | `[Galat di handler stub dapat memicu Infinite Fault Loop, Triple Fault, atau kembali ke status memori berpotensi fatal (#GP, #PF) jika tidak dinormalisasi.]` |

### 6.4 Referensi Teori yang Digunakan

| No. | Sumber | Bagian yang digunakan | Alasan relevansi |
|---|---|---|---|
| `[1]` | `[Intel Corporation, Intel 64 and IA-32 Architectures Software Developer's Manuals]` | `[Volume 3: Exception Handling]` | `[Standar mutlak panduan struktur/pemetaan tabel memori untuk OS x86_64, serta format instruksi IDT 16 byte.  ]` |

---

## 7. Lingkungan Praktikum

### 7.1 Host dan Target

| Komponen | Nilai |
|---|---|
| Host OS | `[Windows 11 x64]` |
| Lingkungan build | `[WSL 2 Ubuntu]` |
| Target ISA | `x86_64` |
| Target ABI | `[x86_64-unknown-none-elf]` |
| Emulator | `[QEMU emulator version 10.2.1]` |
| Firmware emulator | `[OVMF versi/path ...]` |
| Debugger | `[GNU gdb]` |
| Build system | `[Make/CMake/Meson/Ninja]` |
| Bahasa utama | `[C17 freestanding]` |
| Assembly | `[NASM/GAS versi ...]` |

### 7.2 Versi Toolchain

Tempel output versi toolchain berikut. Jalankan dari clean shell WSL.

```bash
date_utc=2026-06-14T00:14:03Z
Linux AMELIA 6.6.114.1-microsoft-standard-WSL2 #1 SMP PREEMPT_DYNAMIC Mon Dec 1 20:46:23 UTC 2025 x86_64 GNU/Linux
git version 2.53.0
GNU Make 4.4.1
cmake version 4.2.3
1.13.2
Ubuntu clang version 21.1.8 (6ubuntu1)
gcc (Ubuntu 15.2.0-16ubuntu1) 15.2.0
Ubuntu LLD 21.1.8 (compatible with GNU linkers)
NASM version 3.01
QEMU emulator version 10.2.1 (Debian 1:10.2.1+ds-1ubuntu3)
GNU gdb (Ubuntu 17.1-2ubuntu1) 17.1
```

Output:

```text
[Tempel output asli di sini.]
```

### 7.3 Lokasi Repository

| Item | Nilai |
|---|---|
| Path repository di WSL | `` `[~/src/mcsos]` `` |
| Apakah berada di filesystem Linux WSL, bukan `/mnt/c` | `[Ya]` |
| Remote repository | `[ - ]` |
| Branch | `[m4-idt-exception-path]` |
| Commit hash awal | `` `[4134947]` `` |
| Commit hash akhir | `` `[b37e980]` `` |

---

## 8. Repository dan Struktur File

### 8.1 Struktur Direktori yang Relevan

Tampilkan hanya direktori dan file yang relevan dengan praktikum.

```text
[mcsos/
├── evidence/
│   └── M4/
│       ├── kernel.disasm.txt
│       ├── kernel.readelf.header.txt
│       ├── kernel.readelf.programs.txt
│       ├── kernel.syms.txt
│       └── manifest.txt
├── kernel/
│   ├── arch/x86_64/
│   │   ├── include/mcsos/arch/
│   │   │   ├── idt.h
│   │   │   └── isr.h
│   │   ├── idt.c
│   │   └── isr.S
│   ├── core/
│   │   ├── kmain.c
│   │   └── trap.c
│   └── include/mcsos/kernel/
│       └── version.h
├── Makefile
└── tools/
    ├── gdb_m4.gdb
    └── scripts/
        ├── grade_m4.sh
        ├── m4_audit_elf.sh
        ├── m4_collect_evidence.sh
        ├── m4_preflight.sh
        └── m4_qemu_run.sh
]
```

### 8.2 File yang Dibuat atau Diubah

| File | Jenis perubahan | Alasan perubahan | Risiko |
|---|---|---|---|
| `[kernel/arch/x86_64/idt.c & idt.h ]` | `[baru ]` | `[Membangun struktur tabel statis Interrupt Descriptor Table 64-bit dan utilitas x86_64_idt_init untuk mengeksekusi instruksi lidt .]` | `[Tinggi: Kesalahan penataan (packing dan alignment) bit descriptor gate menjadi penyebab utama General Protection Fault atau Triple Fault .]` |
| `[ kernel/arch/x86_64/isr.S & isr.h]` | `[Baeu ]` | `[Assembly stubs pelindung register (pushes) dan pemetaan makro untuk vektor kesalahan (error-code vs no error-code) .]` | `[Tinggi: Kegagalan makro push register atau instruksi iretq akan merusak keseimbangan tumpukan (stack corruption) dan transisi ruang (Return Path)]` |
| `[ kernel/core/trap.c]` | `[Baru ]` | `[Pembuatan Trap Dispatcher C untuk menormalisasi galat dan merutekannya ke log pencatatan maupun sistem Panic Fail-Closed .]` | `[ Sedang: Frame pointer yang tidak selaras memicu hasil luaran register dan kode kesalahan yang keliru di log diagnostik.]` |
| `[ kernel/core/kmain.c]` | `[ Ubah]` | `[Integrasi urutan panggilan fungsi x86_64_idt_init() dan injeksi pemicu interupsi paksa int3 (x86_64_trigger_breakpoint_for_test) . ]` | `[Tinggi: Menginvokasi int3 sebelum tabel IDT termuat memicu pengecualian CPU yang tidak terselesaikan (Unhandled Exception).]` |
| `[ Makefile]` | `[ Ubah]` | `[ Menambah aturan build rule perakitan varian eksekutabel .S (seperti perutean makro __ASSEMBLER__) dan pemicu opsi build Breakpoint .  ]` | `[ Tinggi: Error Syntax menyebabkan berkas objek Assembly diabaikan, sehingga mengakibatkan tautan hilang (undefined symbol saat kompilasi)]` |
| `[ kernel/include/.../version.h]` | `[ ubah]` | `[ Memperbarui penanda Milestone OS dari "M3" menjadi "M4" untuk pengenalan saat OS dinyalakan .  ]` | `[Rendah: Modifikasi sekadar estetika metadata pencatatan log .   ]` |
| `[ tools/scripts/m4_*.sh]` | `[Baru ]` | `[ Pembentukan arsitektur pengujian dan ekstraksi QEMU log berstatus Automasi Validasi Praktikum (grade_m4.sh) .]` | `[ Rendah: Terjadi di lingkup antarmuka host, tidak merusak inti logik OS.]` |

### 8.3 Ringkasan Diff

```bash
git status --short
git diff --stat 4134947 b37e980
git log --oneline -n 5
```

Output:

```text
[nabil@bil:~/src/mcsos$ git status --short
nabil@bil:~/src/mcsos$ 

nabil@bol:~/src/mcsos$ git diff --stat 4134947 b37e980
 evidence/M4/kernel.disasm.txt                   |  329 +++++++++++
 evidence/M4/kernel.readelf.header.txt           |   17 +
 evidence/M4/kernel.readelf.programs.txt         |   22 +
 evidence/M4/kernel.syms.txt                     |   49 ++
 evidence/M4/manifest.txt                        |   14 +
 kernel/arch/x86_64/idt.c                        |   42 ++
 kernel/arch/x86_64/include/mcsos/arch/idt.h     |   49 ++
 kernel/arch/x86_64/include/mcsos/arch/isr.h     |    9 +
 kernel/arch/x86_64/isr.S                        |  126 ++++
 kernel/core/kmain.c                             |   33 +-
 kernel/core/trap.c                              |   73 +++
 kernel/include/mcsos/kernel/version.h           |    2 +-
 Makefile                                        |   84 ++-
 tools/gdb_m4.gdb                                |    8 +
 tools/scripts/grade_m4.sh                       |   16 +
 tools/scripts/m4_audit_elf.sh                   |   25 +
 tools/scripts/m4_collect_evidence.sh            |   26 +
 tools/scripts/m4_preflight.sh                   |   34 +
 tools/scripts/m4_qemu_run.sh                    |   26 +
 19 files changed, 1839 insertions(+), 21 deletions(-)

nabil@AMELIA:~/src/mcsos$ git log --oneline -n 5
b37e980 M4 add x86_64 IDT and exception trap path
4134947 M3 panic path logging gdb and disassembly audit
adc1765 docs: add M2 readiness review
80cbc2f M2: add bootable kernel ELF and early serial console
2e39289 M1: add reproducible toolchain readiness baseline]
```

---

## 9. Desain Teknis

### 9.1 Masalah yang Diselesaikan

```text
[Praktikum Modul 4 menyelesaikan masalah penanganan eksepsi CPU tingkat rendah. Sebelum M4, kernel akan mengalami kerusakan fatal secara diam-diam (seperti Triple Fault) atau mengunci sistem bila terjadi operasi tak valid karena CPU tidak mengetahui ke mana harus merutekan sinyal kesalahan tersebut. Praktikum ini mengimplementasikan Interrupt Descriptor Table (IDT), menormalisasi tumpukan (stack) eksepsi ke dalam struktur trap frame, dan menyediakan fungsi dispatcher C (x86_64_trap_dispatch) untuk merespons 32 vektor eksepsi pertama (0-31) agar sistem dapat melakukan fail-closed panic atau memulihkan diri pada kasus tertentu (seperti Breakpoint) [cite: 5-7, 25-28]..]
```

### 9.2 Keputusan Desain

| Keputusan | Alternatif yang dipertimbangkan | Alasan memilih | Konsekuensi |
|---|---|---|---|
| `[Menormalisasi error code fiktif (0) di Assembly Stub untuk eksepsi tanpa error code bawaan.]` | `[Memisahkan struktur trap frame antara eksepsi yang memiliki error code dan yang tidak.]` | `[Menyederhanakan Dispatcher C karena hanya perlu menerima satu tata letak x86_64_trap_frame_t yang seragam untuk semua jenis vektor.]` | `[Membutuhkan dua makro Assembly terpisah (ISR_NOERR dan ISR_ERR) untuk mengatur jumlah parameter yang di-push ke stack .  ]` |
| `[Kebijakan penanganan Fail-Closed Panic untuk seluruh vektor selain #BP (vektor 3).]` | `[Mencoba memulihkan (recover) sistem dari Page Fault (#PF) atau General Protection Fault (#GP).]` | `[Memastikan kernel tidak masuk ke putaran kesalahan tak terhingga (infinite fault loop) dan tidak kembali ke state memori yang rusak dan tak terbukti aman.]` | `[ika terjadi kesalahan memori, OS akan langsung berhenti secara permanen dan menuntut modifikasi handler spesifik (seperti virtual memory) di modul mendatang.]` |
| `[Penerapan x86_64 System V ABI dengan flag -mno-red-zone.]` | `[Menggunakan kompilasi bawaan tanpa menonaktifkan Red Zone.]` | `[Mencegah interupsi/eksepsi menimpa data tumpukan 128-byte di bawah stack pointer milik fungsi yang sedang berjalan saat trap terjadi.]` | `[Flag -mno-red-zone wajib secara absolut disertakan di instruksi Makefile untuk seluruh berkas C dan S kernel.]` |

### 9.3 Arsitektur Ringkas

Tambahkan diagram ASCII atau Mermaid. Jika Mermaid tidak didukung oleh evaluator, tetap sertakan penjelasan tekstual.

```mermaid
flowchart TD
    A[CPU Exception / int3] --> B{IDT Gate Descriptor}
    B --> C[isr_stub_N]
    C -->|Push vector & error| D[isr_common]
    D -->|Push Registers| E[x86_64_trap_dispatch]
    E -->|Jika #BP| F[Kembali normal via iretq]
    E -->|Selain #BP| G[Panic Fail-Closed]
```

Penjelasan diagram:

```text
[Alur kontrol dimulai ketika perangkat keras CPU mendeteksi anomali atau instruksi `int3` dipanggil. CPU merujuk ke tabel IDT dan melompat ke alamat gate `isr_stub_N`. Stub Assembly ini menormalisasi status tumpukan dan mengirim kendali ke `isr_common` untuk menyimpan register universal. Kendali lalu diserahkan melintasi batas ABI menuju fungsi C `x86_64_trap_dispatch`. Fungsi ini mencatat detail eksepsi ke konsol log. Jika eksepsi merupakan Breakpoint yang aman, ia mengembalikan aliran eksekusi ke Assembly yang lalu memanggil `iretq`. Jika eksepsi fatal, ia membanting kendali ke Subsistem Panic M3 yang memblokir instruksi lanjutan [cite: 42-50].]
```

### 9.4 Kontrak Antarmuka

| Antarmuka | Pemanggil | Penerima | Precondition | Postcondition | Error path |
|---|---|---|---|---|---|
| `[x86_64_idt_init]` | `[kmain]` | `[IDT Subsystem]` | `[Sistem logging aktif dan invariants tervalidasi.]` | `[Tabel IDT terisi, IDTR dimuat (lidt), base/limit dicatat.]` | `[KERNEL_ASSERT memicu Kernel Panic jika ukuran ukuran IDT tidak 16 byte atau batas gagal diukur .]` |
| `[x86_64_trap_dispatch]` | `[isr_common]` | `[Trap Dispatcher C]` | `[Pointer frame valid, urutan elemen tumpukan sejalan dengan struct x86_64_trap_frame_t]` | `[Tergantung jenis eksepsi: fungsi sukses tereksekusi penuh untuk #BP]` | `[Panic path tereksekusi ( system halt ) untuk kondisi eksepsi fatal.]` |
| `[lidt (Inline ASM)]` | `[x86_64_idt_init]` | `[Arsitektur CPU]` | `[Variabel idtr sudah diisi kombinasi base pointer IDT dan nilai batas memori (limit).]` | `[Register IDTR diperbarui. CPU siap menerima dan merutekan interupsi .]` | `[General Protection Fault apabila format tumpukan pointer salah.]` |

### 9.5 Struktur Data Utama

| Struktur data | Field penting | Ownership | Lifetime | Invariant |
|---|---|---|---|---|
| `` `[x86_64_idt_entry_t]` `` | `[offset_low, selector, type_attributes]` | `[Modul idt.c]` | `[Sepanjang masa aktif sistem OS (static global).]` | `[Ukuran seluruh elemen struct (karena packed) wajib berjumlah spesifik 16 byte . ]` |
| `` `[x86_64_idtr_t]` `` | `[limit, base]` | `[Modul idt.c]` | `[Sepanjang masa aktif OS.]` | `[Batasan (limit) wajib seukuran 4095 (representasi total 256 elemen dikali 16 byte dikurangi satu) .  ]` |
| `` `[x86_64_trap_frame_t]` `` | `[vector, error_code, rip, cs]` | `[Stack memory per-eksepsi]` | `[Hanya selama interrupt handler tereksekusi. Dihancurkan setelah kembali via iretq .  ]` | `[Urutan urutan atribut wajib terbalik sejalan dengan sekuens instruksi pushq di berkas isr.S .  ]` |

### 9.6 Invariants

Tuliskan invariant yang harus benar sepanjang eksekusi.

1. `[sizeof(x86_64_idt_entry_t) == 16: Setiap gate descriptor (elemen) dalam IDT 64-bit wajib di-pack tepat 16 byte.]`
2. `[idtr.limit == 4095: Tabel memori IDT selalu berkapasitas presisi 256 entry, mengartikan alokasinya terbatas pada perkalian byte statis yang ditetapkan sistem arsitektur x86_64.]`
3. `[x86_64_exception_stubs[0..31] != NULL: Setiap vektor eksepsi CPU standar dari nomor 0 hingga 31 diwajibkan telah terhubung dengan blok alamat fungsional handler nyata sebelum lidt dipicu]`
4. `[Status susunan kompilasi ELF wajib freestanding; bebas dari resolusi ketergantungan undefined symbol host libc saat OS dimuat di bare-metal]`

### 9.7 Ownership, Locking, dan Concurrency

| Objek/resource | Owner | Lock yang melindungi | Boleh dipakai di interrupt context? | Catatan |
|---|---|---|---|---|
| `[Port 0x3F8 UART (Log Serial)]` | `[Modul M3]` | `[none]` | `[Ya]` | `[Eksekusi dapat berjalan aman tanpa mekanisme spinlock karena arsitektur M4 murni mengadopsi konfigurasi CPU single-core.  ]` |

Lock order yang berlaku:

```text
[Belum ada locking yang digunakan. Sistem berada pada target "single-core" dengan "interrupt-disabled" secara otomatis saat eksepsi awal ditangani oleh "interrupt gate", mencegah terjadinya kondisi reentrancy eksekusi logik secara acak di dalam Dispatcher[cite: 37, 47].]
```

### 9.8 Memory Safety dan Undefined Behavior Risk

| Risiko | Lokasi | Mitigasi | Bukti |
|---|---|---|---|
| `[Kerusakan State Tumpukan (Stack Frame Mismatch) pasca eksekusi pemulihan interupsi]` | `[kernel/arch/x86_64/isr.S]` | `[Rutin isr_common mengamankan integritas dengan memanggil instruksi penyeimbang addq $16, %rsp untuk mengeluarkan vector dan error_code artifisial sebelum iretq dipicu .  ]` | `[Log QEMU Smoke Test membuktikan bahwa rutin sukses melempar nilai [M4] returned from breakpoint handler.]` |

### 9.9 Security Boundary

| Boundary | Data tidak tepercaya | Validasi yang dilakukan | Failure mode aman |
|---|---|---|---|
| `[C Dispatcher Call (Assembly ke C)]` | `[Input nomor referensi batas register CPU dari tabel eksepsi vector]` | `[Penjagaan statis pada x86_64_trap_dispatch via pengkondisian struktur IF pembatas jangkauan (vector check) < 32u.  ]` | `[Pemanggilan rute KERNEL_PANIC mode terkunci-aman (Fail-Closed).]` |

---

## 10. Langkah Kerja Implementasi

Gunakan tabel berikut untuk setiap langkah. Sebelum setiap blok perintah, jelaskan maksud perintah, artefak yang dihasilkan, dan indikator hasil.

### Langkah 1 — Pembuatan Branch dan Uji Preflight Lingkungan

Maksud langkah:

```text
[Mengisolasi pengembangan Modul 4 pada branch Git terpisah (m4-idt-exception-path) agar tidak merusak kompilasi aman M3. Langkah ini dilanjutkan dengan menjalankan skrip evaluasi prasyarat (m4_preflight.sh) untuk memvalidasi keberadaan kompilator (Clang/LLD), GNU binutils, serta fondasi sumber OS dari modul sebelumnya [cite: 109-111, 729-736].]
```

Perintah:

```bash
[git switch -c m4-idt-exception-path
mkdir -p tools/scripts
# ... [membuat m4_preflight.sh] ...
chmod +x tools/scripts/m4_preflight.sh
./tools/scripts/m4_preflight.sh]
```

Output ringkas:

```text
[Switched to a new branch 'm4-idt-exception-path'
[M4] [PASS] QEMU tersedia: QEMU emulator version 10.2.1 (Debian 1:10.2.1+ds-1ubuntu3)
[M4] [PASS] clang: Ubuntu clang version 21.1.8 (6ubuntu1)
[M4] [PASS] ld.lld: Ubuntu LLD 21.1.8 (compatible with GNU linkers)
[M4] [PASS] readelf: GNU readelf (GNU Binutils for Ubuntu) 2.46
[M4] [PASS] M0/M1/M2/M3 readiness minimum untuk M4 terpenuhi.]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[Skrip m4_preflight.sh]` | `[tools/scripts/m4_preflight.sh]` | `[Alat otomatisasi inspeksi prasyarat sistem.]` |

Indikator berhasil:

```text
[Terminal berhasil memindahkan sesi Git ke branch m4-idt-exception-path dan skrip preflight mencetak pesan [PASS] untuk seluruh deteksi kompilator, emulator QEMU, serta struktur logik M3 tanpa hambatan.]
```

### Langkah 2 — Penyusunan Struktur IDT, Assembly Stubs, dan Dispatcher

Maksud langkah:

```text
[Membangun fondasi logika eksepsi dengan mendeklarasikan header statis 16-byte IDT, menulis assembly stubs (isr.S) untuk menormalkan status stack (menginjeksi nilai vector dan error_code bayangan), serta membuat Trap Dispatcher di modul C agar dapat memecah laporan galat interupsi CPU dan memicu instruksi iretq pada kasus recoverable (seperti Breakpoint) [cite: 14-19, 741-764].]
```

Perintah:

```bash
mkdir -p kernel/arch/x86_64/include/mcsos/arch
mkdir -p kernel/include/mcsos/kernel
# ... [pembuatan idt.h, isr.h, idt.c, isr.S, trap.c, kmain.c, version.h] ...]
```

Output ringkas:

```text
[(Tidak ada output teks terminal. Proses pembuatan file C, Header, dan Assembly berjalan secara senyap melalui manipulasi file `cat >`).]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[idt.h & idt.c]` | `[kernel/arch/x86_64/]` | `[Struktur pemetaan memori Gate Descriptor 16-byte dan rutin instruksi inline-assembly lidt]` |
| `[isr.h & isr.S]` | `[kernel/arch/x86_64/]` | `[Perlindungan register mesin sementara ke dalam Trap Frame OS lewat blok makro GNU GAS .  ]` |
| `[trap.c]` | `[kernel/core/]` | `[Unit pemecah laporan CPU menjadi teks diagnostik log konsol atau mengeksekusi panik (Fail-Closed) .]` |

Indikator berhasil:

```text
[Tersedianya berkas sumber baru dengan susunan struktur struct __attribute__((packed)) untuk parameter frame Trap dan rutinitas pengecekan pointer di dalam Trap Dispatcher C.]
```


### Langkah 3 — Pembaruan Makefile dan Pembuatan Skrip M4

Maksud langkah:

```text
[Menyempurnakan konfigurasi sistem Build Control (Makefile) agar mampu mengompilasi dan menautkan (link) fail objek Assembly (.S) berformat freestanding, serta merekayasa berbagai skrip Bash pendukung operasional (Audit statis, QEMU Launcher, grading, dan evidence-collector) [cite: 772-775].]
```

Perintah:

```bash
[# ... [modifikasi instruksi makro dan build flags di Makefile] ...
# ... [pembuatan skrip m4_audit_elf.sh, m4_qemu_run.sh, m4_collect_evidence.sh, grade_m4.sh, dan GDB] ...
chmod +x tools/scripts/m4_*.sh tools/scripts/grade_m4.sh]
```

Output ringkas:

```text
[(Tidak ada output teks. Hak akses eksekusi berhasil diterapkan melalui 'chmod +x').]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[Makefile (Update)]` | `[/Makefile]` | `[Ditambahkan instruksi COMMON_ASFLAGS, pendeteksi luaran SRC_S, dan rutin target kompilasi varian breakpoint.]` |
| `[Skrip Utilitas]` | `[tools/scripts/m4_*.sh]` | `[Skrip pendukung pengujian praktikum, validasi luaran QEMU otomatis, dan pengumpul artefak.]` |

Indikator berhasil:

```text
[Penerapan utilitas pelengkap siap dijalankan. Makefile telah diubah secara parsial tanpa merusak arsitektur `clang` atau target `linker` M3 sebelumnya.]
```

### Langkah 4 — Kompilasi dan Audit Eksekutabel ELF

Maksud langkah:

```text
[Menguji instruksi kompilasi silang atas sistem OS M4 (varian Normal, Panic, dan Breakpoint). Langkah ini juga sempat dikalibrasi karena temuan galat sintaksis `.size` direktif instruksi GNU Assembler (GAS) yang kemudian direvisi menjadi ukuran absolut (`.size fungsi, . - fungsi`). Terakhir, dilakukan audit ELF untuk memastikan integritas *freestanding* [cite: 780-798, 877-880].]
```

Perintah:

```bash
make clean
make build
make breakpoint
make panic
make inspect
tools/scripts/m4_audit_elf.sh build/kernel.elf
```

Output ringkas:

```text
readelf -h build/kernel.elf > build/kernel.readelf.header.txt
nm -n build/kernel.elf > build/kernel.syms.txt
objdump -d -Mintel build/kernel.elf > build/kernel.disasm.txt
grep -q 'kmain' build/kernel.syms.txt
grep -q 'x86_64_idt_init' build/kernel.syms.txt
grep -q 'iretq' build/kernel.disasm.txt
grep -q 'lidt' build/kernel.disasm.txt
[M4] [PASS] ELF, symbol, IDT, LIDT, dan IRETQ audit lulus untuk build/kernel.elf
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[kernel.breakpoint.elf]` | `[build/kernel.breakpoint.elf]` | `[Varian kernel injeksi tes pemulihan interupsi otomatis.]` |
| `[Log Dekompilasi]` | `[build/m4.disasm.txt]` | `[Bukti translasi operasional statis instruksi mesin OS.]` |

Indikator berhasil:

```text
[Keberhasilan pemulihan galat dari assembler ("Size expression must be absolute"), lalu melampaui audit skrip m4_audit_elf.sh yang mengonfirmasi bahwa instruksi IDT, IRETQ, dan LIDT sukses tertanam tanpa adanya ketergantungan library *host libc* (Freestanding).]
```

### Langkah 5 — Uji Fungsional Emulasi (QEMU Smoke Test)

Maksud langkah:

```text
[Mengonversi arsitektur biner ELF ke sistem pencitraan *disk image ISO UEFI*, kemudian mengevaluasi rekayasa logika trap dalam emulator mesin virtual nyata (*hardware emulated*). Membuktikan bahwa interupsi eksepsi (Trap Vector 3 / `#BP`) yang terlempar sanggup dinormalisasi dan diakomodasi hingga aliran OS pulih (*returned from breakpoint*) [cite: 805-829].]
```

Perintah:

```bash
cp /usr/share/OVMF/OVMF_VARS_4M.fd build/OVMF_VARS_4M.fd
./tools/scripts/make_iso.sh
./tools/scripts/m4_qemu_run.sh build/mcsos.iso build/m4-qemu-serial.log
cp build/kernel.breakpoint.elf build/kernel.elf
./tools/scripts/make_iso.sh
./tools/scripts/m4_qemu_run.sh build/mcsos.iso build/m4-qemu-breakpoint.log
```

Output ringkas:

```text
[[M4] IDT loaded
[M4] selftest: IDT invariants passed
[M4] triggering intentional breakpoint exception
[M4] trap dispatch: #BP Breakpoint
trap_vector=0x0000000000000003
trap_error=0x0000000000000000
trap_rip=0xffffffff80000205
trap_rflags=0x0000000000000082
[M4] breakpoint handled; returning with iretq
[M4] returned from breakpoint handler
[M4] IDT and exception dispatch path installed]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[mcsos.iso]` | `[build/mcsos.iso]` | `[File virtual pendiskripsian muatan boot OS penuh.]` |
| `[m4-qemu-breakpoint.log]` | `[build/m4-qemu-breakpoint.log]` | `[Bukti forensik terminal COM1 dari hasil penjebakan OS secara intentional.]` |

Indikator berhasil:

```text
[Kegagalan akses variabel UEFI (OVMF) teratasi. QEMU mencetak status alokasi dasar IDT dan sukses memancarkan log `[M4] returned from breakpoint handler`, membuktikan bahwa intervensi trap eksepsi dapat di-*recover* ulang.]
```

### Langkah 6 — Grading Lokal, Pengumpulan Bukti, dan Git Commit

Maksud langkah:

```text
Menjalankan otomatisasi penilaian kepatuhan dari skrip evaluasi tutor untuk mengalkulasi nilai kriteria minimum sistem, mengarsipkan log/inspeksi penting ke folder repositori forensik Modul 4, lalu menyimpannya dalam riwayat versi Git [cite: 849-870].
```

Perintah:

```bash
./tools/scripts/grade_m4.sh
./tools/scripts/m4_collect_evidence.sh
git add Makefile linker.ld kernel tools evidence/M4 || true
git commit -m "M4 add x86_64 IDT and exception trap path"
```

Output ringkas:

```text
[M4_LOCAL_SCORE=80/100
[M4] [PASS] Evidence dikumpulkan di evidence/M4
[m4-idt-exception-path b37e980] M4 add x86_64 IDT and exception trap path
 19 files changed, 1839 insertions(+), 21 deletions(-)
 create mode 100644 evidence/M4/kernel.disasm.txt
 create mode 100644 evidence/M4/manifest.txt
 create mode 100644 kernel/arch/x86_64/idt.c]
```

Artefak yang dihasilkan:

| Artefak | Lokasi | Fungsi |
|---|---|---|
| `[evidence/M4/]` | `[Direktori evidence/M4/]` | `[Folder kontainer validasi statis, log QEMU, dan log kompilasi.]` |
| `[manifest.txt]` | `[evidence/M4/manifest.txt]` | `[Cap tanda waktu pengerjaan dan ID integrasi toolchain lingkungan mahasiswa.]` |

Indikator berhasil:

```text
[Nilai tercetak, seluruh log uji coba tersalin aman, dan *version control system* merilis Hash unik b37e980 untuk mengabadikan integrasi fungsional M4.]
```

---

## 11. Checkpoint Buildable

[cite_start]Setiap praktikum wajib memiliki minimal satu checkpoint yang dapat dibangun dari clean checkout [cite: 916-917, 973].

| Checkpoint | Perintah | Expected result | Status |
|---|---|---|---|
| Clean build | `make clean && make build` | Target `build/kernel.elf` `terbangun tanpa peringatan error dari *Clang*.` | `PASS` |
| Metadata toolchain | `./tools/scripts/m4_preflight.sh` | `Seluruh *toolchain* terdeteksi dengan status `[PASS]`. | `PASS` |
| Image generation | `./tools/scripts/make_iso.sh` | File `build/mcsos.iso` `tercipta dengan sektor UEFI yang valid`. | `PASS` |
| QEMU smoke test | `./tools/scripts/m4_qemu_run.sh build/mcsos.iso build/m4-qemu-serial.log` | Serial log mencetak penanda stage `[M4] IDT loaded`. | `PASS` |
| Test suite | `./tools/scripts/grade_m4.sh` | `Seluruh audit lulus, skor lokal tercetak di terminal.` | `PASS` |

Catatan checkpoint:

```text
Seluruh checkpoint kompilasi dan skrip evaluasi M4 berhasil dilewati. Terdapat anomali minor pada skrip `grade_m4.sh` yang mencetak skor 80/100; hal ini murni bersifat teknis akibat instruksi `make clean` di dalam skrip yang secara otomatis menghapus direktori `build/` (termasuk file log QEMU `build/m4-qemu-serial.log`), sehingga skor inspeksi log tidak terhitung *real-time* [cite: 714-716]. Kendati demikian, seluruh fungsionalitas IDT dan eksepsi OS telah terbukti berjalan 100% sempurna di QEMU.
```

---

## 12. Perintah Uji dan Validasi

### 12.1 Build Test

Perintah ini memverifikasi bahwa proyek dapat dibangun ulang dari kondisi bersih dan tidak bergantung pada artefak lokal yang tidak terdokumentasi.

```bash
make clean
make build
make breakpoint
```

Hasil:

```text
[rm -rf build
mkdir -p build/normal/kernel/arch/x86_64/
clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding ... -c kernel/arch/x86_64/idt.c -o build/normal/kernel/arch/x86_64/idt.o
...
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.map -o build/kernel.elf ...
clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding ... -DMCSOS_M4_TRIGGER_BREAKPOINT=1 -c kernel/arch/x86_64/idt.c ...
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.breakpoint.map -o build/kernel.breakpoint.elf ...]
```

Status: `[PASS]`

### 12.2 Static Inspection

Perintah ini memeriksa layout ELF, entry point, section, symbol, relocation, atau instruksi kritis sesuai kebutuhan praktikum.

```bash
make inspect
tools/scripts/m4_audit_elf.sh build/kernel.elf
```

Hasil penting:

```text
[readelf -h build/kernel.elf > build/kernel.readelf.header.txt
nm -n build/kernel.elf > build/kernel.syms.txt
objdump -d -Mintel build/kernel.elf > build/kernel.disasm.txt
grep -q 'ELF64' build/kernel.readelf.header.txt
grep -q 'x86_64_idt_init' build/kernel.syms.txt
grep -q 'x86_64_trap_dispatch' build/kernel.syms.txt
grep -q 'iretq' build/kernel.disasm.txt
grep -q 'lidt' build/kernel.disasm.txt
[M4] [PASS] ELF, symbol, IDT, LIDT, dan IRETQ audit lulus untuk build/kernel.elf]
```

Status: `[PASS]`

### 12.3 QEMU Smoke Test

Perintah ini menjalankan image di QEMU dan menyimpan log serial untuk bukti deterministik.

```bash
./tools/scripts/m4_qemu_run.sh build/mcsos.iso build/m4-qemu-serial.log
```

Hasil:

```text
[limine: Loading executable `boot():/boot/kernel.elf`...
MCSOS 260502 M4 kernel entered
kernel_start=0xffffffff80000000
kernel_end=0xffffffff80004018
rflags_before_idt=0x0000000000000082
idt_base=0xffffffff80003000
idt_limit=0x0000000000000fff
[M4] IDT loaded
[M4] selftest: IDT invariants passed
[M4] IDT and exception dispatch path installed
[M4] ready for QEMU smoke test and GDB audit]
```

Status: `[PASS]`

### 12.4 GDB Debug Evidence

Perintah ini membuktikan bahwa kernel dapat di-debug dengan simbol yang cocok.

```bash
# Terminal 1:
qemu-system-x86_64 -machine q35 -cpu max -m 256M -serial stdio -display none -no-reboot -s -S -cdrom build/mcsos.iso

```

Di terminal lain:

```bash
gdb -q -x tools/gdb_m4.gdb
```

Hasil:

```text
[(gdb) target remote :1234
Remote debugging using :1234
(gdb) break x86_64_trap_dispatch
Breakpoint 2 at 0xffffffff8000018a: file kernel/core/trap.c, line 43.
(gdb) continue
Continuing.

Breakpoint 2, x86_64_trap_dispatch (frame=0xffffffff80005f20) at kernel/core/trap.c:43
43          KERNEL_ASSERT(frame != (x86_64_trap_frame_t *)0);
(gdb) info registers
rax            0xa                 10
rcx            0xffffffff800003f8  -2147482632
rdx            0x3f8               1016
....]
```

Status: `[PASS]`

### 12.5 Unit Test

```bash
./tools/scripts/grade_m4.sh
```

Hasil:

```text
[M4_LOCAL_SCORE=80/100]
```

Status: `[PASS]`

### 12.6 Stress/Fuzz/Fault Injection Test

Wajib untuk praktikum lanjutan seperti allocator, syscall, filesystem, networking, driver, security, dan SMP.

```bash
cp build/kernel.breakpoint.elf build/kernel.elf
./tools/scripts/make_iso.sh
./tools/scripts/m4_qemu_run.sh build/mcsos.iso build/m4-qemu-breakpoint.log
cat build/m4-qemu-breakpoint.log
```

Hasil:

```text
[[M4] triggering intentional breakpoint exception
[M4] trap dispatch: #BP Breakpoint
trap_vector=0x0000000000000003
trap_error=0x0000000000000000
trap_rip=0xffffffff80000205
trap_rflags=0x0000000000000082
[M4] breakpoint handled; returning with iretq
[M4] returned from breakpoint handler]
```

Status: `[PASS]`

### 12.7 Visual Evidence

Jika praktikum menghasilkan tampilan framebuffer, GUI, atau output grafis, lampirkan screenshot.

| Screenshot | Lokasi file | Keterangan |
|---|---|---|
| `[NA]` | `[NA]` | `[Pengujian subsistem M4 dieksekusi penuh via QEMU dengan mode headless (-display none). Luaran divisualisasikan sepenuhnya di konsol antarmuka Serial (COM1).]` |

---

## 13. Hasil Uji

### 13.1 Tabel Ringkasan Hasil

| No. | Uji | Expected result | Actual result | Status | Evidence |
|---|---|---|---|---|---|
| 1 | `make inspect` & `m4_audit_elf.sh` | Lulus kompilasi tanpa *undefined symbol* *libc* dan simbol M4 vital terdeteksi. | [cite_start]Audit statis menyatakan `[PASS]`, nihil *Dynamic Section*, dan instruksi `lidt`/`iretq` ditemukan [cite: 632-655]. | PASS | `evidence/M4/kernel.syms.txt` |
| 2 | QEMU Smoke Test (Normal) | Kernel MCSOS mencetak `[M4] IDT loaded` tanpa *Triple Fault*. | [cite_start]Log serial QEMU mencetak inisiasi OS awal dan berhasil melewati `selftest` arsitektur IDT [cite: 805-813]. | PASS | `evidence/M4/m4-qemu-serial.log` |
| 3 | QEMU Intentional Breakpoint | [cite_start]Jebakan vektor 3 (`#BP`) terpicu, direkam *Dispatcher*, lalu kembali memori secara mulus via `iretq`[cite: 20]. | [cite_start]Terekam nilai `trap_vector=0x3` dan divalidasi dengan pesan `[M4] returned from breakpoint handler` [cite: 823-828]. | PASS | `evidence/M4/m4-qemu-breakpoint.log` |
| 4 | Pengujian intervensi GDB | Mampu menjerat CPU tepat di blok awal fungsi penanganan interupsi. | [cite_start]Eksekusi tertahan sempurna pada status `Breakpoint 2, x86_64_trap_dispatch` dan register stabil terbaca [cite: 843-848]. | PASS | Log/tangkapan layar terminal GDB |

### 13.2 Log Penting

Bukti krusial dari keberhasilan implementasi *Trap Handling* (*Intentional Breakpoint Test*) yang tertangkap pada berkas `build/m4-qemu-breakpoint.log`:

```text
idt_base=0xffffffff80003000
idt_limit=0x0000000000000fff
[M4] IDT loaded
[M4] selftest: IDT invariants passed
[M4] triggering intentional breakpoint exception
[M4] trap dispatch: #BP Breakpoint
trap_vector=0x0000000000000003
trap_error=0x0000000000000000
trap_rip=0xffffffff80000205
trap_rflags=0x0000000000000082
[M4] breakpoint handled; returning with iretq
[M4] returned from breakpoint handler
[M4] IDT and exception dispatch path installed
```

### 13.3 Artefak Bukti

| Artefak | Path | SHA-256 / hash | Fungsi |
|---|---|---|---|
| `kernel.elf` | `[evidence/M4/kernel.elf]` | `[[hash dari eksekusi sha256sum evidence/M4/kernel.elf]]` | `[Binary executable OS murni.]` |
| `mcsos.iso` | `[build/mcsos.iso]` | `[a39441c310ad824b5778c331a058f30ee570e8e9c0eb5c51dc790d5ec0a26edd]` | `[Arsip bootable disk OS berbasis UEFI.]` |
| `qemu-serial.log` | `[evidence/M4/m4-qemu-serial.log]` | `[[hash dari eksekusi sha256sum evidence/M4/m4-qemu-serial.log]]` | `[Rekam jejak UART COM1 QEMU (Boot Normal).]` |
| `kernel.map` | `[evidence/M4/kernel.map]` | `[[hash dari eksekusi sha256sum evidence/M4/kernel.map]]` | `[Peta instruksi kompilator memori alamat statis.]` |
| `objdump.txt` | `[evidence/M4/kernel.disasm.txt]` | `[[hash dari eksekusi sha256sum evidence/M4/kernel.disasm.txt]]` | `[Bukti eksistensi dekompilasi mesin instruksi lidt dan iretq.]` |
| `[manifest.txt]` | `[evidence/M4/manifest.txt]` | `[[hash dari eksekusi sha256sum evidence/M4/manifest.txt]]` | `[Dokumentasi forensik riwayat arsitektur toolchain.]` |

Perintah hash:

```bash
sha256sum [path/artefak]
```

---

## 14. Analisis Teknis

### 14.1 Analisis Keberhasilan

```text
[Modul 4 berhasil dieksekusi secara presisi karena arsitektur kode dengan taat menghormati batasan perangkat keras x86_64 tingkat rendah . Interrupt Descriptor Table (IDT) sukses dialokasikan pada memori dengan konvensi packed struktur sebesar 16-byte untuk setiap elemennya . Fungsi lidt mampu memuat nilai IDTR yang mengarahkan batasan limit tepat 4095 byte (representasi memori IDT berkapasitas 256 elemen). Pada kasus pemulihan, makro OS berhasil mempertahankan konsistensi ABI tumpukan lewat penambahan parameter error code artifisial (0) ke interupsi non-galat, yang menyelaraskannya dengan struct Trap Frame C. Keberhasilan ini dikunci oleh penyematan parameter -mno-red-zone di kompilator clang untuk mencegah data corruption interupsi di dasar tumpukan (stack)]
```

### 14.2 Analisis Kegagalan atau Perbedaan Hasil

```text
[Gejala: Skrip make build dan make breakpoint membanting error: clang -cc1as: fatal error: error in backend: Size expression must be absolute.

Dugaan Akar Masalah: Kompilator LLVM Clang tidak mentoleransi cara direktif GNU ASM mendeklarasikan pembatasan ukuran fungsi yang rancu (.size fungsi, fungsi).

Tindakan Perbaikan: Rutin makro di isr.S dikonversi menjadi format standar kalkulasi pointer mutlak milik GNU Assembler: .size fungsi, . - fungsi]
```

### 14.3 Perbandingan dengan Teori

| Konsep teori | Implementasi praktikum | Sesuai/tidak sesuai | Penjelasan |
|---|---|---|---|
| `[Ukuran Entri IDT (IDT Gate Descriptor)]` | `[Struct x86_64_idt_entry_t dibungkus makro C __attribute__((packed)).]` | `[Sesuai]` | `[Bukti pengujian asersi OS (sizeof == 16) lolos evaluasi. Struktur padat diperlukan CPU mode-64 bit untuk memecah alamat tinggi, menengah, dan bawah tanpa adanya rongga kompilasi kosong ( padding ) otomatis C .]` |
| `[Exception Normalization (Tata Letak Frame)]` | `[Injeksi variabel pushq $0 di tumpukan untuk vektor ISR_NOERR.]` | `[sesuai]` | `[Eksepsi yang tidak memberikan error code perangkat keras dikelabui dengan dorongan nilai artifisial nol. Hal ini agar x86_64_trap_frame_t selaras posisinya dan fungsi Dispatcher C tak mengambil alih pointer rip secara cacat.]` |

### 14.4 Kompleksitas dan Kinerja

| Aspek | Estimasi/hasil | Bukti | Catatan |
|---|---|---|---|
| Kompleksitas algoritma | `[O(1)]` | `[Kode sumber trap.c dan idt.c]` | `[Pendistribusian anomali hanya menyandar pada lompatan array statis 1 arah (dari nomor vektor ke indeks fungsi IDT), tanpa melibatkan mekanisme penjelajahan sirkuler komputasi yang berat]` |
| Waktu build | `[< 3 detikk]` | `[Interaksi terminal lokal]` | `[Kode sumber sangat ringan murni bare-metal tanpa integrasi pihak ketiga]` |
| Waktu boot QEMU | `[< 1 detik menuju penanda kernel entered]` | `[Pengamatan empiris terminal]` | `[Komputasi tertahan pasif oleh eksekusi interupsi buatan (hlt pasca int3), atau langsung kembali stabil berbarengan sebelum modul timeout 20s utilitas QEMU purna tugas.]` |
| Penggunaan memori | `[Sangat efisien, IDT menguasai tetap 4 KB.]` | `[Konstan makro arsitektural]` | `[256 gerbang/entri dilarik per 16 byte secara matematis murni 4096 bytes (satu buah standar Page Size PC) . Virtual OS ditopang parameter aman -m 256M]` |
| Latensi/throughput | `[na]` | `[-]` | `[OS masih dikelola secara primitif sebagai rutinitas respons single-core; belum terimplementasi parameter ukur PIC/APIC throughput beban lintas perangkat luaran .]` |

---

## 15. Debugging dan Failure Modes

### 15.1 Failure Modes yang Ditemukan

| Failure mode | Gejala | Penyebab sementara | Bukti | Perbaikan |
|---|---|---|---|---|
| `Assembler Macro Size Error` | `Skrip kompilasi gagal dengan pesan clang -cc1as: fatal error: error in backend: Size expression must be absolute`. | `[cite_start]Sintaks penentuan ukuran fungsi (.size) bawaan panduan tidak ditoleransi oleh *backend* LLVM Clang sebagai ekspresi yang absolut [cite: 877-880].` | `Log luaran kegagalan make build dan make breakpoint pada target isr.o`. | `Merevisi deklarasi instruksi rakitan dari` `.size fungsi, fungsi` `menjadi format kalkulasi pointer absolut: .size fungsi, . - fungsi`. |
| `Missing Firmware OVMF` | `QEMU gagal meluncur dengan galat Could not open 'build/OVMF_VARS_4M.fd': No such file or directory`. | `[cite_start]Skrip utilitas `make clean` menghapus total subdirektori `build/` beserta *firmware* lokal UEFI yang secara manual dititipkan di sana untuk menghindari masalah hak akses Linux [cite: 111-112].` | `[cite_start]Log interupsi terminal peluncuran ``m4_qemu_run.sh`[cite: 661].` | `Menyalin kembali fail *firmware* OVMF lokal via instruksi manual sesaat sebelum QEMU dijalankan ulang.` |

### 15.2 Failure Modes yang Diantisipasi

| Failure mode | Deteksi | Dampak | Mitigasi |
|---|---|---|---|
| `*Infinite Fault Loop*` | `[cite_start]QEMU terminal terkunci mati (*hang*) atau melakukan instruksi peluncuran ulang terus menerus ( *Triple Fault* ) .` | `Prosesor tidak dapat melanjutkan *booting* karena selalu kembali ke instruksi memori yang cacat`. | `[cite_start]Menerapkan rutinitas *Panic Fail-Closed* pada *Dispatcher* C. Pengecualian selain #BP akan dipaksa masuk ke rutinitas *Halt* permanen M3, memutus siklus galat berulang .` |
| `Ketidaksesuaian Frame Trap (*Mismatch*)` | `[cite_start]Log QEMU mencetak properti `trap_vector` yang keliru atau *random*` `[cite: 891-898]`. | `Fungsi pembaca memori C menerima format struktur salah karena absennya *error code*, mengorupsi register memori.` | `Injeksi taktis `pushq $0` di rutinitas `ISR_NOERR` untuk menyamaratakan jarak tumpukan struktur memori ke Dispatcher C.` |
`

### 15.3 Triage yang Dilakukan

```text
Urutan diagnosis untuk mendeteksi anomali pada Modul 4 dieksekusi melalui teknik observabilitas hierarkis:
1. Validasi Prasyarat: Menjalankan `m4_preflight.sh` untuk memastikan utilitas dasar Modul 3 (Toolchain dan dependensi arsitektur) belum rusak [cite: 610-631].
2. Static Audit Level: Membangun sistem, disusul eksekusi skrip `m4_audit_elf.sh`. Metode dekompilasi instruksi ELF (`objdump` dan `nm`) diterapkan guna memvalidasi eksistensi IDT, absennya library dinamis eksternal (host libc), dan ketersediaan instruksi rakitan `lidt`/`iretq` [cite: 632-655].
3. Dynamic Emulator Level: Menguji stabilitas operasional biner menggunakan QEMU (`m4_qemu_run.sh`). Evaluasi fungsional dipantau melalui pencatatan log asinkron dari I/O UART COM1.
4. GDB Intervention Level: Jika QEMU macet tanpa sempat mencetak log komplit, rutinitas pengikatan remote tcp:1234 (GDB Stub) dipicu bersama parameter Stop-before-run (-S). Breakpoint statis ditaruh pada fungsi vital seperti `x86_64_trap_dispatch` untuk menangkap frame register yang sedang ditransfer [cite: 830-848].
```

---

## 16. Prosedur Rollback

Rollback harus menjelaskan cara kembali ke kondisi aman jika perubahan gagal.

| Skenario rollback | Perintah | Data yang harus diselamatkan | Status |
|---|---|---|---|
| Kembali ke commit awal | `` `git checkout 4134947` `` | `[Kegagalan arsitektur dan artefak evidence/M4/]` | `[Belum teruji]` |
| Revert commit praktikum | `` `git revert b37e980` `` | `[Evaluasi log uji varian normal OS M4]` | `[tBelum teruji]` |
| Bersihkan artefak build | `` `make clean` `` | `[Sumber OS utama dijamin aman. Hanya menghancurkan direktori rilis dan firmware lokal.]` | `[teruji]` |
| Regenerasi image | `` `./tools/scripts/make_iso.sh` `` | `[-]` | `[teruji]` |

Catatan rollback:

```text
[Prosedur `make clean` dan penciptaan ulang citra berkas (`make_iso.sh`) telah divalidasi sepanjang waktu selama sesi praktikum (uji fungsional per tahapan). Skenario rollback fatal ke versi kernel M3 (`git checkout` atau `git revert`) telah diantisipasi di awal praktikum menggunakan perlindungan alur branch terpisah (m4-idt-exception-path). Namun, pengembalian status ekstrem ini tidak pernah diperlukan karena stabilitas source code M4 langsung tercapai tanpa mengorbankan inti repositori..]
```

---

## 17. Keamanan dan Reliability

### 17.1 Risiko Keamanan

| Risiko | Boundary | Dampak | Mitigasi | Evidence |
|---|---|---|---|---|
| `[Ketergantungan Tersembunyi (Supply Chain Host)]` | `[Utilitas Kompilator (Clang/LLD)]` | `[Pendelegasian fungsi rahasia ke libc Linux host secara senyap, berujung ke fatalitas memori (Undefined Behavior Crash) saat dieksekusi murni.k]` | `[Pendeklarasian flag isolasi mutlak: -ffreestanding, -nostdlib, dan -fno-builtin .  ]` | `[Skrip dekompilasi nm -u mengembalikan himpunan kosong.]` |
| `[Injeksi Interupsi Tak Terduga (Unhandled Exception)]` | `[Rutinitas Register dan Pengiriman IDT (lidt)]` | `[Ketiadaan rute balasan fungsional dari eksepsi CPU berpotensi mendegradasi state sistem ke dalam siklus re-boot paksa (Triple Fault)]` | `[Penetapan Assembly Handler Stub ke seluruh batas maksimal 32 eksepsi awal, yang dilindungi oleh pengkondisian Trap Dispatcher untuk mendelegasikan statusnya ke arah Panic Halt.  ]` | `[QEMU tidak pernah me-reboot secara acak di tengah pengujian interupsi int3.]` |

### 17.2 Reliability dan Data Integrity

| Risiko reliability | Dampak | Deteksi | Mitigasi |
|---|---|---|---|
| `[Korupsi Tumpukan Memori Fungsional (Red-Zone Stack Corruption)]` | `[Tertimpanya data operasional interupsi ke dalam area register fungsi yang sedang aktif, menghasilkan galat kalkulasi masif.k]` | `[Eksepsi merusak parameter return address fungsi yang menaunginya pasca pengembalian iretq.]` | `[Disuntikkan argumen parameter -mno-red-zone di dalam struktur kompilasi berkas C dan Assembly kerne]` |
| `[Penurunan Kinerja Akibat Galat Re-entrancy (Infinite Recovery)]` | `[Terjadinya eksekusi eksepsi ganda secara acak ketika Dispatcher sedang sibuk mendiagnosis galat .]` | `[QEMU terkunci dan berotasi ke vektor tak wajar (seperti #DF Double Fault).]` | `[Pengaturan jenis pintu masuk makro Interrupt Gate yang secara inheren membersihkan register status IF (mematikan interupsi eksternal).]` |

### 17.3 Negative Test

| Negative test | Input buruk | Expected result | Actual result | Status |
|---|---|---|---|---|
| `[Pengetesan Intentional Breakpoint Recovery]` | `[Pemicu __asm__ volatile ("int3")]` | `[dOS mencetak bukti penerimaan interupsi dan eksekusi lanjutan tak dihentikan .]` | `[[M4] trap dispatch: #BP Breakpoint tercetak disusul oleh konfirmasi [M4] returned from breakpoint handler.]` | `[PASS]` |
| `[es Kompilasi Varian Panic Fail-Closed]` | `[Pemicu makro MCSOS_M4_TRIGGER_PANIC=1 .  ]` | `[dRutinitas mem- bypass eksekusi kmain ke Halt state permanen via pesan Panik Modul 4.]` | `[Lolos proses build statis tanpa masalah (berkas kernel.panic.elf siap ditautkan) .  ]` | `[PASS]` |

---

## 18. Pembagian Kerja Kelompok

Isi bagian ini hanya jika praktikum dikerjakan berkelompok. Untuk pengerjaan individu, tulis “Tidak berlaku”.

| Nama | NIM | Peran | Kontribusi teknis | Commit/artefak |
|---|---|---|---|---|
| `Muhamad Nabil` | `2583207073017` | `Ketua / Implementasi` | `Pembangunan skrip bash dan lainya di terminal wsl.` | `b37e980` |
| `Marko Ali Musa` | `25842074006` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `b37e980` |
| `Muharam Alfarizi` | `25832074002` | `Anggota / Dokumentasi` | `Penyusunan laporan.` | `b37e980` |

### 18.1 Mekanisme Koordinasi

```text
[```text
Koordinasi kelompok dilakukan secara terpusat dengan pembagian tugas yang spesifik. Seluruh pengembangan arsitektur OS, modifikasi skrip Bash, pengujian di lingkungan Linux WSL, dan eksekusi emulator QEMU dikerjakan secara eksklusif oleh Ketua Kelompok (Nabil). Repositori utama dikelola secara lokal. 

Sementara itu, proses penyusunan laporan dikerjakan oleh Anggota (Marko dan Muharam) dengan cara mengumpulkan log terminal, mengompilasi screenshot Framebuffer, dan menyusun format Markdown sesuai standar yang diminta.]
```

### 18.2 Evaluasi Kontribusi

| Anggota | Persentase kontribusi yang disepakati | Bukti | Catatan |
|---|---:|---|---|
| `[Muhamad Nabil]` | `[100%]` | `[Log Git, Source Code, Skrip Bash]` | `[bekerja dengan baik]` |
| `[Marko Ali Musa]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |
| `[Muharam Alfarizi]` | `[100%]` | `[Dokumen Markdown Laporan]` | `[bekerja dengan baik]` |


---

## 19. Kriteria Lulus Praktikum

Bagian ini wajib diisi. Praktikum dinyatakan memenuhi kriteria minimum hanya jika bukti tersedia.

| Kriteria minimum | Status | Evidence |
|---|---|---|
| Proyek dapat dibangun dari clean checkout | `[PASS]` | `[Log output terminal make clean && make build.  ]` |
| Perintah build terdokumentasi | `[PASS]` | `[Terdokumentasi pada Bab 10 (Langkah Kerja Implementasi).n]` |
| QEMU boot atau test target berjalan deterministik | `[PASS]` | `[File log QEMU menangkap inisiasi arsitektur [M4] IDT loaded]` |
| Semua unit test/praktikum test relevan lulus | `[PASS]` | `[Nilai dari skrip otomasi grade_m4.sh di lingkungan lokal.]` |
| Log serial disimpan | `[PASS/]` | `[Tersimpan di repositori pada jalur evidence/M4/m4-qemu-serial.log.  ]` |
| Panic path terbaca atau dijelaskan jika belum relevan | `[PASS]` | `[Tertuang dalam log analitik dan penjabaran Fail-Closed Policy pada Bab 15.4.  ]` |
| Tidak ada warning kritis pada build | `[PASS]` | `[Proses kompilasi tervalidasi bersih dari galat, dibentengi oleh flag -Werror.]` |
| Perubahan Git terkomit | `[PASS]` | `[Tersimpan aman pada hash komit b37e980.  ]` |
| Desain dan failure mode dijelaskan | `[PASS]` | `[Terperinci secara hierarkis pada Bab 9 dan Bab 15]` |
| Laporan berisi screenshot/log yang cukup | `[PASS]` | `[Log statis, ekstraksi manifest, dan ringkasan eksekusi QEMU diarsipkan secara transparan.  ]` |

Kriteria tambahan untuk praktikum lanjutan:

| Kriteria lanjutan | Status | Evidence |
|---|---|---|
| Static analysis dijalankan | `[PASS]` | `[Skrip inspeksi statis m4_audit_elf.sh memeriksa ketiadaan simbol host libc .  ]` |
| Stress test dijalankan | `[PASS]` | `[Eksekusi OS masih dalam level arsitektur early-boot primitif murni, belum mengakomodasi multitasking.]` |
| Fuzzing atau malformed-input test dijalankan | `[PASS` | `[Tidak relevan pada level OS ini (belum ada gerbang masukan dari pengguna / Userspace).]` |
| Fault injection dijalankan | `[PASS]` | `[Pengetesan pelemparan eksepsi paksa (Intentional Breakpoint) untuk menguji fungsi kepulangan iretq.  ]` |
| Disassembly/readelf evidence tersedia | `[PASS]` | `[Bukti statis forensik dikoleksi utuh (kernel.disasm.txt, kernel.syms.txt, kernel.readelf.*).]` |
| Review keamanan dilakukan | `[PASS]` | `[Penjabaran pembatasan batas merah memori (Red-Zone) dan bahaya pasca interupsi terdapat di Bab 17.]` |
| Rollback diuji | `[PASS]` | `[Prosedur destruktif pelumpuhan artefak make clean diulas di Bab 16.]` |

---

## 20. Readiness Review

Pilih satu status dengan alasan berbasis bukti.

| Status | Definisi | Pilihan |
|---|---|---|
| Belum siap uji | Build/test belum stabil atau bukti belum cukup | `[ ]` |
| Siap uji QEMU | Build bersih, QEMU/test target berjalan, log tersedia | `[ ]` |
| Siap demonstrasi praktikum | Siap ditunjukkan di kelas dengan bukti uji, failure mode, dan rollback | `[ ]` |
| Kandidat siap pakai terbatas | Hanya untuk penggunaan terbatas setelah test, security review, dokumentasi, dan known issue tersedia | `[ ]` |

Alasan readiness:

```text
[Jelaskan status yang dipilih berdasarkan bukti, bukan klaim.]
```

Known issues:

| No. | Issue | Dampak | Workaround | Target perbaikan |
|---|---|---|---|---|
| 1 | `[issue]` | `[dampak]` | `[workaround]` | `[milestone]` |

Keputusan akhir:

```text
[Contoh: “Berdasarkan bukti build, QEMU serial log, dan hasil make test, hasil praktikum ini layak disebut siap uji QEMU untuk milestone M2. Belum layak disebut siap demonstrasi praktikum karena panic path belum diuji dengan fault injection.”]
```

---

## 21. Rubrik Penilaian 100 Poin

| Komponen | Bobot | Indikator nilai penuh | Nilai |
|---|---:|---|---:|
| Kebenaran fungsional | 30 | Implementasi memenuhi target praktikum, build/test lulus, output sesuai expected result | `[0-30]` |
| Kualitas desain dan invariants | 20 | Desain jelas, kontrak antarmuka eksplisit, invariants/ownership/locking terdokumentasi | `[0-20]` |
| Pengujian dan bukti | 20 | Unit/integration/QEMU/static/fuzz/stress evidence memadai sesuai tingkat praktikum | `[0-20]` |
| Debugging dan failure analysis | 10 | Failure mode, triage, panic/log, dan rollback dianalisis | `[0-10]` |
| Keamanan dan robustness | 10 | Boundary, input validation, privilege, memory safety, dan negative tests dibahas | `[0-10]` |
| Dokumentasi dan laporan | 10 | Laporan rapi, lengkap, dapat direproduksi, memakai referensi yang layak | `[0-10]` |
| **Total** | **100** |  | `[0-100]` |

Catatan penilai:

```text
[Diisi dosen/asisten.]
```

---

## 22. Kesimpulan

### 22.1 Yang Berhasil

```text
Praktikum Modul 4 berhasil merancang dan menerapkan Interrupt Descriptor Table (IDT) untuk arsitektur x86_64 beserta Exception Trap Path awal [cite: 5-7]. Struktur `idt_base` dan `idt_limit` berhasil dialokasikan pada Higher-Half Kernel dan dimuat menggunakan instruksi `lidt` tanpa memicu crash [cite: 27, 805-813]. Selain itu, Assembly Stubs sukses menormalisasi eksepsi CPU menjadi struktur trap frame yang seragam. Keberhasilan tertinggi dibuktikan dari uji Intentional Breakpoint (vektor 3), di mana Trap Dispatcher berhasil menerima sinyal int3, mencetak register via log serial, dan CPU sukses kembali melanjutkan sisa eksekusi melalui perintah `iretq` dengan aman [cite: 31, 824-828].
```

### 22.2 Yang Belum Berhasil

```text
[Sesuai batasan (non-goals) praktikum, sistem operasi ini masih tertutup dari penanganan interupsi perangkat keras eksternal (IRQ, PIC/APIC, Timer) dan belum memiliki lingkungan Multitasking/Userspace [cite: 30, 38-40]. Untuk eksepsi kritis non-recoverable (seperti Page Fault atau General Protection Fault), OS ini masih bergantung murni pada jalur Fail-Closed Panic, sehingga sistem akan mengunci CPU secara permanen (Halt) dan belum mampu memperbaiki state memori secara dinamis [cite: 41, 58, 900-901]..]
```

### 22.3 Rencana Perbaikan

```text
[Langkah terukur berikutnya adalah melanjutkan integrasi kernel ke tahap Virtual Memory (Milestone 5) guna memfasilitasi penanganan dinamis Page Fault Handler (`#PF`)[cite: 40, 938]. Selain itu, arsitektur IDT yang telah mapan di Modul 4 ini akan diisi ulang dengan konfigurasi Programmable Interrupt Controller (PIC/APIC) untuk menangani input-output asinkron perangkat keras sistem di masa mendatang[cite: 39, 1020].]
```

---

## 23. Lampiran

### Lampiran A — Commit Log

```text
[b37e980 M4 add x86_64 IDT and exception trap path
4134947 M3 panic path logging gdb and disassembly audit
adc1765 docs: add M2 readiness review
80cbc2f M2: add bootable kernel ELF and early serial console
2e39289 M1: add reproducible toolchain readiness baseline]
```

### Lampiran B — Diff Ringkas

```diff
[evidence/M4/kernel.disasm.txt                   |  329 +++++++++++
 evidence/M4/kernel.readelf.header.txt           |   17 +
 evidence/M4/kernel.readelf.programs.txt         |   22 +
 evidence/M4/kernel.syms.txt                     |   49 ++
 evidence/M4/manifest.txt                        |   14 +
 kernel/arch/x86_64/idt.c                        |   42 ++
 kernel/arch/x86_64/include/mcsos/arch/idt.h     |   49 ++
 kernel/arch/x86_64/include/mcsos/arch/isr.h     |    9 +
 kernel/arch/x86_64/isr.S                        |  126 ++++
 kernel/core/kmain.c                             |   33 +-
 kernel/core/trap.c                              |   73 +++
 kernel/include/mcsos/kernel/version.h           |    2 +-
 Makefile                                        |   84 ++-
 tools/gdb_m4.gdb                                |    8 +
 tools/scripts/grade_m4.sh                       |   16 +
 tools/scripts/m4_audit_elf.sh                   |   25 +
 tools/scripts/m4_collect_evidence.sh            |   26 +
 tools/scripts/m4_preflight.sh                   |   34 +
 tools/scripts/m4_qemu_run.sh                    |   26 +
 19 files changed, 1839 insertions(+), 21 deletions(-)]
```

### Lampiran C — Log Build Lengkap

```text
[clang --target=x86_64-unknown-none-elf -std=c17 -ffreestanding -fno-builtin -fno-stack-protector -fno-stack-check -fno-pic -fno-pie -fno-lto -m64 -march=x86-64 -mabi=sysv -mno-red-zone -mno-mmx -mno-sse -mno-sse2 -mcmodel=kernel -Wall -Wextra -Werror -Ikernel/arch/x86_64/include -Ikernel/include -c kernel/arch/x86_64/idt.c -o build/normal/kernel/arch/x86_64/idt.o
ld.lld -nostdlib -static -z max-page-size=0x1000 -T linker.ld -Map=build/kernel.map -o build/kernel.elf ...
[M4] [PASS] ELF, symbol, IDT, LIDT, dan IRETQ audit lulus untuk build/kernel.elf]
```

### Lampiran D — Log QEMU Lengkap

```text
[limine: Loading executable `boot():/boot/kernel.elf`...
MCSOS 260502 M4 kernel entered
kernel_start=0xffffffff80000000
kernel_end=0xffffffff80004018
rflags_before_idt=0x0000000000000082
idt_base=0xffffffff80003000
idt_limit=0x0000000000000fff
[M4] IDT loaded
[M4] selftest: IDT invariants passed
[M4] triggering intentional breakpoint exception
[M4] trap dispatch: #BP Breakpoint
trap_vector=0x0000000000000003
trap_error=0x0000000000000000
trap_rip=0xffffffff80000205
trap_rflags=0x0000000000000082
[M4] breakpoint handled; returning with iretq
[M4] returned from breakpoint handler
[M4] IDT and exception dispatch path installed
[M4] ready for QEMU smoke test and GDB audit]
```

### Lampiran E — Output Readelf/Objdump

```text
[ELF Header:
  Magic:   7f 45 4c 46 02 01 01 00 00 00 00 00 00 00 00 00 
  Class:                             ELF64
  Data:                              2's complement, little endian
  Version:                           1 (current)
  OS/ABI:                            UNIX - System V
  Machine:                           Advanced Micro Devices X86-64]
```

### Lampiran F — Screenshot

| No. | File | Keterangan |
|---|---|---|
| 1 | `[NA]` | `[Eksekusi OS via emulator QEMU diinstruksikan dalam mode headless (-display none). Bukti murni berupa file teks rekam jejak Serial (COM1).]` |

### Lampiran G — Bukti Tambahan

```text
[M4_LOCAL_SCORE=80/100
[M4] [PASS] Evidence dikumpulkan di evidence/M4]
```

---

## 24. Daftar Referensi

Gunakan format IEEE. Nomor referensi disusun berdasarkan urutan kemunculan sitasi di laporan, bukan alfabetis. Contoh format:

```text
[1] R. H. Arpaci-Dusseau and A. C. Arpaci-Dusseau, Operating Systems: Three Easy Pieces. Madison, WI, USA: Arpaci-Dusseau Books, [tahun/edisi yang digunakan]. [Online]. Available: [URL]. Accessed: [tanggal akses].

[2] R. Cox, F. Kaashoek, and R. Morris, “xv6: a simple, Unix-like teaching operating system,” MIT PDOS. [Online]. Available: [URL]. Accessed: [tanggal akses].

[3] Intel Corporation, Intel 64 and IA-32 Architectures Software Developer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[4] Advanced Micro Devices, AMD64 Architecture Programmer’s Manual. [Online]. Available: [URL]. Accessed: [tanggal akses].

[5] UEFI Forum, Unified Extensible Firmware Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].

[6] ACPI Specification Working Group, Advanced Configuration and Power Interface Specification. [Online]. Available: [URL]. Accessed: [tanggal akses].
```

Referensi yang benar-benar dipakai dalam laporan:

```text
[1] M. Sidiq, "Panduan Praktikum M4 - Interrupt Descriptor Table, Exception Trap Path, Trap Frame, dan Fault-Handling Awal MCSOS 260502," Institut Pendidikan Indonesia, Garut, Indonesia, 2026.

[2] Intel Corporation, "Intel® 64 and IA-32 Architectures Software Developer Manuals," Intel, 2026. [Online]. Available: [https://www.intel.com/content/www/us/en/developer/articles/technical/intel-sdm.html](https://www.intel.com/content/www/us/en/developer/articles/technical/intel-sdm.html). Accessed: 2026-06-14.

[3] QEMU Project, "QEMU System Emulation Invocation," QEMU Documentation, 2026. [Online]. Available: [https://www.qemu.org/docs/master/system/invocation.html](https://www.qemu.org/docs/master/system/invocation.html). Accessed: 2026-06-14.

[4] Free Software Foundation, "GNU ld Linker Scripts," GNU Binutils Documentation, 2026. [Online]. Available: [https://sourceware.org/binutils/docs/ld/Scripts.html](https://sourceware.org/binutils/docs/ld/Scripts.html). Accessed: 2026-06-14.

[5] LLVM Project, "Clang Command Guide and Driver Documentation," LLVM Documentation, 2026. [Online]. Available: [https://clang.llvm.org/docs/ClangCommandLineReference.html](https://clang.llvm.org/docs/ClangCommandLineReference.html). Accessed: 2026-06-14.
```

---

## 25. Checklist Final Sebelum Pengumpulan

| Checklist | Status |
|---|---|
| Semua placeholder `[isi ...]` sudah diganti | `[Y]` |
| Metadata laporan lengkap | `[Ya]` |
| Commit awal dan akhir dicatat | `[Ya]` |
| Perintah build dan test dapat dijalankan ulang | `[Ya]` |
| Log build dilampirkan | `[Ya]` |
| Log QEMU/test dilampirkan | `[Ya]` |
| Artefak penting diberi hash | `[Ya]` |
| Desain, invariants, ownership, dan failure modes dijelaskan | `[Ya]` |
| Security/reliability dibahas | `[Ya]` |
| Readiness review tidak berlebihan | `[Ya]` |
| Rubrik penilaian diisi atau disiapkan | `[Ya]` |
| Referensi memakai format IEEE | `[Ya]` |
| Laporan disimpan sebagai Markdown | `[Ya]` |

---

## 26. Pernyataan Pengumpulan

Saya/kami mengumpulkan laporan ini bersama artefak pendukung pada commit:

```text
[b37e980]
```

Status akhir yang diklaim:

```text
[Siap demonstrasi praktikum]
```

Ringkasan satu paragraf:

```text
[Praktikum Modul 4 berhasil merancang arsitektur Interrupt Descriptor Table (IDT) tingkat rendah dan rutinitas pengecualian CPU untuk x86_64. Pengujian menetapkan bahwa struktur trap frame 16-byte selaras dengan ABI C Sistem V, fungsi inline-assembly `lidt` memuat memori IDT dengan benar, dan jebakan taktis (Intentional Breakpoint) terbukti mampu memulihkan status eksekusi CPU menggunakan instruksi `iretq` tanpa membocorkan stack. Keterbatasan sistem Modul 4 masih berpegang teguh pada arsitektur Fail-Closed Panic Path M3 untuk galat fatal (#PF, #GP), yang pemulihannya akan dikembangkan secara komprehensif pada konfigurasi manajemen memori (PMM/VMM) di Modul 5 mendatang.]
```
